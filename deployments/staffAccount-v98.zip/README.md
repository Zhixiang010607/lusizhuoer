# staffAccount 云函数

当前版本：`v98`

`v98` 配合照片打卡，只把考勤只读响应中的 NULL 人脸分数原样返回 NULL，不再转换成 0 分；历史真实分数不变。不改查询权限、日报、培训发布、审核或核销。2026-11-01 已按 090 指引备份、迁移、验收并与 faceRecognition v137 一起部署。2026-11-05 的 faceRecognition v138 只修复结果恢复读取，不需重新部署本函数或重跑迁移。

当前联动部署矩阵：`staffAccount v98`、`faceRecognition v138`、
`verificationPhoto v13`、`teacherCreate v9`、`customerRating v8`。迁移 075—086
验收通过后再部署当前版本；照片打卡还须先按 090 指引完整备份、迁移和验收（既有 087 不重复执行）。下文较旧版本号属于历史说明。

`v97` 修正培训 PDF 发布确认：INSERT 空 RETURNING 或写入回执丢失时，按原请求号独立回读，不能返回无效资料 ID。数据库结果不确定时保留已完整上传的私有 PDF，返回 `TRAINING_MATERIAL_PUBLISH_PENDING`，原任务重试确认而不是重传；格式／字节校验明确失败仍拒绝。正常链路不增加数据库读请求，只有异常／空返回才回读；旧客户端响应兼容，无新 action、SQL 或迁移，不改变账号、审核、核销、余额、BLE 或照片。v97 源码包不代表已经部署，必须核对线上 health 与代码回下载。

`v96` 将培训资料删除改为总部明确二次确认后物理删除 PDF 和数据库记录。`setTrainingMaterialStatus` 须携带 `confirmDeletion: true`；旧客户端没有明确确认参数时拒绝删除并提示更新。先按精确 ID／对象引用停止阅读并独立回读，再清理私有对象，最后调用 087 的精确删除函数；不以空 RETURNING 判断资料不存在。部分失败保留待清理记录，只对总部显示且可重试；老师缓存仍每次鉴权，不能绕过删除。完成后仅保留请求号／删除时间的内部防重标记，不保存标题、文件引用或人员内容。没有自动批量删除历史下架资料，不改变任何核销规则。

`v95` 为本地已缓存 PDF 增加 `getTrainingMaterialAccess({ materialId, authorizeOnly: true })`：仍回读当前 UID、在职状态和资料发布状态，但仅返回权威文件元数据，不再申请无用下载签名；缓存失效或不存在时再走原签名读取。未传该参数的网页版及旧小程序保持原响应兼容。下架资料对总部与老师均停止读取；此历史版本无需新迁移，不改变任何核销链路。

`v94` 修复培训 PDF 阅读签名地址：兼容 manager-node 5.6.4 返回的根相对 signedURL，仅拼接配置环境的 HTTPS 网关；随后仍严格校验环境、私有桶、对象路径和签名 token，原样保留签名查询字节。总部／在职老师权限、五分钟有效期、100 MiB 上传、下架规则、数据库与核销链路不变；无需新迁移。

`v93` 增加迁移 086 的培训学习资料库，供总部网页版和微信小程序共用：只有总部账号可以签发私有 PDF 直传、确认发布和删除（下架）；下架后不再显示，也不提供重新发布入口。在职老师只能在小程序列出并短时阅读已发布资料，门店账号和已封存老师均被服务端拒绝。标题必填，PDF 最大 100 MiB，服务端同时校验对象大小、内容类型和 `%PDF-` 文件头；客户端请求编号保证后台上传确认幂等。资料对象保存在独立私有桶，阅读链接有效期 5 分钟，不提供老师永久下载或分享 action。

`v92` 采用迁移 084 的日报最终契约：老师只填写“今日完成事项”，必填且最多 1000 个 Unicode 字符，支持 emoji 和特殊符号；新建或当天修改时其余三个历史兼容列统一写为空字符串，历史四栏内容不批量改写。迁移 085 同时把项目核销／充值单说明分别收紧到 1000 个 Unicode 字符，原样保留显式换行、emoji 和特殊符号。

`v91` 修复人员目录把长账号 ID 通过三位 `LPAD` 截断成重复短编号的问题：老师目录的兼容 `person_code` 直接使用数据库唯一 `teacher_code`，其他角色也使用完整账号 ID，不再产生多个 `T200`。老师编号仍只用于服务端关联与旧路由兼容，小程序展示改用姓名和全局唯一登录手机号；不修改老师主键、手机号约束或任何业务归属。`v90` 修正老师个人月历的考勤日期映射，并把总部按日追踪明确拆为“完整打卡／仅上班打卡／仅下班打卡／未打卡”四组；只有上下班两笔齐全才返回工作时长。它同时返回老师入职日期，并新增仅供当前在职老师读取本人单月考勤与四栏日报的合并只读接口，供小程序内两个独立月历复用。所有本人范围都从认证会话派生，客户端不能指定老师；正常／体验／补录核销及设备交互路径不变。`v89` 新增总部老师主页的个人月历只读接口：一次返回指定老师单月的上／下班考勤与四栏日报，允许查看封存老师既有历史。`v88` 在迁移 081 之后把考勤记录中服务端保存的附近地点和具体地址返回给老师本人
与总部打卡详情。旧记录没有地址时继续显示经纬度和地图，不虚构文字地址；地址不
参与权限、人脸或上下班顺序判断。`v87` 把迁移 079 审核通过的补录核销纳入与正常核销相同的老师归属、客户关系、
总部统计和查询口径，并继续由现有 `reviewOrder` 事务完成通过／驳回；待审补录只
出现在总部核销审核队列。正常／体验核销和其他审核流程不变。

`staffAccount` 负责员工会话、总部／门店账号、人员状态、老师体验额度、项目、独立产品、培训资料、审核与总部统计。v98 提供老师工作日报、总部日报追踪、老师／总部考勤只读查询和培训资料权限服务。日报只保留“今日完成事项”，必填、最多 1000 个 Unicode 字符并允许 emoji／特殊符号；老师只能修改上海时间今天的日报，历史永久只读。考勤查询按迁移 078 分别返回同日上班、下班两笔不可变记录和工作时长，总部固定返回姓名、电话、上下班时间、两个详情和工作时长七项；它不接收打卡照片、不做人脸验证。数据库迁移 073、074、084 管理当前日报写入契约，迁移 075 与 078 管理考勤，迁移 086 管理培训资料元数据。v87 增加迁移 079 的补录核销审核、归属和统计口径，v81 的既有老师额度和统计能力保持不变。

## 登录与会话边界

`staffAccount v98` 同时支持现有手机号＋密码登录和微信小程序手机号快捷登录。两种方式必须在 CloudBase 身份源中关联到同一个已有 Auth 用户和同一 UID；业务角色、账号状态和门店范围仍只从该 UID 对应的 PostgreSQL `staff_accounts` 回读。总部老师维度统计只认来源与业务类型都符合矩阵的 `teacher_id`：门店来源限充值、退费、正常核销和审核通过的补录核销，老师来源限该提交账号本人办理的充值、退费、正常核销、审核通过的补录核销和体验核销。历史总部、退役角色、老师错绑或门店体验仍保留在总量、门店和项目统计中，但不会产生老师归属；排名将这些有效事实单独汇总为“未指定老师”，不会计到任何真实老师名下。总部审核与门店精确工单读取采用相同口径；其他历史工单保留但显示“未指定”。

小程序快捷登录流程为：

1. 用户在 `open-type="getPhoneNumber"` 按钮上明确授权，小程序只把当次一次性 `phoneCode` 交给 CloudBase SDK 的 `auth.signInWithPhoneAuth({ phoneCode })`。
2. CloudBase 校验微信身份和手机号，按已验证手机号关联现有 Auth 用户；小程序不自行解密手机号。
3. 取得 CloudBase 会话后，客户端调用无手机号参数的 `{ "action": "session" }`。`staffAccount` 只信任平台认证上下文中的当前 UID，不使用客户端手机号查找账号。
4. UID 未绑定业务账号，或账号／门店／老师已封存时直接拒绝。快捷登录不创建业务账号，不修改 `staff_accounts.auth_uid`，也不得把新 UID 自动改绑到旧员工。

`session` 的公开请求固定为：

```json
{ "action": "session" }
```

不得再传入 `phone`、`role`、`storeId` 或其他身份范围参数。应用代码不记录或自行持久化 `phoneCode`、微信 session key、CloudBase access／refresh token 或密码；CloudBase 登录凭据仅由官方 SDK 管理。登录失败时必须退出 CloudBase 会话并清除本地业务会话。手机号＋密码继续作为应急入口。

## 老师创建与人脸边界

老师只能通过独立 `teacherCreate v9` 创建。创建需要姓名、手机号、初始密码、
老师明确同意以及当场拍摄的正面照片；照片只用于建立考勤专用 1:1 人脸档案，
不参与登录、激活、客户业务、正常核销或体验核销。总部老师主页可调用 `teacherCreate v9`
现场原子替换考勤专用人脸；门店和老师本人无权调用。`staffAccount v98` 已彻底移除旧的业务老师人脸
Saga，不保留旧发布兼容入口，也不读取或写入 `teacher_face_operations`：

- `beginTeacherProvisionWithFace`
- `provisionTeacherWithFace`
- `readTeacherProvisionResult`
- `upsertTeacherFace`
- `reconcileTeacherFaceOperation`
- `getTeacherFaceOperationStatus`

调用这些旧 action 会统一进入“不支持的操作”。`provisionStaff({ role: "teacher" })` 也会在 Auth 查询、用户创建和 SQL 写入之前返回 `TEACHER_CREATE_SERVICE_REQUIRED`。新建老师只能调用 `teacherCreate`。

迁移 051／052 的旧表、函数和历史记录不再是本函数的运行依赖。旧 Saga 的退役
已由迁移 053 完成；该迁移会物理删除旧操作表与六个私有函数，不影响老师及
业务历史。当前联动版本为 `staffAccount v98`／`faceRecognition v138`／
`verificationPhoto v13`／`teacherCreate v9`。

## 保留能力

以下老师相关能力仍由本函数负责，并且与人脸流程彼此独立：

- `listStaff({ role: "teacher" })`：读取老师目录及老师主档状态。
- `setMasterStatus({ teacherId, status })`、`setStaffStatus(...)`：同步封存或激活老师主档、业务账号和 CloudBase 登录状态；老师人脸字段不参与状态判断。
- `getTeacherExperienceEntitlements({ teacherId })`：读取额度配置与完整审计历史；每个活跃配置同时返回当前基础额度、当前可用、上海自然月内不可变充值流水合计、上海自然月内已通过体验核销合计和累计体验。业务累计只统计来源可信、已通过且由该老师本人提交的体验核销，历史异常扣减仍保留在余额和流水中。
- `upsertTeacherExperienceEntitlement(...)`：配置月度额度。
- `deleteTeacherExperienceEntitlement(...)`：封存额度配置，保留历史。
- `rechargeTeacherExperienceEntitlement(...)`：写入独立、不可变的老师体验充值流水。
- `resetTeacherExperienceQuotas()`：总部手动补跑月度重置。
- `getOwnDailyReportMonth`／`getOwnDailyReport`／`saveOwnDailyReport`：仅在职老师按当前 UID 绑定的老师账号读取本人日报；只有上海时间当天可保存，“今日完成事项”必填且最多 1000 个 Unicode 字符，支持 emoji／特殊符号，整份日报通过一个确认动作提交，历史只读且不能删除。总部、门店和客户端传入的人员编号均不能扩大范围。
- `getHqDailyReportTrackingDay`／`getHqDailyReportDetail`：仅总部按日期只读查看当前全部在职老师的完成名单和日报详情；老师主档或账号任一已封存就从名单中排除，且不能凭日报编号绕过状态限制读取详情。接口不接受客户端传入的老师范围，不提供总部代填、修改或删除动作。门店和老师不能调用总部追踪动作。
- `getOwnTeacherWorkMonth({ month })`：仅当前在职老师读取本人指定月份的上／下班考勤和单栏日报；老师与员工编号只取认证会话，不能从客户端扩大范围。它只负责月历查询，不代替现有打卡、人脸验证或日报保存动作。
- `getHqAttendanceTrackingDay({ attendanceDate })`：仅总部按日期把当前在职老师拆成完整打卡、仅上班、仅下班和未打卡四组。只有完整打卡返回工作时长；任一缺失记录都不得伪造时间、详情或工时。
- `saveProductReceiptTemplate(...)`：仅总部保存核销／体验共用说明与充值／退费共用说明；每段最多 1000 个 Unicode 字符，规范化跨平台换行符但不删除显式换行，允许 emoji 和特殊符号。项目 LOGO 继续使用私有对象短时签名直传与鉴权分块回读。
- `listTrainingMaterials`／`getTrainingMaterialAccess`：总部与在职老师只能读取当前已发布资料和 5 分钟临时阅读地址；已下架资料不再返回，门店和已封存老师无权调用。
- `beginTrainingMaterialUpload`／`confirmTrainingMaterialUpload`／`discardTrainingMaterialUpload`／`setTrainingMaterialStatus`：仅总部管理培训 PDF。标题必填，最大 100 MiB，私有对象和数据库记录通过稳定客户端请求编号幂等绑定；确认“删除”后 PDF 和资料记录一起删除，不提供重新发布。旧的仅下架保留文件设计已退役。

老师状态与额度依赖既有 046、048、049、050 数据库能力。目录与历史额度仍可查询。
老师赠送体验核销时，服务端按登录账号绑定老师额度，并只核验和保存所选客户的人脸。

非老师能力包括会话与总部引导、门店建档和账号管理、项目与回执模板、独立产品主档、审核队列、人员密码和状态、总部统计，以及运营身份下线维护。

## 项目与产品边界

`v81` 将两个概念明确分开：

- 既有 `public.products` 与 `listProducts`／`createProduct`／`setProductStatus` 保持接口兼容，但业务名称统一为“项目”。它继续承载充值、退费、正常核销、体验额度、项目 LOGO 和单据模板，项目编号仍为 `PRD...`。
- 新增 `public.retail_products` 与 `listRetailProducts`／`createRetailProduct`／`setRetailProductStatus`，只管理涂抹类／实物产品。页面只录入产品名称，数据库自动生成 `PDT...` 编号；状态只允许 `ACTIVE`／`ARCHIVED`，不提供删除 action，迁移 060 的触发器也会拒绝物理删除。
- 三个独立产品 action 均只允许总部账号调用。产品不会进入项目下拉框、客户余额、核销、体验额度、项目汇总、排名或项目凭证模板；迁移 061 后，活跃产品只可作为充值单第三步的可选赠品主档，赠品不改变库存、项目次数或业务统计。
- 同名产品不能重复新增；封存产品应重新激活原记录。每次状态变化由数据库写入状态历史。
- 迁移 062 后，`reviewRetailProductPurchase` 只允许活跃总部账号审核独立购买单。购买审核与充值／退费审核分开；通过后才由客户主页汇总读取，审核本身不修改项目余额或库存。
- `listRetailProductPurchaseReviews` 为兼容保留名称，但 v81 的总部“产品查询”读取两种来源：`PURCHASE` 来自独立产品购买表，`GIFT` 来自迁移 061 的充值赠品不可变明细。接口接受来源、门店、独立产品、审核状态、姓名、生日、提交日期和完整工单号，返回来源汇总、状态汇总与稳定分页。`GIFT` 行的工单号、状态、提交／审核时间和详情 ID 均取父充值单；客户端必须显示“充值赠送”并进入父 `RC...` 工单，不得另造赠品单。产品购买审核页、购买详情和审核动作必须显式传 `sourceType: "PURCHASE"`，不得把赠品放入第二次审核。

`v81` 的总部排名读取使用严格的三段选择：`dimension` 只允许 `store`／`teacher`，`productId` 留空代表全部项目或传入一个真实项目 ID，`rankingMetric` 只允许 `recharge`／`verification`／`experience`／`refund`。数据库先按日期和项目过滤已通过业务，再按所选业务次数字段降序；当前为 `ACTIVE` 的门店／老师即使范围内四项均为 0 也进入候选集合，已封存门店／老师只有在范围内至少存在一条有效业务时才进入。老师维度对无法可信归属到真实老师的有效业务增加单独“未指定老师”汇总项，因而老师排名合计与同筛选条件的全局业务合计一致，同时不改变任何真实老师的归属。响应回显 `dimension`、`productId`、`rankingMetric` 和该业务的 `rankingTotal`，客户端必须核对回显后才显示排名。旧版按四类合计排序、把项目作为排名对象、遗漏 0 次激活老师、遗漏未归属业务或把 0 次封存主档列入排名的规则已退役。

`v81` 另提供 `getHqDashboard({ mode: "product-summary" })` 的完整项目汇总分页。它以 `public.products` 为主表，因此无业务记录和已封存但仍保留历史的项目也不会从项目目录中消失；四类次数只统计所选日期内已通过的业务。响应每页默认 10 项、最多 500 项，回传 `pageNumber`、`pageSize`、`total`、`totalPages` 和当前页 `rows`。客户端必须逐页展示全部项目，页面底部的四类合计来自同一日期范围的全局总数，不得用当前页小计或旧 Top 10 图表代替。总部看板可以显式传入 `allTime: true` 从最早有效充值／退费／核销／体验记录统计到今天；该模式不得同时传入开始或结束日期。

## 环境变量

必需或按功能使用：

- `BOOTSTRAP_HQ_UID`：首个总部管理员的 CloudBase UID。
- `CLOUDBASE_ENV_ID` 或 `TCB_ENV`：CloudBase 环境。
- `CLOUDBASE_APIKEY`（兼容 `CLOUDBASE_SERVICE_ROLE_KEY`）：服务端用户管理和项目模板私有存储。
- `PRODUCT_TEMPLATE_BUCKET_ID`：项目模板私有桶；默认 `product-templates`。
- `TRAINING_MATERIAL_BUCKET_ID`：培训 PDF 私有桶；默认 `training-materials`。

`staffAccount` 不需要 `FACE_SECRET_ID`、`FACE_SECRET_KEY`、`FACE_GROUP_ID` 或老师照片桶配置。

微信小程序快捷登录也不为 `staffAccount` 新增 AppSecret 或自定义登录私钥环境变量。微信小程序 AppSecret 只配置在 CloudBase 身份源的服务端设置中，不得进入小程序、云函数环境变量、README、ZIP、日志或截图。

## 月度额度 Timer

本函数只保留老师体验额度月度重置 Timer。旧的 `reconcile-teacher-face-operations` Timer 必须从 `staffAccount` 触发器配置中删除。

```json
{
  "triggers": [
    {
      "name": "reset-teacher-experience-quotas-monthly",
      "type": "timer",
      "config": "0 0 0 1 * * *",
      "enable": true
    }
  ]
}
```

控制台时区选择 `Asia/Shanghai`。函数只接受平台 Timer 事件，并校验 `TRIGGER_SRC=timer`、函数名、触发器名、事件时间及无终端用户 UID；普通客户端不能伪造月度重置。

## 部署与验收

上传包文件名必须为 `staffAccount-v98.zip`。ZIP 根目录直接包含：

```text
index.js
package.json
README.md
```

不得在 ZIP 中再套 `staffAccount/` 目录。平台按根目录 `package.json` 安装依赖；交付前必须回读 ZIP 根目录的 `README.md`，确认其显示当前版本 `v98`，并确认 ZIP 内 `index.js` 的运行时版本同样为 `v98`。

生产切换顺序：

1. 在 CloudBase 身份源中配置类型 `WX_MICRO_APP` 并绑定正确小程序 AppID；设置 `On=TRUE`、`AutoSignInWhenPhoneNumberMatch=TRUE`、`TransparentMode=FALSE`、`ReuseUserId=FALSE`，同时保留现有手机号＋密码登录方式。全托管持久身份模式可能固定回显 `AutoSignUpWithProviderUser=TRUE`；这只建立 Auth 身份，业务会话仍只认既有 UID 映射，未绑定身份必须拒绝。
2. 依次执行并验收迁移 060—087；087 必须通过完整数据库备份门禁执行，四项只读检查全部 `READY` 后再部署 v98。迁移不删除任何现有资料。创建私有桶 `training-materials`（或通过 `TRAINING_MATERIAL_BUCKET_ID` 指定的私有桶），再打包并上传 `staffAccount-v98.zip`，使用 Node.js 20，配置上述环境变量，并将安全规则限制为已登录且非匿名用户。v81 的精确充值工单详情和统一产品查询继续读取 061 中不可变的赠品明细，并通过 062 的独立函数审核产品购买单。
3. 客户评价作为独立同轮服务部署：执行并验收 068 与 070，配置至少 32 字节的 `CUSTOMER_RATING_SIGNING_KEY` 及实际 `rating.html` 地址 `CUSTOMER_RATING_BASE_URL`，上传 `customerRating-v8.zip` 并确认其 `health`。`staffAccount v98` 不签发或写入评价。
4. 删除 `staffAccount` 上的旧人脸补偿 Timer，只保留月度额度 Timer。
5. 部署后先调用 `{ "action": "health" }`，确认版本和配置就绪；再分别用现有已登录会话和微信手机号授权后的会话调用无参数 `{ "action": "session" }`，确认返回的 UID、角色和门店与旧密码账号完全一致。
6. `staffAccount v98`、`faceRecognition v138`、`verificationPhoto v13` 和 `teacherCreate v9` 验收通过后才发布依赖新后端契约的小程序；不得先发布依赖培训资料、日报、考勤、老师创建、照片 5 MiB 边界或无参数 `session` 的客户端。v130 → v133 的高清读取兼容客户端放宽本地图片字节／尺寸校验，并明确用旧服务端已有 original=true 参数首屏读取原图；与旧服务端兼容，应先让实际使用者更新，再完整备份执行 089 并更新考勤函数。不会引入新 action，也不因矩阵变更重复部署本函数。

健康检查必须返回：

```json
{
  "ok": true,
  "version": "v98",
  "managerNodeInstalled": true,
  "teacherExperienceResetTimerTriggerName": "reset-teacher-experience-quotas-monthly",
  "teacherCreationService": "teacherCreate"
}
```

健康响应中不再出现老师 Saga、Auth 创建回执、同请求恢复、051／052 租约或人脸补偿 Timer 字段。

密码继续遵循 CloudBase 规则：8–32 位，且大写、小写、数字、特殊字符四类中至少包含三类。业务角色只从 PostgreSQL `staff_accounts` 解析，不写入 CloudBase 用户描述 JSON。
