"use strict";

const cloudbase = require("@cloudbase/node-sdk");
const CloudBaseManager = require("@cloudbase/manager-node");
const crypto = require("crypto");
const https = require("https");
const { parseTeacherLookup, lookupCustomerCondition } = require("./teacher-customer-lookup");

const PHOTO_ONLY_FUNCTION = String(process.env.VERIFICATION_PHOTO_ONLY_FUNCTION || "").trim() === "1";
const FUNCTION_VERSION = PHOTO_ONLY_FUNCTION ? "v13" : "v144";
const OPERATIONAL_EXPORT_MAX_ROWS = 1000;
const CLEANUP_TIMER_TRIGGER_NAME = PHOTO_ONLY_FUNCTION
  ? "cleanup-verification-photo-uploads-hourly"
  : "cleanup-verification-photo-drafts-hourly";
const EXPECTED_FUNCTION_NAME = PHOTO_ONLY_FUNCTION ? "verificationPhoto" : "faceRecognition";
const MAX_IMAGE_BYTES = 4 * 1024 * 1024;
// SCF synchronous events are capped at 6 MB and Base64 adds roughly 33%.
// Face evidence and the legacy function-carried fallback therefore remain at
// 3 MiB. Supplemental photos use signed object-storage PUTs and may reach
// 5 MiB without entering the function event. Customer enrollment keeps its
// existing independent 4 MiB limit above.
const MAX_VERIFICATION_IMAGE_BYTES = 3 * 1024 * 1024;
const MAX_EXTRA_VERIFICATION_IMAGE_BYTES = 5 * 1024 * 1024;
const MAX_VERIFICATION_FUNCTION_FALLBACK_BYTES = 3 * 1024 * 1024;
const MAX_THUMBNAIL_BYTES = 384 * 1024;
const FACE_MODEL_VERSION = "3.0";
let cloudApp = null;
let managerClient = null;
let storeBindingLayout = null;
let iaiClientClass = null;
let pinyinFunction = null;
let verificationPhotoUploadSchemaReady = null;
let teacherTeamReadService = null;
const signedCustomerPhotoCache = new Map();
const signedVerificationPhotoCache = new Map();

function app() {
  if (!cloudApp) cloudApp = cloudbase.init({});
  return cloudApp;
}

function cloudbaseEnvId() {
  const envId = String(process.env.CLOUDBASE_ENV_ID || process.env.TCB_ENV || "").trim();
  if (!envId) throw new Error("Missing cloud function environment variable: CLOUDBASE_ENV_ID or TCB_ENV");
  return envId;
}

function manager() {
  if (!managerClient) managerClient = CloudBaseManager.init({ envId: cloudbaseEnvId() });
  return managerClient;
}

function required(name) {
  const value = String(process.env[name] || "").trim();
  if (!value) throw new Error(`Missing cloud function environment variable: ${name}`);
  return value;
}

function cloudbaseServiceRoleKey() {
  const managedValue = String(process.env.CLOUDBASE_APIKEY || "").trim();
  const legacyValue = String(process.env.CLOUDBASE_SERVICE_ROLE_KEY || "").trim();
  const value = managedValue || legacyValue;
  if (!value) {
    throw new Error(
      "Missing CloudBase service-role API key: CLOUDBASE_APIKEY or CLOUDBASE_SERVICE_ROLE_KEY"
    );
  }
  return value;
}

function cloudbaseServiceRoleKeyConfigured() {
  const managedValue = String(process.env.CLOUDBASE_APIKEY || "").trim();
  const legacyValue = String(process.env.CLOUDBASE_SERVICE_ROLE_KEY || "").trim();
  return Boolean(managedValue || legacyValue);
}

function numberSetting(name, fallback, minimum, maximum) {
  const value = process.env[name];
  if (value === undefined || value === "") return fallback;
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < minimum || parsed > maximum) {
    throw new Error(`${name} must be a number between ${minimum} and ${maximum}.`);
  }
  return parsed;
}

function verificationPhotoUrlTtlSeconds() {
  return Math.trunc(numberSetting("VERIFICATION_PHOTO_URL_TTL_SECONDS", 900, 60, 900));
}

function verificationPhotoUploadTtlSeconds() {
  return Math.trunc(numberSetting("VERIFICATION_PHOTO_UPLOAD_TTL_SECONDS", 600, 120, 900));
}

function booleanSetting(name, fallback = false) {
  const value = process.env[name];
  if (value === undefined || value === "") return fallback;
  return ["1", "true", "yes", "on"].includes(String(value).trim().toLowerCase());
}

function fail(message, code = "BAD_REQUEST") {
  const error = new Error(message);
  error.code = code;
  throw error;
}

function sqlText(value) {
  return `'${String(value ?? "").replace(/'/g, "''")}'`;
}

function customerStatusSql(status) {
  if (status !== "ACTIVE" && status !== "ARCHIVED") {
    fail("客户状态不受支持。", "INVALID_CUSTOMER_STATUS");
  }
  return sqlText(status);
}

function temporalNumber(value) {
  let current = value;
  for (let depth = 0; depth < 5; depth += 1) {
    if (typeof current === "number") return Number.isFinite(current) ? current : NaN;
    if (typeof current === "string") {
      const parsed = Number(current.trim());
      return Number.isFinite(parsed) ? parsed : NaN;
    }
    if (!current || typeof current !== "object") return NaN;
    const key = ["$numberLong", "$numberInt", "$numberDouble", "value"].find((name) => current[name] !== undefined);
    if (!key) return NaN;
    current = current[key];
  }
  return NaN;
}

function sqlTemporalText(value, columnName = "") {
  const column = String(columnName || "").toLowerCase();
  if (!/(?:_at|_time|_date)$/.test(column) || value === null || value === undefined || value === "") return value;
  let current = value;
  for (let depth = 0; depth < 8; depth += 1) {
    if (current instanceof Date) return Number.isNaN(current.getTime()) ? value : current.toISOString();
    if (typeof current === "number") {
      const millis = Math.abs(current) < 100000000000 ? current * 1000 : current;
      const parsed = new Date(millis);
      return Number.isNaN(parsed.getTime()) ? value : parsed.toISOString();
    }
    if (typeof current === "string") {
      const text = current.trim();
      if (!text) return value;
      if (/^-?\d+(?:\.\d+)?$/.test(text)) { current = Number(text); continue; }
      if (text[0] === "{" || text[0] === "[") {
        try { current = JSON.parse(text); continue; } catch (error) { /* keep database text */ }
      }
      if (/_date$/.test(column) && /^\d{4}-\d{2}-\d{2}$/.test(text)) return text;
      const normalized = /^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?$/.test(text)
        ? `${text.replace(" ", "T")}Z`
        : text.replace(/([+-]\d{2})$/, "$1:00");
      const parsed = new Date(normalized);
      return Number.isNaN(parsed.getTime()) ? text : parsed.toISOString();
    }
    if (!current || typeof current !== "object") return value;
    if (typeof current.toDate === "function") {
      try { current = current.toDate(); continue; } catch (error) { /* inspect stored fields */ }
    }
    if (typeof current.toISOString === "function") {
      try {
        const text = current.toISOString();
        if (text) { current = text; continue; }
      } catch (error) { /* inspect stored fields */ }
    }
    const seconds = temporalNumber(current.seconds ?? current._seconds);
    if (Number.isFinite(seconds)) {
      const nanos = temporalNumber(current.nanoseconds ?? current._nanoseconds);
      const parsed = new Date((seconds * 1000) + (Number.isFinite(nanos) ? Math.trunc(nanos / 1000000) : 0));
      return Number.isNaN(parsed.getTime()) ? value : parsed.toISOString();
    }
    const wrapperKey = ["$date", "$numberLong", "$numberInt", "$numberDouble", "date", "timestamp", "time", "iso", "isoString", "value"].find((name) => current[name] !== undefined);
    if (wrapperKey) { current = current[wrapperKey]; continue; }
    const printable = String(current);
    if (printable && printable !== "[object Object]") { current = printable; continue; }
    return value;
  }
  return value;
}

function parseSqlRows(result) {
  const columns = result?.Columns || [];
  return (result?.Rows || []).map((raw) => {
    const values = Array.isArray(raw) ? raw : JSON.parse(raw);
    return Object.fromEntries(columns.map((column, index) => [column, sqlTemporalText(values[index], column)]));
  });
}

async function executeSql(sql) {
  return parseSqlRows(await manager().database.executePGSql({ Sql: sql }));
}

function databaseBoolean(value) {
  return [true, "true", "t", 1, "1"].includes(value);
}

async function mapWithConcurrency(items, limit, mapper) {
  const rows = Array.isArray(items) ? items : [];
  const output = new Array(rows.length);
  let cursor = 0;
  const workers = Array.from({ length: Math.min(Math.max(1, Number(limit) || 1), rows.length) }, async () => {
    while (cursor < rows.length) {
      const index = cursor;
      cursor += 1;
      output[index] = await mapper(rows[index], index);
    }
  });
  await Promise.all(workers);
  return output;
}

async function getStoreBindingLayout() {
  if (storeBindingLayout) return storeBindingLayout;
  const rows = await executeSql(
    `SELECT
       EXISTS (
         SELECT 1 FROM information_schema.columns
         WHERE table_schema = 'public'
           AND table_name = 'stores'
           AND column_name = 'store_account_id'
       ) AS has_store_account_id,
       EXISTS (
         SELECT 1 FROM information_schema.tables
         WHERE table_schema = 'public'
           AND table_name = 'staff_store_assignments'
       ) AS has_staff_store_assignments`
  );
  const layout = rows?.[0] || {};
  if (databaseBoolean(layout.has_store_account_id)) storeBindingLayout = "stores";
  else if (databaseBoolean(layout.has_staff_store_assignments)) storeBindingLayout = "assignments";
  else fail("The database has no store-account binding structure.", "DATABASE_SCHEMA_MISSING");
  return storeBindingLayout;
}

function faceClient() {
  // Customer list/detail/photo actions do not use Tencent IAI. Loading the
  // large face SDK only for actual face operations keeps ordinary customer
  // selection fast, especially after a cold start.
  if (!iaiClientClass) iaiClientClass = require("tencentcloud-sdk-nodejs").iai.v20200303.Client;
  return new iaiClientClass({
    credential: { secretId: required("FACE_SECRET_ID"), secretKey: required("FACE_SECRET_KEY") },
    region: "ap-guangzhou",
    profile: { httpProfile: { endpoint: "iai.tencentcloudapi.com" } }
  });
}

function faceSettings() {
  return {
    qualityThreshold: numberSetting("FACE_QUALITY_THRESHOLD", 70, 0, 100),
    livenessEnabled: booleanSetting("FACE_LIVENESS_ENABLED", false),
    livenessThreshold: numberSetting("FACE_LIVENESS_THRESHOLD", 40, 0, 100),
    verifyThreshold: numberSetting("FACE_VERIFY_THRESHOLD", 60, 0, 99.99),
    maxYaw: numberSetting("FACE_MAX_YAW", 20, 0, 90),
    maxPitch: numberSetting("FACE_MAX_PITCH", 20, 0, 90),
    maxRoll: numberSetting("FACE_MAX_ROLL", 15, 0, 90)
  };
}

function photoStorageSettings() {
  return {
    bucketId: String(process.env.CUSTOMER_PHOTO_BUCKET_ID || "customer-photos").trim(),
    accessToken: cloudbaseServiceRoleKey(),
    envId: cloudbaseEnvId()
  };
}

function verificationPhotoStorageSettings() {
  return {
    bucketId: String(process.env.VERIFICATION_PHOTO_BUCKET_ID || "verification-photos").trim(),
    accessToken: cloudbaseServiceRoleKey(),
    envId: cloudbaseEnvId()
  };
}

function verificationPhotoStorageCandidates() {
  const candidates = [verificationPhotoStorageSettings(), photoStorageSettings()];
  return candidates.filter((candidate, index) => candidate.bucketId
    && candidates.findIndex((item) => item.bucketId === candidate.bucketId) === index);
}

function parsePhotoReference(value) {
  const reference = String(value || "").trim();
  if (!reference.startsWith("pg://")) fail("客户照片引用格式无效。", "PHOTO_REFERENCE_INVALID");
  const path = reference.slice(5);
  const separator = path.indexOf("/");
  if (separator <= 0 || separator === path.length - 1) fail("客户照片引用格式无效。", "PHOTO_REFERENCE_INVALID");
  return { bucketId: path.slice(0, separator), objectName: path.slice(separator + 1) };
}

function photoObjectCandidates(bucketId, objectName) {
  const bucket = String(bucketId || "").trim().replace(/^\/+|\/+$/g, "");
  const object = String(objectName || "").trim().replace(/^\/+/, "");
  if (!bucket || !object) return [];
  const prefix = `${bucket}/`;
  const candidates = [object];
  if (object.startsWith(prefix)) candidates.push(object.slice(prefix.length));
  else candidates.push(`${prefix}${object}`);
  return [...new Set(candidates.filter(Boolean))];
}

function storageObjectMissing(error) {
  const detail = [error?.code, error?.message].filter(Boolean).join(" ").toUpperCase();
  return detail.includes("STORAGE_OBJECT_NOT_FOUND") || detail.includes("OBJECT NOT FOUND");
}

function storageBucketMissing(error) {
  const detail = [error?.code, error?.message].filter(Boolean).join(" ").toUpperCase();
  return detail.includes("STORAGE_BUCKET_NOT_FOUND") || detail.includes("BUCKET NOT FOUND");
}

function signedUploadFunctionFallbackAllowed(error) {
  const detail = [error?.code, error?.message, responseErrorText(error)]
    .filter(Boolean).join(" ").toUpperCase();
  return detail.includes("STORAGE_INVALID_REQUEST")
    && detail.includes("RELATED RESOURCE DOES NOT EXIST");
}

function storageUploadResponseMismatch(error) {
  const detail = String(error?.message || "");
  return detail.includes("上传成功但响应格式异常")
    && detail.includes("Id")
    && detail.includes("Key");
}

function verificationPhotoStorageEnvironmentError(error, storage) {
  const mismatch = new Error(
    `腾讯云照片存储无法在环境 ${storage.envId} 中识别私有桶 ${storage.bucketId}。请确认这是 PG 云存储桶的真实 ID，并确认 CLOUDBASE_APIKEY（或兼容变量 CLOUDBASE_SERVICE_ROLE_KEY）属于同一环境。`
  );
  mismatch.code = "PHOTO_STORAGE_ENV_MISMATCH";
  mismatch.requestId = error?.requestId || error?.RequestId || "";
  return mismatch;
}

function verificationPhotoStorageAccessError(error, storage) {
  const detail = [error?.code, error?.message, responseErrorText(error)]
    .filter(Boolean).join(" ").toUpperCase();
  const configurationFailure = storageBucketMissing(error)
    || (detail.includes("STORAGE_INVALID_REQUEST") && detail.includes("RELATED RESOURCE DOES NOT EXIST"))
    || ["401", "403", "AUTH", "JWT", "TOKEN", "EXCEED_AUTHORITY", "ACTION_FORBIDDEN"]
      .some((marker) => detail.includes(marker));
  if (configurationFailure) return verificationPhotoStorageEnvironmentError(error, storage);
  const unavailable = new Error("腾讯云照片存储暂时无法确认服务端上传通道，请稍后重试。");
  unavailable.code = "PHOTO_STORAGE_CHECK_FAILED";
  unavailable.requestId = error?.requestId || error?.RequestId || "";
  return unavailable;
}

function verificationPhotoBucketReady(row, requiredBytes = MAX_EXTRA_VERIFICATION_IMAGE_BYTES) {
  if (!row || databaseBoolean(row.public)) return false;
  const limit = Number(row.file_size_limit || 0);
  if (Number.isFinite(limit) && limit > 0 && limit < requiredBytes) return false;
  const allowed = row.allowed_mime_types;
  if (allowed === null || allowed === undefined || allowed === "") return true;
  const mimeTypes = Array.isArray(allowed) ? allowed : String(allowed).match(/[\w.+-]+\/[\w.+-]+/g) || [];
  return mimeTypes.map((value) => String(value).toLowerCase()).includes("image/jpeg");
}

function signedPhotoUrl(value, depth = 0) {
  if (depth > 4 || value === null || value === undefined) return "";
  if (typeof value === "string") return /^https:\/\//i.test(value.trim()) ? value.trim() : "";
  if (Array.isArray(value)) {
    for (const item of value) {
      const url = signedPhotoUrl(item, depth + 1);
      if (url) return url;
    }
    return "";
  }
  if (typeof value !== "object") return "";
  for (const [key, item] of Object.entries(value)) {
    if (/^(?:signedurl|fullsignedurl|url)$/i.test(key) && typeof item === "string" && /^https:\/\//i.test(item.trim())) {
      return item.trim();
    }
  }
  for (const item of Object.values(value)) {
    const url = signedPhotoUrl(item, depth + 1);
    if (url) return url;
  }
  return "";
}

function cachedCustomerPhoto(cacheKey) {
  const now = Date.now();
  for (const [key, value] of signedCustomerPhotoCache) {
    if (!value || value.expiresAt <= now + 10000) signedCustomerPhotoCache.delete(key);
  }
  const cached = signedCustomerPhotoCache.get(cacheKey);
  return cached && cached.expiresAt > now + 10000 ? cached : null;
}

function rememberCustomerPhoto(cacheKeys, value) {
  for (const key of new Set(cacheKeys.filter(Boolean))) {
    signedCustomerPhotoCache.delete(key);
    signedCustomerPhotoCache.set(key, value);
  }
  while (signedCustomerPhotoCache.size > 500) {
    signedCustomerPhotoCache.delete(signedCustomerPhotoCache.keys().next().value);
  }
}

function safeResponseShape(value, depth = 0) {
  if (depth > 2 || value === null || value === undefined) return typeof value;
  if (Array.isArray(value)) return value.slice(0, 2).map((item) => safeResponseShape(item, depth + 1));
  if (typeof value !== "object") return typeof value;
  return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, safeResponseShape(item, depth + 1)]));
}

function responseErrorText(value, depth = 0) {
  if (depth > 4 || value === null || value === undefined) return "";
  if (typeof value === "string") return value;
  if (Array.isArray(value)) return value.map((item) => responseErrorText(item, depth + 1)).filter(Boolean).join(" ");
  if (typeof value !== "object") return "";
  const messages = [];
  for (const [key, item] of Object.entries(value)) {
    if (/^(?:error|code|message)$/i.test(key)) messages.push(responseErrorText(item, depth + 1));
    else if (/^(?:data|result|results|items)$/i.test(key)) messages.push(responseErrorText(item, depth + 1));
  }
  return messages.filter(Boolean).join(" ");
}

function cleanImage(value) {
  if (typeof value !== "string" || !value.trim()) fail("A camera photo is required.");
  const base64 = value.replace(/^data:image\/[a-zA-Z0-9.+-]+;base64,/, "").trim();
  if (!/^[A-Za-z0-9+/=]+$/.test(base64)) fail("The camera photo format is invalid.");
  const buffer = Buffer.from(base64, "base64");
  if (!buffer.length || buffer.length > MAX_IMAGE_BYTES) fail("The camera photo must be between 1 byte and 4 MB.");
  return { base64, buffer };
}

function cleanVerificationJpeg(value, label, maximumBytes) {
  const text = String(value || "").trim();
  if (!/^data:image\/jpeg;base64,/i.test(text)) {
    fail(`${label}必须是 JPEG 照片。`, "PHOTO_FORMAT_INVALID");
  }
  const base64 = text.replace(/^data:image\/jpeg;base64,/i, "").trim();
  if (!/^[A-Za-z0-9+/=]+$/.test(base64)) fail(`${label}格式无效。`, "PHOTO_FORMAT_INVALID");
  const buffer = Buffer.from(base64, "base64");
  if (!buffer.length || buffer.length > maximumBytes) {
    fail(`${label}不得超过 ${Math.ceil(maximumBytes / 1024 / 1024)} MB。`, "PHOTO_TOO_LARGE");
  }
  if (buffer.length < 4 || buffer[0] !== 0xff || buffer[1] !== 0xd8 || buffer[2] !== 0xff) {
    fail(`${label}内容不是有效 JPEG。`, "PHOTO_FORMAT_INVALID");
  }
  return { base64, buffer };
}

function verificationPhotoDimensions(event = {}) {
  const width = Number(event.imageWidth);
  const height = Number(event.imageHeight);
  if (!Number.isInteger(width) || !Number.isInteger(height)
      || width < 1 || width > 10000 || height < 1 || height > 10000) {
    fail("照片尺寸信息无效。", "PHOTO_DIMENSIONS_INVALID");
  }
  return { width, height };
}

function verificationPhotoReference(value) {
  const reference = String(value || "").trim();
  if (!reference.startsWith("pg://")) fail("核销照片引用格式无效。", "PHOTO_REFERENCE_INVALID");
  const path = reference.slice(5);
  const separator = path.indexOf("/");
  if (separator <= 0 || separator === path.length - 1) fail("核销照片引用格式无效。", "PHOTO_REFERENCE_INVALID");
  return { bucketId: path.slice(0, separator), objectName: path.slice(separator + 1) };
}

function verificationPhotoUploadRequestId(event = {}) {
  const requestId = String(event.requestId || "").trim();
  if (!/^[A-Za-z0-9][A-Za-z0-9_-]{15,63}$/.test(requestId)) {
    fail("照片上传请求编号无效，请重新选择照片。", "PHOTO_UPLOAD_REQUEST_INVALID");
  }
  return requestId;
}

function verificationPhotoUploadBytes(event = {}) {
  const bytes = Number(event.originalBytes);
  if (!Number.isInteger(bytes) || bytes < 4 || bytes > MAX_EXTRA_VERIFICATION_IMAGE_BYTES) {
    fail("补充照片不能超过 5 MB。", "PHOTO_TOO_LARGE");
  }
  return bytes;
}

function verificationPhotoFunctionUploadProof(context, request) {
  const payload = [
    "verification-photo-function-upload-v1",
    String(request.request_id || ""),
    String(context.verificationId || ""),
    String(context.caller.staffId || ""),
    String(request.photo_slot || ""),
    String(request.expected_original_bytes || ""),
    String(request.original_object_ref || "")
  ].join("\n");
  return crypto.createHmac("sha256", cloudbaseServiceRoleKey()).update(payload).digest("hex");
}

function requireVerificationPhotoFunctionUploadProof(event, context, request) {
  const supplied = String(event.functionUploadProof || "").trim().toLowerCase();
  const expected = verificationPhotoFunctionUploadProof(context, request);
  if (!/^[a-f0-9]{64}$/.test(supplied)
      || !crypto.timingSafeEqual(Buffer.from(supplied, "hex"), Buffer.from(expected, "hex"))) {
    fail("该上传任务没有使用云函数兼容通道的授权，请重新选择照片。", "PHOTO_FUNCTION_UPLOAD_NOT_AUTHORIZED");
  }
}

function nestedResponseValue(value, keyPattern, validator, depth = 0) {
  if (depth > 5 || value === null || value === undefined) return "";
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = nestedResponseValue(item, keyPattern, validator, depth + 1);
      if (found) return found;
    }
    return "";
  }
  if (typeof value !== "object") return "";
  for (const [key, item] of Object.entries(value)) {
    if (keyPattern.test(key) && validator(item)) return String(item).trim();
  }
  for (const item of Object.values(value)) {
    const found = nestedResponseValue(item, keyPattern, validator, depth + 1);
    if (found) return found;
  }
  return "";
}

function signedVerificationPhotoUpload(response, storage, objectName) {
  let url = nestedResponseValue(
    response,
    /^(?:url|signedurl|fullsignedurl|uploadurl)$/i,
    (value) => typeof value === "string"
      && (/^https:\/\//i.test(value.trim()) || /^\/v1\/storages\/object\/upload\/sign\//.test(value.trim()))
  );
  const token = nestedResponseValue(
    response,
    /^(?:token|uploadtoken|signaturetoken)$/i,
    (value) => typeof value === "string" && value.trim().length > 0
  );
  const expectedPath = `/v1/storages/object/upload/sign/${encodeURIComponent(storage.bucketId)}/${objectName
    .split("/").map((segment) => encodeURIComponent(segment)).join("/")}`;
  const trustedOrigin = `https://${storage.envId}.api.tcloudbasegateway.com`;
  let target;
  try {
    target = new URL(url, trustedOrigin);
  } catch (_) {
    target = null;
  }
  if (!url || !target || target.origin !== trustedOrigin || target.pathname !== expectedPath) {
    console.error("CloudBase signed upload response has no HTTPS URL", {
      bucketId: storage.bucketId,
      objectName,
      responseShape: safeResponseShape(response)
    });
    fail("核销照片上传地址生成失败，请检查云函数存储配置。", "PHOTO_UPLOAD_SIGN_FAILED");
  }
  // CloudBase's uploadToSignedUrl(path, token, file) sends the short-lived
  // upload token as the signed URL's `token` query parameter. manager-node
  // versions may return that token separately, so normalize the URL on the
  // server. The browser never receives or sends the service-role API key and
  // must not place this upload token in an Authorization header.
  if (token) {
    if (!target.searchParams.get("token")) target.searchParams.set("token", token);
  }
  url = target.toString();
  return {
    url,
    bucketId: storage.bucketId,
    objectName,
    method: "PUT",
    contentType: "image/jpeg",
    headers: { "Content-Type": "image/jpeg" }
  };
}

async function signVerificationPhotoUploadReference(referenceValue) {
  const reference = verificationPhotoReference(referenceValue);
  const storage = verificationPhotoStorageForEvidence(reference);
  if (!storage) fail("核销照片不属于允许的私有存储桶。", "PHOTO_BUCKET_MISMATCH");
  const response = await manager().storage.signUploadObject({
    bucketId: reference.bucketId,
    objectName: reference.objectName,
    upsert: false,
    accessToken: storage.accessToken,
    envId: storage.envId
  });
  return signedVerificationPhotoUpload(response, storage, reference.objectName);
}

async function requireVerificationPhotoFunctionFallbackStorage(referenceValue) {
  const reference = verificationPhotoReference(referenceValue);
  const storage = verificationPhotoStorageForEvidence(reference);
  if (!storage) fail("核销照片不属于允许的私有存储桶。", "PHOTO_BUCKET_MISMATCH");
  try {
    await manager().storage.listObjects({
      bucketId: reference.bucketId,
      limit: 1,
      withDelimiter: false,
      accessToken: storage.accessToken,
      envId: storage.envId
    });
  } catch (error) {
    throw verificationPhotoStorageAccessError(error, storage);
  }
  return storage;
}

function verificationPhotoObjectInfoBody(value, depth = 0) {
  if (depth > 5 || value === null || value === undefined || typeof value !== "object") return null;
  if (!Array.isArray(value) && (
    Object.prototype.hasOwnProperty.call(value, "size")
    || Object.prototype.hasOwnProperty.call(value, "content_type")
    || Object.prototype.hasOwnProperty.call(value, "bucket_id")
  )) return value;
  for (const item of Array.isArray(value) ? value : Object.values(value)) {
    const found = verificationPhotoObjectInfoBody(item, depth + 1);
    if (found) return found;
  }
  return null;
}

async function inspectVerificationPhotoObject(referenceValue, expectedBytes) {
  const reference = verificationPhotoReference(referenceValue);
  const storage = verificationPhotoStorageForEvidence(reference);
  if (!storage) fail("核销照片不属于允许的私有存储桶。", "PHOTO_BUCKET_MISMATCH");
  let response;
  try {
    response = await manager().storage.getObjectInfoAuthenticated({
      bucketId: reference.bucketId,
      objectName: reference.objectName,
      method: "GET",
      accessToken: storage.accessToken,
      envId: storage.envId
    });
  } catch (error) {
    if (storageObjectMissing(error)) fail("照片尚未上传完成。", "PHOTO_UPLOAD_INCOMPLETE");
    throw error;
  }
  const info = verificationPhotoObjectInfoBody(response);
  if (!info) fail("无法读取已上传照片的信息。", "PHOTO_UPLOAD_INFO_INVALID");
  const bytes = Number(info.size ?? response?.headers?.["content-length"]);
  const contentType = String(info.content_type || response?.headers?.["content-type"] || "")
    .split(";", 1)[0].trim().toLowerCase();
  const returnedBucket = String(info.bucket_id || "").trim();
  const returnedName = String(info.name || "").trim().replace(/^\/+/, "");
  const allowedNames = photoObjectCandidates(reference.bucketId, reference.objectName);
  if (returnedBucket && returnedBucket !== reference.bucketId) {
    fail("已上传照片的存储桶不匹配。", "PHOTO_BUCKET_MISMATCH");
  }
  if (returnedName && !allowedNames.includes(returnedName)) {
    fail("已上传照片的对象路径不匹配。", "PHOTO_OBJECT_MISMATCH");
  }
  if (!Number.isInteger(bytes) || bytes !== expectedBytes || bytes < 4 || bytes > MAX_EXTRA_VERIFICATION_IMAGE_BYTES) {
    fail("已上传照片大小与上传请求不一致，请取消后重试。", "PHOTO_UPLOAD_SIZE_MISMATCH");
  }
  if (contentType !== "image/jpeg") {
    fail("已上传文件不是 JPEG 照片。", "PHOTO_FORMAT_INVALID");
  }
  const buffer = await downloadVerificationPhotoAuthenticated(referenceValue, MAX_EXTRA_VERIFICATION_IMAGE_BYTES);
  if (buffer.length !== bytes) {
    fail("已上传照片内容不完整，请取消后重试。", "PHOTO_UPLOAD_SIZE_MISMATCH");
  }
  return verificationPhotoBufferMetadata(buffer);
}

function verificationPhotoBufferMetadata(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 4 || buffer.length > MAX_EXTRA_VERIFICATION_IMAGE_BYTES) {
    fail("补充照片必须是不超过 5 MB 的 JPEG。", "PHOTO_TOO_LARGE");
  }
  const dimensions = jpegDimensions(buffer);
  return {
    bytes: buffer.length,
    width: dimensions.width,
    height: dimensions.height,
    sha256: crypto.createHash("sha256").update(buffer).digest("hex")
  };
}

async function downloadVerificationPhotoAuthenticated(referenceValue, maximumBytes, options = {}) {
  const reference = verificationPhotoReference(referenceValue);
  const verificationStorage = verificationPhotoStorageForEvidence(reference, options.allowAttendance === true);
  const customerStorage = photoStorageSettings();
  const retainedProfile = options.allowRetainedProfile === true
    && reference.bucketId === customerStorage.bucketId;
  const storage = retainedProfile ? customerStorage : verificationStorage;
  if (!storage) fail("核销照片不属于允许的私有存储桶。", "PHOTO_BUCKET_MISMATCH");
  let response;
  const objectNames = retainedProfile
    ? photoObjectCandidates(reference.bucketId, reference.objectName)
    : [reference.objectName];
  for (const objectName of objectNames) {
    try {
      response = await manager().storage.downloadAuthenticatedObject({
        bucketId: reference.bucketId,
        objectName,
        method: "GET",
        accessToken: storage.accessToken,
        envId: storage.envId
      });
      break;
    } catch (error) {
      if (!storageObjectMissing(error)) throw error;
    }
  }
  if (!response) fail("照片尚未上传完成。", "PHOTO_UPLOAD_INCOMPLETE");
  const status = Number(response?.status || 0);
  const declaredBytes = Number(response?.headers?.["content-length"] || 0);
  if (status !== 200 || !response?.body) {
    fail("无法读取已上传照片内容。", "PHOTO_UPLOAD_DOWNLOAD_FAILED");
  }
  if (declaredBytes > maximumBytes) {
    fail(`补充照片超过 ${Math.floor(maximumBytes / 1024 / 1024)} MB。`, "PHOTO_TOO_LARGE");
  }
  const chunks = [];
  let totalBytes = 0;
  for await (const chunk of response.body) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    totalBytes += buffer.length;
    if (totalBytes > maximumBytes) {
      response.body.destroy?.();
      fail(`补充照片超过 ${Math.floor(maximumBytes / 1024 / 1024)} MB。`, "PHOTO_TOO_LARGE");
    }
    chunks.push(buffer);
  }
  const result = Buffer.concat(chunks);
  if (!result.length) fail("已上传照片内容为空。", "PHOTO_UPLOAD_INCOMPLETE");
  return result;
}

function jpegDimensions(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 4
      || buffer[0] !== 0xff || buffer[1] !== 0xd8 || buffer[2] !== 0xff) {
    fail("已上传文件不是有效 JPEG 照片。", "PHOTO_FORMAT_INVALID");
  }
  const startOfFrame = new Set([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf]);
  let offset = 2;
  while (offset + 3 < buffer.length) {
    while (offset < buffer.length && buffer[offset] === 0xff) offset += 1;
    if (offset >= buffer.length) break;
    const marker = buffer[offset];
    offset += 1;
    if (marker === 0xd9 || marker === 0xda) break;
    if (marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
    if (offset + 2 > buffer.length) break;
    const segmentLength = buffer.readUInt16BE(offset);
    if (segmentLength < 2 || offset + segmentLength > buffer.length) break;
    if (startOfFrame.has(marker) && segmentLength >= 7) {
      const height = buffer.readUInt16BE(offset + 3);
      const width = buffer.readUInt16BE(offset + 5);
      if (width >= 1 && width <= 10000 && height >= 1 && height <= 10000) return { width, height };
      break;
    }
    offset += segmentLength;
  }
  fail("无法读取 JPEG 照片尺寸，请重新拍照。", "PHOTO_DIMENSIONS_INVALID");
}

async function uploadVerificationPhotoObject(objectName, buffer) {
  let missingBucketError = null;
  for (const storage of verificationPhotoStorageCandidates()) {
    try {
      await manager().storage.uploadObject({
        bucketId: storage.bucketId,
        objectName,
        body: buffer,
        contentType: "image/jpeg",
        contentLength: buffer.length,
        cacheControl: "private, max-age=31536000, immutable",
        upsert: false,
        accessToken: storage.accessToken,
        envId: storage.envId
      });
      return {
        bucketId: storage.bucketId,
        objectName,
        reference: `pg://${storage.bucketId}/${objectName}`
      };
    } catch (error) {
      // manager-node 5.6.4 throws this only after the storage gateway has
      // already returned an HTTP success response. We persist the exact
      // bucket/objectName supplied by this function, so missing response
      // metadata must not turn a completed upload into a false failure.
      if (storageUploadResponseMismatch(error)) {
        console.warn("CloudBase upload succeeded without Id/Key response metadata", {
          bucketId: storage.bucketId,
          objectName
        });
        return {
          bucketId: storage.bucketId,
          objectName,
          reference: `pg://${storage.bucketId}/${objectName}`
        };
      }
      if (!storageBucketMissing(error)) throw error;
      missingBucketError = error;
      console.warn("Verification photo bucket missing; trying the existing private customer photo bucket", {
        bucketId: storage.bucketId
      });
    }
  }
  throw missingBucketError || new Error("核销照片私有存储桶不可用。");
}

async function uploadVerificationPhotoReference(referenceValue, buffer) {
  const reference = verificationPhotoReference(referenceValue);
  const storage = verificationPhotoStorageForEvidence(reference);
  if (!storage) fail("核销照片不属于允许的私有存储桶。", "PHOTO_BUCKET_MISMATCH");
  try {
    await manager().storage.uploadObject({
      bucketId: reference.bucketId,
      objectName: reference.objectName,
      body: buffer,
      contentType: "image/jpeg",
      contentLength: buffer.length,
      cacheControl: "private, max-age=31536000, immutable",
      upsert: false,
      accessToken: storage.accessToken,
      envId: storage.envId
    });
  } catch (error) {
    if (storageUploadResponseMismatch(error)) {
      console.warn("CloudBase fallback upload succeeded without Id/Key response metadata", {
        bucketId: reference.bucketId,
        objectName: reference.objectName
      });
    } else {
      // The cloud-function response may be lost after Storage committed the
      // object. A retry keeps the same random request path; accept it only if
      // the authenticated bytes are exactly the same JPEG.
      let existing = null;
      try {
        existing = await downloadVerificationPhotoAuthenticated(referenceValue, MAX_EXTRA_VERIFICATION_IMAGE_BYTES);
      } catch (_) { /* preserve the original upload error */ }
      if (existing) {
        const expectedSha = crypto.createHash("sha256").update(buffer).digest("hex");
        const existingSha = crypto.createHash("sha256").update(existing).digest("hex");
        if (existing.length === buffer.length && existingSha === expectedSha) return reference;
        fail("同一上传请求的照片内容与已有文件不一致，请取消后重新上传。", "PHOTO_UPLOAD_CONTENT_CONFLICT");
      }
      if (signedUploadFunctionFallbackAllowed(error)) throw verificationPhotoStorageEnvironmentError(error, storage);
      throw error;
    }
  }
  return reference;
}

function verificationPhotoStorageForEvidence(reference, allowAttendance = false) {
  if (!/^(?:face-evidence|records)\//.test(reference.objectName)
      && !(allowAttendance && /^attendance\/[a-f0-9]{48}\.jpg$/.test(reference.objectName))) return null;
  return verificationPhotoStorageCandidates().find((storage) => storage.bucketId === reference.bucketId) || null;
}

async function deleteVerificationPhotoObject(referenceValue, options = {}) {
  if (!referenceValue) return true;
  try {
    const reference = verificationPhotoReference(referenceValue);
    const storage = verificationPhotoStorageForEvidence(reference, options.allowAttendance === true);
    if (!storage) return false;
    await manager().storage.deleteObject({
      bucketId: reference.bucketId,
      objectName: reference.objectName,
      accessToken: storage.accessToken,
      envId: storage.envId
    });
    return true;
  } catch (error) {
    if (storageObjectMissing(error)) return true;
    console.warn("Verification photo cleanup failed", error?.message || error);
    return false;
  }
}

function cachedVerificationPhoto(cacheKey) {
  const now = Date.now();
  for (const [key, value] of signedVerificationPhotoCache) {
    if (!value || value.expiresAt <= now + 10000) signedVerificationPhotoCache.delete(key);
  }
  const cached = signedVerificationPhotoCache.get(cacheKey);
  return cached && cached.expiresAt > now + 10000 ? cached : null;
}

function thumbnailTransformUrl(url) {
  const separator = String(url).includes("?") ? "&" : "?";
  return `${url}${separator}imageMogr2/thumbnail/480x480/format/webp/rquality/82`;
}

async function signVerificationPhoto(referenceValue, expiresIn, options = {}) {
  const reference = verificationPhotoReference(referenceValue);
  const customerStorage = photoStorageSettings();
  const verificationStorage = verificationPhotoStorageForEvidence(reference, options.allowAttendance === true);
  const isVerificationObject = Boolean(verificationStorage);
  const isRetainedProfile = options.allowRetainedProfile === true && reference.bucketId === customerStorage.bucketId;
  if (!isVerificationObject && !isRetainedProfile) {
    fail("核销照片不属于允许的私有存储桶。", "PHOTO_BUCKET_MISMATCH");
  }
  const storage = isRetainedProfile ? customerStorage : verificationStorage;
  const transformKey = options.thumbnailTransform === true ? "thumbnail" : "original";
  const cacheKey = `${reference.bucketId}/${reference.objectName}/${transformKey}`;
  const cached = cachedVerificationPhoto(cacheKey);
  if (cached) return {
    url: cached.url,
    expiresIn: Math.max(1, Math.floor((cached.expiresAt - Date.now()) / 1000))
  };
  let url = "";
  const candidates = isRetainedProfile
    ? photoObjectCandidates(reference.bucketId, reference.objectName)
    : [reference.objectName];
  const missingFailures = [];
  const signingFailures = [];
  for (const objectName of candidates) {
    let signed = null;
    let batchSigned = null;
    const attemptErrors = [];
    try {
      signed = await manager().storage.signObject({
        bucketId: reference.bucketId,
        objectName,
        expiresIn,
        accessToken: storage.accessToken,
        envId: storage.envId
      });
      url = signedPhotoUrl(signed);
    } catch (error) {
      attemptErrors.push(error);
    }
    // Always try the documented batch endpoint after a single-object error
    // or response-shape mismatch. Some PG Storage gateways intermittently
    // reject one endpoint while the other can still sign the same object.
    if (!url && typeof manager().storage.signObjects === "function") {
      try {
        batchSigned = await manager().storage.signObjects({
          bucketId: reference.bucketId,
          paths: [objectName],
          expiresIn,
          accessToken: storage.accessToken,
          envId: storage.envId
        });
        url = signedPhotoUrl(batchSigned);
      } catch (error) {
        attemptErrors.push(error);
      }
    }
    if (url) break;

    const responseError = responseErrorText([signed, batchSigned]);
    if (responseError) attemptErrors.push({ message: responseError });
    const failures = attemptErrors.map((error) => ({
      objectName,
      code: String(error?.code || ""),
      requestId: error?.requestId || error?.RequestId || "",
      message: String(error?.message || "").slice(0, 240)
    }));
    if (failures.length && failures.every((failure) => storageObjectMissing(failure))) {
      missingFailures.push(...failures);
    } else {
      signingFailures.push(...(failures.length ? failures : [{
        objectName,
        responseShape: safeResponseShape([signed, batchSigned]),
        responseError: responseError.slice(0, 240)
      }]));
    }
  }
  if (!url && missingFailures.length > 0 && signingFailures.length === 0) {
    console.warn("Verification photo object is missing", {
      bucketId: reference.bucketId,
      candidates,
      failures: missingFailures
    });
    fail("该核销照片文件已不存在。", "PHOTO_NOT_FOUND");
  }
  if (!url) {
    console.error("Verification photo signing returned no HTTPS URL", {
      bucketId: reference.bucketId,
      candidates,
      failures: signingFailures
    });
    fail("核销照片临时访问地址生成失败，请查看云函数日志中的签名阶段错误。", "PHOTO_SIGN_FAILED");
  }
  if (options.thumbnailTransform === true) url = thumbnailTransformUrl(url);
  const cacheEntry = { url, expiresAt: Date.now() + expiresIn * 1000 };
  signedVerificationPhotoCache.set(cacheKey, cacheEntry);
  while (signedVerificationPhotoCache.size > 1000) {
    signedVerificationPhotoCache.delete(signedVerificationPhotoCache.keys().next().value);
  }
  return { url, expiresIn: Math.max(1, Math.floor((cacheEntry.expiresAt - Date.now()) / 1000)) };
}

function rounded(value) {
  return Math.round(Number(value || 0) * 10) / 10;
}

async function inspectFaceImage(api, base64) {
  let result;
  try {
    result = await api.DetectFace({
      Image: base64,
      MaxFaceNum: 2,
      MinFaceSize: 34,
      NeedFaceAttributes: 1,
      NeedQualityDetection: 1,
      FaceModelVersion: FACE_MODEL_VERSION,
      NeedRotateDetection: 0
    });
  } catch (error) {
    if (String(error?.code || "").includes("NoFaceInPhoto")) fail("没有检测到清晰人脸，请让客户正对镜头后重新拍照。", "FACE_NOT_FOUND");
    throw error;
  }

  const faces = Array.isArray(result?.FaceInfos) ? result.FaceInfos : [];
  if (!faces.length) fail("没有检测到清晰人脸，请让客户正对镜头后重新拍照。", "FACE_NOT_FOUND");
  if (faces.length !== 1) fail("照片中只能有一位客户，请移开其他人员后重新拍照。", "MULTIPLE_FACES");

  const face = faces[0] || {};
  const width = Number(face.Width || 0);
  const height = Number(face.Height || 0);
  if (width < 100 || height < 100) fail("人脸距离镜头太远，请靠近镜头后重新拍照。", "FACE_TOO_SMALL");

  const quality = face.FaceQualityInfo || {};
  const attributes = face.FaceAttributesInfo || {};
  const settings = faceSettings();
  const qualityScore = Number(quality.Score || 0);
  if (qualityScore < settings.qualityThreshold) {
    fail(`照片质量不足（${rounded(qualityScore)} 分），请保证光线均匀、镜头清晰后重新拍照。`, "FACE_QUALITY_LOW");
  }
  if (attributes.Mask === true) fail("建档照片不能佩戴口罩，请摘下口罩后重新拍照。", "FACE_MASKED");
  if (attributes.EyeOpen === false) fail("检测到闭眼，请睁眼后重新拍照。", "EYES_CLOSED");

  const yaw = Number(attributes.Yaw || 0);
  const pitch = Number(attributes.Pitch || 0);
  const roll = Number(attributes.Roll || 0);
  if (Math.abs(yaw) > settings.maxYaw || Math.abs(pitch) > settings.maxPitch || Math.abs(roll) > settings.maxRoll) {
    fail("脸部角度过大，请正对镜头、不要低头或歪头后重新拍照。", "FACE_POSE_INVALID");
  }

  return {
    requestId: result?.RequestId || "",
    imageWidth: Number(result?.ImageWidth || 0),
    imageHeight: Number(result?.ImageHeight || 0),
    faceWidth: width,
    faceHeight: height,
    qualityScore: rounded(qualityScore),
    qualityThreshold: settings.qualityThreshold,
    sharpness: rounded(quality.Sharpness),
    brightness: rounded(quality.Brightness),
    yaw: rounded(yaw),
    pitch: rounded(pitch),
    roll: rounded(roll)
  };
}

async function inspectLiveness(api, base64) {
  const settings = faceSettings();
  if (!settings.livenessEnabled) return { enabled: false, checked: false, score: null, threshold: settings.livenessThreshold };
  const result = await api.DetectLiveFaceAccurate({ Image: base64, FaceModelVersion: FACE_MODEL_VERSION });
  const score = Number(result?.Score || 0);
  if (score < settings.livenessThreshold) {
    fail(`活体检测未通过（${rounded(score)} 分），请确认是真人现场拍摄后重试。`, "LIVENESS_FAILED");
  }
  return { enabled: true, checked: true, score: rounded(score), threshold: settings.livenessThreshold, requestId: result?.RequestId || "" };
}

function validDate(value) {
  const date = String(value || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) fail("Birth date must use YYYY-MM-DD.");
  const parsed = new Date(`${date}T00:00:00.000Z`);
  if (Number.isNaN(parsed.valueOf()) || parsed.toISOString().slice(0, 10) !== date) fail("Birth date is invalid.");
  return date;
}

function customerCode(storeId, clientRequestId = "") {
  if (clientRequestId) {
    let storeToken;
    try { storeToken = BigInt(String(storeId)).toString(36).toUpperCase(); }
    catch (_) { storeToken = String(storeId).replace(/[^A-Za-z0-9]/g, "").slice(-12).toUpperCase() || "0"; }
    const requestToken = crypto.createHash("sha256").update(clientRequestId).digest("hex").slice(0, 16).toUpperCase();
    return `C${storeToken}-${requestToken}`;
  }
  const stamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `C${storeId}-${stamp}-${random}`;
}

function optionalClientRequestId(value) {
  const requestId = String(value || "").trim();
  if (!requestId) return "";
  if (!/^[A-Za-z0-9_-]{8,96}$/.test(requestId)) fail("clientRequestId is invalid.", "BAD_REQUEST");
  return requestId;
}

async function activeStoreCaller() {
  const { uid } = app().auth().getUserInfo();
  if (!uid) fail("Please sign in before creating a customer.", "UNAUTHENTICATED");
  const layout = await getStoreBindingLayout();
  const storeJoin = layout === "stores"
    ? "JOIN public.stores s ON s.store_account_id = a.id"
    : `JOIN public.staff_store_assignments sa
         ON sa.staff_account_id = a.id AND sa.assignment_status = 'ACTIVE'
       JOIN public.stores s ON s.id = sa.store_id`;
  const rows = await executeSql(
    `SELECT a.id AS staff_id, a.staff_name, a.phone, a.role_code, a.account_status,
            s.id AS store_id, s.store_code, s.store_name, s.store_status
       FROM public.staff_accounts a
       ${storeJoin}
      WHERE a.auth_uid = ${sqlText(uid)}
      LIMIT 1`
  );
  const caller = rows[0];
  if (!caller || caller.role_code !== "store") fail("Only an active store account can create a customer.", "FORBIDDEN");
  if (caller.account_status !== "ACTIVE" || caller.store_status !== "ACTIVE") fail("The store account or store is archived.", "ARCHIVED");
  return {
    uid: String(uid),
    staffId: Number(caller.staff_id),
    staffName: String(caller.staff_name || ""),
    storeId: Number(caller.store_id),
    storeCode: String(caller.store_code || ""),
    storeName: String(caller.store_name || "")
  };
}

async function activeTeacherCaller() {
  const { uid } = app().auth().getUserInfo();
  if (!uid) fail("请先登录老师账号后再办理业务。", "UNAUTHENTICATED");
  const rows = await executeSql(
    `SELECT a.id AS staff_id, a.staff_name, a.phone, a.role_code, a.account_status,
            t.id AS teacher_id, t.teacher_code, t.teacher_name, t.teacher_status
       FROM public.staff_accounts a
       JOIN public.teachers t ON t.staff_account_id = a.id
      WHERE a.auth_uid = ${sqlText(uid)}
      LIMIT 1`
  );
  const caller = rows[0];
  if (!caller || caller.role_code !== "teacher") fail("只有老师账号可以使用老师办理入口。", "FORBIDDEN");
  if (caller.account_status !== "ACTIVE" || caller.teacher_status !== "ACTIVE") {
    fail("老师账号或老师资料已经封存。", "ARCHIVED");
  }
  return {
    uid: String(uid),
    role: "teacher",
    staffId: Number(caller.staff_id),
    staffName: String(caller.staff_name || caller.teacher_name || ""),
    teacherId: String(caller.teacher_id),
    teacherCode: String(caller.teacher_code || ""),
    teacherName: String(caller.teacher_name || ""),
    teacherPhone: String(caller.phone || "")
  };
}

async function activeBusinessCaller(event = {}) {
  const { uid } = app().auth().getUserInfo();
  if (!uid) fail("请先登录后再办理业务。", "UNAUTHENTICATED");
  const accounts = await executeSql(
    `SELECT a.id AS staff_id, a.phone, a.role_code, a.account_status,
             t.id AS teacher_id, t.teacher_code, t.teacher_name, t.teacher_status
       FROM public.staff_accounts a
       LEFT JOIN public.teachers t ON t.staff_account_id = a.id
      WHERE a.auth_uid = ${sqlText(uid)}
      LIMIT 1`
  );
  const account = accounts[0];
  if (!account) fail("当前登录账号尚未绑定业务身份。", "STAFF_PROFILE_MISSING");
  if (account.account_status !== "ACTIVE") fail("当前登录账号已经封存。", "ARCHIVED");
  if (account.role_code === "store") {
    const store = await activeStoreCaller();
    const requestedStore = String(event.storeId || "").trim();
    if (requestedStore && requestedStore !== String(store.storeId)) {
      fail("门店账号不能为其他门店办理业务。", "FORBIDDEN");
    }
    return { ...store, role: "store", teacherId: "" };
  }
  if (account.role_code !== "teacher") {
    fail("只有门店或老师账号可以办理业务。", "FORBIDDEN");
  }

  if (!account.teacher_id) fail("当前老师账号尚未绑定老师资料。", "TEACHER_PROFILE_MISSING");
  if (account.teacher_status !== "ACTIVE") fail("老师资料已经封存。", "ARCHIVED");
  const storeId = positiveDatabaseId(event.storeId, "门店");
  const stores = await executeSql(
    `SELECT id, store_code, store_name, store_status
       FROM public.stores
      WHERE id = ${sqlText(storeId)}::bigint
        AND store_status = 'ACTIVE'
      LIMIT 1`
  );
  const store = stores[0];
  if (!store) fail("所选门店不存在或已经封存，请重新选择。", "STORE_NOT_ACTIVE");
  return {
    uid: String(uid),
    role: String(account.role_code),
    staffId: Number(account.staff_id),
    teacherId: String(account.teacher_id),
    teacherCode: String(account.teacher_code || ""),
    teacherName: String(account.teacher_name || ""),
    teacherPhone: String(account.phone || ""),
    storeId: Number(store.id),
    storeCode: String(store.store_code || ""),
    storeName: String(store.store_name || "")
  };
}

async function activeCustomerCreationCaller(event = {}) {
  const caller = await activeBusinessCaller(event);
  if (!["store", "teacher"].includes(caller.role)) {
    fail("只有门店或老师账号可以建立客户档案。", "FORBIDDEN");
  }
  return caller;
}

async function getHqBusinessContext() {
  fail("总部账号不能办理业务，请使用门店或老师账号。", "FORBIDDEN");
}

async function getTeacherBusinessContext() {
  const teacher = await activeTeacherCaller();
  const stores = await executeSql(
    `SELECT id, store_code, store_name
       FROM public.stores
      WHERE store_status = 'ACTIVE'
      ORDER BY store_name, store_code, id
      LIMIT 1000`
  );
  return {
    ok: true,
    teacher: {
      teacherId: teacher.teacherId,
      teacherCode: teacher.teacherCode,
      teacherName: teacher.teacherName,
      teacherPhone: teacher.teacherPhone
    },
    stores: stores.map((store) => ({
      storeId: String(store.id),
      storeCode: String(store.store_code || ""),
      storeName: String(store.store_name || "")
    }))
  };
}

async function activeCustomerStatusCaller() {
  const { uid } = app().auth().getUserInfo();
  if (!uid) fail("请先登录后再管理客户状态。", "UNAUTHENTICATED");
  const rows = await executeSql(
    `SELECT id AS staff_id, role_code, account_status
       FROM public.staff_accounts
      WHERE auth_uid = ${sqlText(uid)}
      LIMIT 1`
  );
  const account = rows[0];
  if (!account) fail("当前登录账号尚未绑定业务身份。", "STAFF_PROFILE_MISSING");
  if (account.account_status !== "ACTIVE") fail("当前登录账号已封存。", "ARCHIVED");
  if (account.role_code === "hq") {
    return { uid: String(uid), staffId: Number(account.staff_id), role: "hq", storeId: null };
  }
  if (account.role_code === "store") {
    const store = await activeStoreCaller();
    return { ...store, role: "store" };
  }
  fail("只有总部或客户所属门店可以修改客户状态。", "FORBIDDEN");
}

// Customer and business-record query pages are shared by headquarters and
// stores.  The authenticated CloudBase UID is always the source of authority:
// stores are pinned to their active binding, while HQ may optionally narrow an
// otherwise global query to one real store. Retired roles are deliberately not
// included in this contract.
async function activeScopedQueryCaller(event = {}) {
  const caller = await activeCustomerStatusCaller();
  const requestedStore = String(event.storeId || "").trim();
  if (caller.role === "store") {
    if (requestedStore && requestedStore !== String(caller.storeId)) {
      fail("门店账号不能查询其他门店或全部门店。", "FORBIDDEN");
    }
    return { ...caller, storeId: String(caller.storeId), scopeMode: "STORE" };
  }

  if (!requestedStore || requestedStore.toUpperCase() === "ALL") {
    return {
      ...caller,
      storeId: null,
      storeCode: "",
      storeName: "全部门店",
      storeStatus: "",
      scopeMode: "ALL"
    };
  }

  const storeId = businessQueryDatabaseId(requestedStore, "门店");
  const stores = await executeSql(
    `SELECT id, store_code, store_name, store_status
       FROM public.stores
      WHERE id = ${storeId}::bigint
      LIMIT 1`
  );
  const store = stores[0];
  if (!store) fail("所选门店不存在，请刷新门店列表后重试。", "STORE_NOT_FOUND");
  return {
    ...caller,
    storeId: String(store.id),
    storeCode: String(store.store_code || ""),
    storeName: String(store.store_name || ""),
    storeStatus: String(store.store_status || ""),
    scopeMode: "STORE"
  };
}

function scopedStoreClause(caller, column) {
  const store = caller.storeId ? `${column} = ${caller.storeId}::bigint` : "TRUE";
  return caller.teamCustomerScope ? `(${store} AND ${caller.teamCustomerScope})` : store;
}

function teacherTeamReads() {
  if (!teacherTeamReadService) teacherTeamReadService = require("./teacher-team").createTeacherTeamReads({
    executeSql, sqlText, fail, activeTeacherCaller, positiveDatabaseId, teacherBusinessAttributionSourceCondition
  });
  return teacherTeamReadService;
}

async function activeCustomerProfileCaller() {
  const { uid } = app().auth().getUserInfo();
  if (!uid) fail("请先登录后再查看客户主页。", "UNAUTHENTICATED");
  const rows = await executeSql(
    `SELECT a.id AS staff_id, a.role_code, a.account_status, a.staff_name,
            t.id AS teacher_id, t.teacher_name, t.teacher_status
       FROM public.staff_accounts a
  LEFT JOIN public.teachers t ON t.staff_account_id = a.id
      WHERE a.auth_uid = ${sqlText(uid)}
      LIMIT 1`
  );
  const account = rows[0];
  if (!account) fail("当前登录账号尚未绑定业务身份。", "STAFF_PROFILE_MISSING");
  if (account.account_status !== "ACTIVE") fail("当前登录账号已封存。", "ARCHIVED");
  if (account.role_code === "store") {
    const store = await activeStoreCaller();
    return { ...store, role: "store", staffName: String(account.staff_name || store.staffName || "") };
  }
  if (account.role_code === "hq") {
    return { uid: String(uid), staffId: Number(account.staff_id), staffName: String(account.staff_name || ""), role: "hq", storeId: null, teacherId: "" };
  }
  if (account.role_code === "teacher") {
    if (!account.teacher_id || account.teacher_status !== "ACTIVE") fail("老师资料已经封存。", "ARCHIVED");
    return {
      uid: String(uid), staffId: Number(account.staff_id),
      staffName: String(account.staff_name || account.teacher_name || ""),
      role: "teacher", storeId: null, teacherId: String(account.teacher_id)
    };
  }
  fail("当前登录身份无权查看客户主页。", "FORBIDDEN");
}

async function activeVerificationPhotoCaller() {
  const { uid } = app().auth().getUserInfo();
  if (!uid) fail("请先登录后再查看核销照片。", "UNAUTHENTICATED");
  const rows = await executeSql(
    `SELECT a.id AS staff_id, a.role_code, a.account_status,
            t.id AS teacher_id, t.teacher_status
       FROM public.staff_accounts a
  LEFT JOIN public.teachers t ON t.staff_account_id = a.id
      WHERE a.auth_uid = ${sqlText(uid)}
      LIMIT 1`
  );
  const account = rows[0];
  if (!account) fail("当前登录账号尚未绑定业务身份。", "STAFF_PROFILE_MISSING");
  if (account.account_status !== "ACTIVE") fail("当前登录账号已封存。", "ARCHIVED");
  if (!['hq', 'store', 'teacher'].includes(account.role_code)) {
    fail("当前登录身份无权查看核销照片。", "FORBIDDEN");
  }
  if (account.role_code === "store") {
    const store = await activeStoreCaller();
    return { ...store, role: "store", staffId: Number(account.staff_id), teacherId: "" };
  }
  if (account.role_code === "teacher") {
    if (!account.teacher_id || account.teacher_status !== "ACTIVE") fail("老师资料已经封存。", "ARCHIVED");
    return {
      uid: String(uid), role: "teacher", staffId: Number(account.staff_id),
      storeId: null, teacherId: String(account.teacher_id)
    };
  }
  return { uid: String(uid), role: account.role_code, staffId: Number(account.staff_id), storeId: null, teacherId: "" };
}

async function verificationPhotoContext(event, options = {}) {
  const caller = options.caller || await activeVerificationPhotoCaller();
  const verificationId = businessQueryDatabaseId(event.recordId, "核销工单");
  let scope = "TRUE";
  if (caller.role === "store") scope = `v.store_id = ${Number(caller.storeId)}::bigint`;
  else if (caller.role === "teacher") scope = `(
    ${teacherBusinessOwnershipCondition(caller, "v")}
    OR (
      v.record_status = 'APPROVED'
      AND ${teacherBusinessAttributionCondition(caller, "v", "VERIFICATION")}
    )
    OR EXISTS (
      SELECT 1
        FROM public.customers permitted_customer
       WHERE permitted_customer.id = v.customer_id
         AND ${teacherCustomerAccessCondition(caller, "permitted_customer")}
    )
  )`;
  const lookup = options.allowTeacherLookupRead ? parseTeacherLookup(event, caller.role, fail) : null;
  if (lookup) scope = `EXISTS (SELECT 1 FROM public.customers lookup_customer
    WHERE lookup_customer.id = v.customer_id AND ${lookupCustomerCondition(lookup, "lookup_customer", sqlText)})`;
  const rows = await executeSql(
    `SELECT v.id, v.verification_code, v.verification_type, v.store_id,
            v.teacher_id, v.submitted_by_account_id, v.submitted_at,
            v.customer_id, v.face_subject_type, v.face_subject_teacher_id,
            customer.customer_code, customer.customer_name,
            face_teacher.teacher_code AS face_subject_teacher_code,
            face_teacher.teacher_name AS face_subject_teacher_name,
            v.submitted_at + INTERVAL '24 hours' AS editable_until,
            (CLOCK_TIMESTAMP() < v.submitted_at + INTERVAL '24 hours') AS within_edit_window
       FROM public.verification_records v
       JOIN public.customers customer ON customer.id = v.customer_id
  LEFT JOIN public.teachers face_teacher ON face_teacher.id = v.face_subject_teacher_id
      WHERE v.id = ${verificationId}::bigint
        AND ${scope}
      LIMIT 1`
  );
  const record = rows[0];
  if (!record) fail("未找到当前账号有权查看的核销工单。", "VERIFICATION_NOT_FOUND");
  const canEdit = !lookup && ["hq", "store", "teacher"].includes(caller.role)
    && String(record.submitted_by_account_id) === String(caller.staffId)
    && databaseBoolean(record.within_edit_window);
  return { caller, record, verificationId, canEdit };
}

function teacherBusinessAttributionSourceCondition(alias, recordFamily) {
  const storeCategory = recordFamily === "RECHARGE"
    ? `${alias}.recharge_type IN ('NEW', 'REFUND')`
    : `${alias}.verification_type IN ('NORMAL', 'SUPPLEMENT')`;
  const teacherCategory = recordFamily === "RECHARGE"
    ? `${alias}.recharge_type IN ('NEW', 'REFUND')`
    : `${alias}.verification_type IN ('NORMAL', 'SUPPLEMENT', 'EXPERIENCE')`;
  if (!["RECHARGE", "VERIFICATION"].includes(recordFamily)) {
    throw new Error("Business teacher attribution requires a record family.");
  }
  return `EXISTS (
    SELECT 1
      FROM public.staff_accounts attribution_submitter
 LEFT JOIN public.teachers attribution_submitter_teacher
        ON attribution_submitter_teacher.staff_account_id = attribution_submitter.id
     WHERE attribution_submitter.id = ${alias}.submitted_by_account_id
       AND (
         (
           attribution_submitter.role_code = 'store'
           AND ${storeCategory}
         )
         OR (
           attribution_submitter.role_code = 'teacher'
           AND attribution_submitter_teacher.id = ${alias}.teacher_id
           AND ${teacherCategory}
         )
       )
  )`;
}

function trustedBusinessTeacherIdSql(alias, recordFamily) {
  return `CASE
    WHEN ${teacherBusinessAttributionSourceCondition(alias, recordFamily)} THEN ${alias}.teacher_id
    ELSE NULL::bigint
  END`;
}

function teacherBusinessOwnershipCondition(caller, alias) {
  return `${alias}.submitted_by_account_id = ${sqlText(caller.staffId)}::bigint`;
}

function teacherBusinessAttributionCondition(caller, alias, recordFamily) {
  return `(
    ${alias}.teacher_id = ${sqlText(caller.teacherId)}::bigint
    AND ${teacherBusinessAttributionSourceCondition(alias, recordFamily)}
  )`;
}

function teacherCustomerAccessCondition(caller, alias = "c") {
  return `(
    ${alias}.created_by_account_id = ${sqlText(caller.staffId)}::bigint
    OR EXISTS (
      SELECT 1 FROM public.verification_records teacher_verification
       WHERE teacher_verification.customer_id = ${alias}.id
         AND ${teacherBusinessAttributionCondition(caller, "teacher_verification", "VERIFICATION")}
         AND teacher_verification.record_status = 'APPROVED'
         AND teacher_verification.verification_type IN ('NORMAL', 'SUPPLEMENT', 'EXPERIENCE')
    )
    OR EXISTS (
      SELECT 1 FROM public.recharge_records teacher_recharge
       WHERE teacher_recharge.customer_id = ${alias}.id
         AND ${teacherBusinessAttributionCondition(caller, "teacher_recharge", "RECHARGE")}
         AND teacher_recharge.record_status = 'APPROVED'
         AND teacher_recharge.recharge_type IN ('NEW', 'REFUND')
    )
    OR EXISTS (
      SELECT 1 FROM public.retail_product_purchase_records teacher_purchase
       WHERE teacher_purchase.customer_id = ${alias}.id
         AND teacher_purchase.teacher_id = ${sqlText(caller.teacherId)}::bigint
         AND teacher_purchase.submitted_by_account_id = ${sqlText(caller.staffId)}::bigint
         AND teacher_purchase.record_status = 'APPROVED'
    )
  )`;
}

function customerProfileScope(caller, alias = "c") {
  if (caller.role === "store") return ` AND ${alias}.created_store_id = ${caller.storeId}`;
  if (caller.role === "teacher") return ` AND ${teacherCustomerAccessCondition(caller, alias)}`;
  return "";
}

function customerStatusCode(event) {
  const customerCodeValue = String(event.customerCode || "").trim();
  if (!customerCodeValue || customerCodeValue.length > 96) fail("必须提供有效客户编号。", "CUSTOMER_REQUIRED");
  return customerCodeValue;
}

function customerStatusScope(caller, tableAlias = "") {
  const column = tableAlias ? `${tableAlias}.created_store_id` : "created_store_id";
  return caller.storeId ? ` AND ${column} = ${caller.storeId}` : "";
}

async function findCustomerStatus(caller, customerCodeValue) {
  const rows = await executeSql(
    `SELECT c.id, c.customer_code, c.customer_name, c.birth_date, c.notes,
            c.created_store_id, c.customer_status, c.created_at, c.updated_at,
            s.store_name, s.store_code
       FROM public.customers c
       JOIN public.stores s ON s.id = c.created_store_id
      WHERE c.customer_code = ${sqlText(customerCodeValue)}
        ${customerStatusScope(caller, "c")}
      LIMIT 1`
  );
  return rows[0] || null;
}

async function findCustomerForNotes(caller, customerCodeValue) {
  const rows = await executeSql(
    `SELECT c.id, c.customer_code, c.customer_name, c.birth_date, c.notes,
            c.created_store_id, c.customer_status, c.created_at, c.updated_at,
            s.store_name, s.store_code
       FROM public.customers c
       JOIN public.stores s ON s.id = c.created_store_id
      WHERE c.customer_code = ${sqlText(customerCodeValue)}
        ${customerProfileScope(caller, "c")}
      LIMIT 1`
  );
  return rows[0] || null;
}

function customerStatusResult(customer) {
  return {
    ok: true,
    customer: {
      id: String(customer.id),
      customerCode: customer.customer_code,
      customerName: customer.customer_name,
      birthDate: customer.birth_date,
      notes: customer.notes || "",
      storeId: String(customer.created_store_id),
      storeName: customer.store_name,
      storeCode: customer.store_code,
      customerStatus: customer.customer_status,
      createdAt: customer.created_at,
      updatedAt: customer.updated_at
    }
  };
}

async function getCustomerStatus(event) {
  const caller = await activeCustomerStatusCaller();
  const customerCodeValue = customerStatusCode(event);
  const customer = await findCustomerStatus(caller, customerCodeValue);
  if (!customer) fail("未找到当前账号有权查看的客户档案。", "CUSTOMER_NOT_FOUND");
  return customerStatusResult(customer);
}

async function updateCustomerStatus(event) {
  const caller = await activeCustomerStatusCaller();
  const customerCodeValue = customerStatusCode(event);
  const targetStatus = String(event.targetStatus || "").trim().toUpperCase();
  const expectedStatus = String(event.expectedStatus || "").trim().toUpperCase();
  if (!["ACTIVE", "ARCHIVED"].includes(targetStatus)) fail("客户状态只能切换为活跃或封存。", "CUSTOMER_STATUS_INVALID");
  if (expectedStatus && !["ACTIVE", "ARCHIVED"].includes(expectedStatus)) fail("原客户状态无效，请刷新后重试。", "CUSTOMER_STATUS_INVALID");

  const before = await findCustomerStatus(caller, customerCodeValue);
  if (!before) fail("未找到当前账号有权管理的客户档案。", "CUSTOMER_NOT_FOUND");
  if (expectedStatus && before.customer_status !== expectedStatus && before.customer_status !== targetStatus) {
    fail("客户状态已被其他人员修改，请刷新后重试。", "CUSTOMER_STATUS_CONFLICT");
  }
  if (before.customer_status !== targetStatus) {
    await executeSql(
      `UPDATE public.customers
          SET customer_status = ${sqlText(targetStatus)}, updated_at = NOW()
        WHERE customer_code = ${sqlText(customerCodeValue)}
          ${customerStatusScope(caller)}
          AND customer_status = ${sqlText(before.customer_status)}`
    );
  }
  const customer = await findCustomerStatus(caller, customerCodeValue);
  if (!customer) fail("客户状态更新后无法读取档案。", "DATABASE_ERROR");
  if (customer.customer_status !== targetStatus) fail("客户状态已被其他人员修改，请刷新后重试。", "CUSTOMER_STATUS_CONFLICT");
  return customerStatusResult(customer);
}

async function updateCustomerNotes(event) {
  const caller = await activeCustomerProfileCaller();
  const customerCodeValue = customerStatusCode(event);
  const notes = String(event.notes ?? "").replace(/\r\n?/g, "\n").trim();
  const hasExpectedNotes = Object.prototype.hasOwnProperty.call(event, "expectedNotes");
  const expectedNotes = String(event.expectedNotes ?? "").replace(/\r\n?/g, "\n").trim();
  if (notes.length > 5000) fail("客户备注不能超过 5000 个字符。", "CUSTOMER_NOTES_TOO_LONG");
  if (expectedNotes.length > 5000) fail("原客户备注无效，请刷新后重试。", "CUSTOMER_NOTES_INVALID");

  const before = await findCustomerForNotes(caller, customerCodeValue);
  if (!before) fail("未找到当前账号有权管理的客户档案。", "CUSTOMER_NOT_FOUND");
  const currentNotes = String(before.notes || "").replace(/\r\n?/g, "\n").trim();
  if (hasExpectedNotes && currentNotes !== expectedNotes) {
    fail("客户备注已被其他人员修改，请刷新后重试。", "CUSTOMER_NOTES_CONFLICT");
  }
  if (currentNotes !== notes) {
    await executeSql(
      `UPDATE public.customers AS c
          SET notes = ${sqlText(notes)}, updated_at = NOW()
        WHERE c.customer_code = ${sqlText(customerCodeValue)}
          ${customerProfileScope(caller, "c")}
          AND COALESCE(c.notes, '') = ${sqlText(String(before.notes || ""))}`
    );
  }
  const customer = await findCustomerForNotes(caller, customerCodeValue);
  if (!customer) fail("客户备注更新后无法读取档案。", "DATABASE_ERROR");
  if (String(customer.notes || "").replace(/\r\n?/g, "\n").trim() !== notes) {
    fail("客户备注已被其他人员修改，请刷新后重试。", "CUSTOMER_NOTES_CONFLICT");
  }
  return customerStatusResult(customer);
}

async function executeCustomerMessageSql(sql) {
  try { return await executeSql(sql); }
  catch (error) {
    if (/customer_messages.*does not exist|relation .*customer_messages/i.test(String(error?.message || ""))) {
      fail("客户留言数据库尚未升级，请先执行 042 客户留言迁移。", "DATABASE_SCHEMA_MISSING");
    }
    throw error;
  }
}

function customerMessageOptions(event = {}) {
  const requestedLimit = Number(event.messageLimit);
  const limit = Number.isFinite(requestedLimit)
    ? Math.min(Math.max(Math.trunc(requestedLimit), 1), 50)
    : 20;
  const cursorCreatedAt = scopedQueryCursorTimestamp(event.cursorCreatedAt, "客户留言游标时间");
  const cursorId = String(event.cursorMessageId || "").trim();
  if (Boolean(cursorCreatedAt) !== Boolean(cursorId)) fail("客户留言游标不完整。", "BAD_REQUEST");
  return {
    limit,
    cursorCreatedAt,
    cursorId: cursorId ? businessQueryDatabaseId(cursorId, "客户留言游标编号") : ""
  };
}

async function customerMessageCustomer(caller, customerCodeValue) {
  const rows = await executeSql(
    `SELECT c.id, c.customer_code
       FROM public.customers c
      WHERE c.customer_code = ${sqlText(customerCodeValue)}
        ${customerProfileScope(caller, "c")}
      LIMIT 1`
  );
  const customer = rows[0];
  if (!customer) fail("未找到当前账号有权留言的客户档案。", "CUSTOMER_NOT_FOUND");
  return customer;
}

function mapCustomerMessage(row) {
  return {
    id: String(row.id),
    authorName: String(row.author_name_snapshot || ""),
    authorRole: String(row.author_role || ""),
    content: String(row.message_content || ""),
    createdAt: row.created_at
  };
}

async function listCustomerMessages(event) {
  const caller = await activeCustomerProfileCaller();
  const customerCodeValue = customerStatusCode(event);
  const customers = await executeCustomerMessageSql(`SELECT c.id FROM public.customers c
    WHERE c.customer_code = ${sqlText(customerCodeValue)} ${customerLookupReadScope(caller, event)} LIMIT 1`);
  const customer = customers[0];
  if (!customer) fail("未找到有权查看的客户留言。", "CUSTOMER_NOT_FOUND");
  const options = customerMessageOptions(event);
  const cursor = options.cursorCreatedAt
    ? `AND (cm.created_at, cm.id) < (${sqlText(options.cursorCreatedAt)}::timestamptz, ${options.cursorId}::bigint)`
    : "";
  const rows = await executeCustomerMessageSql(
    `SELECT cm.id, cm.author_role, cm.author_name_snapshot,
            cm.message_content, cm.created_at,
            TO_CHAR(cm.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS cursor_created_at,
            (SELECT COUNT(*) FROM public.customer_messages total
              WHERE total.customer_id = cm.customer_id) AS total_count
       FROM public.customer_messages cm
      WHERE cm.customer_id = ${sqlText(String(customer.id))}::bigint
        ${cursor}
      ORDER BY cm.created_at DESC, cm.id DESC
      LIMIT ${options.limit + 1}`
  );
  const hasMore = rows.length > options.limit;
  const visibleRows = rows.slice(0, options.limit);
  const last = visibleRows[visibleRows.length - 1];
  return {
    ok: true,
    messages: visibleRows.map(mapCustomerMessage),
    totalCount: Number(rows[0]?.total_count || 0),
    page: {
      hasMore,
      nextCursor: hasMore && last
        ? { createdAt: last.cursor_created_at, id: String(last.id) }
        : null
    }
  };
}

async function addCustomerMessage(event) {
  const caller = await activeCustomerProfileCaller();
  const customerCodeValue = customerStatusCode(event);
  const customer = await customerMessageCustomer(caller, customerCodeValue);
  const content = String(event.content ?? "").replace(/\r\n?/g, "\n").trim();
  const contentLength = Array.from(content).length;
  if (!contentLength) fail("请输入留言内容。", "CUSTOMER_MESSAGE_REQUIRED");
  if (contentLength > 100) fail("单条客户留言不能超过 100 字。", "CUSTOMER_MESSAGE_TOO_LONG");
  const rows = await executeCustomerMessageSql(
    `WITH inserted_message AS (
       INSERT INTO public.customer_messages
         (customer_id, author_account_id, author_role, author_name_snapshot, message_content)
       SELECT ${sqlText(String(customer.id))}::bigint, a.id, a.role_code,
              BTRIM(a.staff_name), ${sqlText(content)}
         FROM public.staff_accounts a
        WHERE a.id = ${positiveDatabaseId(caller.staffId, "当前留言账号")}::bigint
          AND a.account_status = 'ACTIVE'
          AND a.role_code IN ('hq', 'store', 'teacher')
       RETURNING id, author_role, author_name_snapshot, message_content, created_at
     )
     SELECT id, author_role, author_name_snapshot, message_content, created_at
       FROM inserted_message
      LIMIT 1`
  );
  const message = rows[0];
  if (!message) fail("当前登录账号不能提交客户留言。", "FORBIDDEN");
  const totals = await executeCustomerMessageSql(
    `SELECT COUNT(*) AS total_count
       FROM public.customer_messages
      WHERE customer_id = ${sqlText(String(customer.id))}::bigint`
  );
  return { ok: true, message: mapCustomerMessage(message), totalCount: Number(totals[0]?.total_count || 1) };
}

function customerHistoryOptions(event = {}) {
  const numberedPage = event.historyPage !== undefined || event.historyPageSize !== undefined;
  const pageNumber = Number(event.historyPage === undefined ? 1 : event.historyPage);
  if (numberedPage && (!Number.isSafeInteger(pageNumber) || pageNumber < 1 || pageNumber > 100000)) {
    fail("客户业务记录页码必须是 1 至 100000 的整数。", "BAD_REQUEST");
  }
  if (numberedPage && event.historyPageSize !== undefined && Number(event.historyPageSize) !== 10) {
    fail("客户业务记录每页固定为 10 条。", "BAD_REQUEST");
  }
  const requestedLimit = Number(event.historyLimit);
  const limit = numberedPage ? 10 : Number.isFinite(requestedLimit)
    ? Math.min(Math.max(Math.trunc(requestedLimit), 1), 100)
    : 50;
  const type = String(event.historyType || "").trim().toUpperCase();
  if (type && !["RECHARGE", "REFUND", "VERIFICATION", "EXPERIENCE", "PRODUCT_PURCHASE"].includes(type)) fail("客户历史类型无效。", "BAD_REQUEST");
  const cursorSubmittedAt = scopedQueryCursorTimestamp(event.cursorSubmittedAt, "客户历史游标时间");
  const cursorId = String(event.cursorId || "").trim();
  if ((cursorSubmittedAt || cursorId) && !type) fail("客户历史游标必须指定记录类型。", "BAD_REQUEST");
  if (Boolean(cursorSubmittedAt) !== Boolean(cursorId)) fail("客户历史游标不完整。", "BAD_REQUEST");
  if (numberedPage && cursorSubmittedAt) fail("客户业务记录页码不能同时提交游标。", "BAD_REQUEST");
  return {
    limit,
    numberedPage,
    pageNumber,
    type,
    cursorSubmittedAt,
    cursorId: cursorId ? businessQueryDatabaseId(cursorId, "客户历史游标编号") : ""
  };
}

function customerHistorySql(sql, options, table, customerId, category) {
  if (!options.numberedPage) return sql;
  const select = sql.replace(/\n\s*LIMIT \d+\s*$/, "");
  return `WITH history_count AS (
    SELECT COUNT(*)::bigint AS history_total
      FROM public.${table}
     WHERE customer_id = ${sqlText(customerId)}::bigint AND ${category}
  ), history_meta AS (
    SELECT history_total,
           GREATEST(1, CEIL(history_total::numeric / 10))::integer AS history_total_pages,
           LEAST(${options.pageNumber}, GREATEST(1, CEIL(history_total::numeric / 10)))::integer AS history_page
      FROM history_count
  ), history_rows AS (
    ${select}
    LIMIT 10 OFFSET (SELECT (history_page - 1) * 10 FROM history_meta)
  )
  SELECT history_rows.*, history_meta.*
    FROM history_meta LEFT JOIN history_rows ON TRUE
   ORDER BY history_rows.submitted_at DESC, history_rows.id DESC`;
}

function customerHistoryPage(rows, limit, options = {}) {
  if (options.numberedPage) {
    const meta = rows[0] || {};
    const pageNumber = Number(meta.history_page || 1);
    const totalPages = Number(meta.history_total_pages || 1);
    return {
      rows: rows.filter((row) => row.id !== null && row.id !== undefined),
      page: { pageNumber, pageSize: 10, total: Number(meta.history_total || 0), totalPages,
        hasMore: pageNumber < totalPages, nextCursor: null }
    };
  }
  const hasMore = rows.length > limit;
  const visibleRows = rows.slice(0, limit);
  const last = visibleRows[visibleRows.length - 1];
  return {
    rows: visibleRows,
    page: {
      hasMore,
      nextCursor: hasMore && last
        ? { submittedAt: last.cursor_submitted_at, id: String(last.id) }
        : null
    }
  };
}

function mapCustomerRecharges(rows) {
  return rows.map((row) => ({
    id: String(row.id), rechargeCode: row.recharge_code, rechargeType: row.recharge_type,
    unitCount: Number(row.unit_count || 0), recordStatus: row.record_status,
    balanceBeforeCount: row.balance_before_count === null || row.balance_before_count === undefined ? null : Number(row.balance_before_count),
    balanceAfterCount: row.balance_after_count === null || row.balance_after_count === undefined ? null : Number(row.balance_after_count),
    voidRequestStatus: row.void_request_status, submittedAt: row.submitted_at, reviewedAt: row.reviewed_at,
    productId: String(row.product_id), productCode: row.product_code, productName: row.product_name,
    teacherId: row.teacher_id ? String(row.teacher_id) : "", teacherCode: row.teacher_code || "", teacherName: row.teacher_name || ""
  }));
}

function mapCustomerVerifications(rows) {
  return rows.map((row) => ({
    id: String(row.id), verificationCode: row.verification_code, verificationType: row.verification_type,
    unitCount: Number(row.unit_count || 1), recordStatus: row.record_status,
    voidRequestStatus: row.void_request_status, submittedAt: row.submitted_at, reviewedAt: row.reviewed_at,
    productId: String(row.product_id), productCode: row.product_code, productName: row.product_name,
    teacherId: row.teacher_id ? String(row.teacher_id) : "", teacherCode: row.teacher_code || "", teacherName: row.teacher_name || ""
  }));
}

function mapCustomerProductPurchases(rows) {
  return rows.map((row) => ({
    id: String(row.id), purchaseCode: row.purchase_code,
    unitCount: Number(row.unit_count || 0), recordStatus: row.record_status,
    submittedAt: row.submitted_at, reviewedAt: row.reviewed_at,
    retailProductId: String(row.retail_product_id), productName: row.product_name_snapshot,
    teacherId: row.teacher_id ? String(row.teacher_id) : "", teacherCode: row.teacher_code || "", teacherName: row.teacher_name || ""
  }));
}

function customerLookupReadScope(caller, event, alias = "c") {
  const lookup = parseTeacherLookup(event, caller.role, fail);
  if (!lookup) return customerProfileScope(caller, alias);
  return `AND ${lookupCustomerCondition(lookup, alias, sqlText)}`;
}

async function queryTeacherCustomers(event) {
  const caller = await activeCustomerProfileCaller();
  if (caller.role !== "teacher") fail("只有在职老师可以使用此客户查询。", "FORBIDDEN");
  const lookup = parseTeacherLookup(event, caller.role, fail, false);
  if (!lookup || lookup.customerCode) fail("请选择门店并输入完整客户姓名。", "BAD_REQUEST");
  const page = Number(event.page || 1);
  if (!Number.isSafeInteger(page) || page < 1 || page > 100000) fail("查询页码无效。", "BAD_REQUEST");
  const condition = lookupCustomerCondition(lookup, "c", sqlText);
  const countRows = await executeSql(`SELECT COUNT(*) AS total FROM public.customers c WHERE ${condition}`);
  const total = Number(countRows[0]?.total || 0);
  const totalPages = Math.max(1, Math.ceil(total / 10));
  const effectivePage = Math.min(page, totalPages);
  const rows = await executeSql(`SELECT c.customer_code, c.customer_name, c.birth_date,
    c.customer_status, c.customer_process_status, c.created_at, s.store_name,
    (SELECT COALESCE(SUM(r.unit_count), 0) FROM public.recharge_records r
      WHERE r.customer_id = c.id AND r.recharge_type = 'NEW' AND r.record_status = 'APPROVED') AS recharge_count,
    (SELECT COALESCE(SUM(v.unit_count), 0) FROM public.verification_records v
      WHERE v.customer_id = c.id AND v.verification_type IN ('NORMAL', 'SUPPLEMENT') AND v.record_status = 'APPROVED') AS verification_count
    FROM public.customers c JOIN public.stores s ON s.id = c.created_store_id
    WHERE ${condition} ORDER BY c.created_at DESC, c.id DESC LIMIT 10 OFFSET ${(effectivePage - 1) * 10}`);
  return { ok: true, customers: rows.map(row => ({ customerCode: row.customer_code,
    customerName: row.customer_name, birthDate: row.birth_date, storeName: row.store_name,
    customerStatus: row.customer_status, customerProcessStatus: row.customer_process_status, createdAt: row.created_at, rechargeCount: Number(row.recharge_count || 0),
    verificationCount: Number(row.verification_count || 0) })), total, page: effectivePage, totalPages, pageSize: 10 };
}

async function getTeacherLookupProductPurchase(event) {
  const caller = await activeCustomerProfileCaller();
  const lookup = parseTeacherLookup(event, caller.role, fail);
  if (!lookup) fail("请从客户查询结果进入工单。", "FORBIDDEN");
  const id = businessQueryDatabaseId(event.recordId, "产品工单");
  const rows = await executeSql(`SELECT p.id, p.purchase_code, p.record_status, p.unit_count,
    p.product_name_snapshot, p.submitted_at, p.reviewed_at, p.message, p.review_note,
    s.store_name, c.customer_name, t.teacher_name,
    submitter.staff_name AS submitted_by_name, reviewer.staff_name AS reviewed_by_name
    FROM public.retail_product_purchase_records p
    JOIN public.customers c ON c.id = p.customer_id
    JOIN public.stores s ON s.id = p.store_id
    LEFT JOIN public.teachers t ON t.id = p.teacher_id
    LEFT JOIN public.staff_accounts submitter ON submitter.id = p.submitted_by_account_id
    LEFT JOIN public.staff_accounts reviewer ON reviewer.id = p.reviewed_by_account_id
    WHERE p.id = ${id}::bigint AND ${lookupCustomerCondition(lookup, "c", sqlText)} LIMIT 1`);
  if (!rows[0]) fail("未找到有权查看的产品工单。", "ORDER_NOT_FOUND");
  return { ok: true, orders: rows, readOnly: true };
}

async function getCustomerProfile(event) {
  const caller = await activeCustomerProfileCaller();
  const customerCodeValue = customerStatusCode(event);
  const profileScope = customerLookupReadScope(caller, event, "c");
  const customerRows = await executeSql(
    `SELECT c.id, c.customer_code, c.customer_name, c.birth_date, c.notes,
            ${caller.role === "teacher" ? teacherCustomerAccessCondition(caller, "c") : "TRUE"} AS can_edit_customer,
            c.customer_status, c.customer_process_status,
            COALESCE((
              SELECT SUM(recharge.unit_count)
                FROM public.recharge_records recharge
               WHERE recharge.customer_id = c.id
                 AND recharge.recharge_type = 'NEW'
                 AND recharge.record_status = 'APPROVED'
            ), 0)::bigint AS gross_recharge_count,
            COALESCE((
              SELECT SUM(refund.unit_count)
                FROM public.recharge_records refund
               WHERE refund.customer_id = c.id
                 AND refund.recharge_type = 'REFUND'
                 AND refund.record_status = 'APPROVED'
            ), 0)::bigint AS total_refund_count,
            COALESCE((
              SELECT SUM(verification.unit_count)
                FROM public.verification_records verification
               WHERE verification.customer_id = c.id
                 AND verification.record_status = 'APPROVED'
                 AND verification.verification_type IN ('NORMAL', 'SUPPLEMENT')
            ), 0)::bigint AS normal_verification_count,
            c.total_experience_count,
            c.latest_recharge_at, c.latest_verification_at, c.created_at, c.updated_at,
            c.created_store_id, s.store_code, s.store_name
      FROM public.customers c
      JOIN public.stores s ON s.id = c.created_store_id
      WHERE c.customer_code = ${sqlText(customerCodeValue)}
        ${profileScope}
      LIMIT 1`
  );
  const customer = customerRows[0];
  if (!customer) fail("未找到当前账号有权查看的客户档案。", "CUSTOMER_NOT_FOUND");
  const customerId = String(customer.id);
  const historyOptions = customerHistoryOptions(event);
  const cursorSql = historyOptions.cursorSubmittedAt
    ? (alias) => `AND (${alias}.submitted_at, ${alias}.id) < (${sqlText(historyOptions.cursorSubmittedAt)}::timestamptz, ${historyOptions.cursorId}::bigint)`
    : () => "";
  const rechargeSql = (refundOnly = false) => `SELECT r.id, r.recharge_code, r.recharge_type, r.unit_count,
               r.balance_before_count, r.balance_after_count,
               r.record_status, r.void_request_status, r.submitted_at, r.reviewed_at,
               TO_CHAR(r.submitted_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS cursor_submitted_at,
               p.id AS product_id, p.product_code, p.product_name,
               business_teacher.id AS teacher_id,
               business_teacher.teacher_code,
               business_teacher.teacher_name
          FROM public.recharge_records r
          JOIN public.products p ON p.id = r.product_id
     LEFT JOIN public.teachers business_teacher
            ON business_teacher.id = r.teacher_id
           AND ${teacherBusinessAttributionSourceCondition("r", "RECHARGE")}
         WHERE r.customer_id = ${sqlText(customerId)}::bigint
           AND r.recharge_type = '${refundOnly ? "REFUND" : "NEW"}'
           ${historyOptions.type === (refundOnly ? "REFUND" : "RECHARGE") ? cursorSql("r") : ""}
         ORDER BY r.submitted_at DESC, r.id DESC
         LIMIT ${historyOptions.limit + 1}`;
  const verificationSql = (experienceOnly = false) => `SELECT v.id, v.verification_code, v.verification_type, v.unit_count,
               v.record_status, v.void_request_status, v.submitted_at, v.reviewed_at,
               TO_CHAR(v.submitted_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS cursor_submitted_at,
               p.id AS product_id, p.product_code, p.product_name,
               business_teacher.id AS teacher_id,
               business_teacher.teacher_code,
               business_teacher.teacher_name
          FROM public.verification_records v
          JOIN public.products p ON p.id = v.product_id
     LEFT JOIN public.teachers business_teacher
            ON business_teacher.id = v.teacher_id
           AND ${teacherBusinessAttributionSourceCondition("v", "VERIFICATION")}
         WHERE v.customer_id = ${sqlText(customerId)}::bigint
           AND v.verification_type ${experienceOnly ? "=" : "<>"} 'EXPERIENCE'
           ${historyOptions.type === (experienceOnly ? "EXPERIENCE" : "VERIFICATION") ? cursorSql("v") : ""}
         ORDER BY v.submitted_at DESC, v.id DESC
         LIMIT ${historyOptions.limit + 1}`;
  const productPurchaseSql = `SELECT purchase.id, purchase.purchase_code, purchase.unit_count,
               purchase.record_status, purchase.submitted_at, purchase.reviewed_at,
               TO_CHAR(purchase.submitted_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS cursor_submitted_at,
               purchase.retail_product_id, purchase.product_name_snapshot,
               business_teacher.id AS teacher_id,
               business_teacher.teacher_code,
               business_teacher.teacher_name
          FROM public.retail_product_purchase_records purchase
     LEFT JOIN public.teachers business_teacher
            ON business_teacher.id = purchase.teacher_id
         WHERE purchase.customer_id = ${sqlText(customerId)}::bigint
           ${historyOptions.type === "PRODUCT_PURCHASE" ? cursorSql("purchase") : ""}
         ORDER BY purchase.submitted_at DESC, purchase.id DESC
         LIMIT ${historyOptions.limit + 1}`;

  const historySql = (type) => {
    const config = {
      RECHARGE: [rechargeSql(false), "recharge_records", "recharge_type = 'NEW'"],
      REFUND: [rechargeSql(true), "recharge_records", "recharge_type = 'REFUND'"],
      VERIFICATION: [verificationSql(false), "verification_records", "verification_type <> 'EXPERIENCE'"],
      EXPERIENCE: [verificationSql(true), "verification_records", "verification_type = 'EXPERIENCE'"],
      PRODUCT_PURCHASE: [productPurchaseSql, "retail_product_purchase_records", "TRUE"]
    }[type];
    return customerHistorySql(config[0], historyOptions, config[1], customerId, config[2]);
  };

  if (historyOptions.type) {
    if (historyOptions.type === "PRODUCT_PURCHASE") {
      await requireRetailProductPurchaseSchema();
      const historyRows = await executeSql(historySql(historyOptions.type));
      const historyPage = customerHistoryPage(historyRows, historyOptions.limit, historyOptions);
      return {
        ok: true,
        productPurchases: mapCustomerProductPurchases(historyPage.rows),
        history: { productPurchases: historyPage.page }
      };
    }
    const rechargeHistory = ["RECHARGE", "REFUND"].includes(historyOptions.type);
    const historyRows = await executeSql(historySql(historyOptions.type));
    const historyPage = customerHistoryPage(historyRows, historyOptions.limit, historyOptions);
    if (rechargeHistory) {
      const field = historyOptions.type === "REFUND" ? "refunds" : "recharges";
      return { ok: true, [field]: mapCustomerRecharges(historyPage.rows), history: { [field]: historyPage.page } };
    }
    const field = historyOptions.type === "EXPERIENCE" ? "experiences" : "verifications";
    return { ok: true, [field]: mapCustomerVerifications(historyPage.rows), history: { [field]: historyPage.page } };
  }

  await requireRetailProductPurchaseSchema();
  const [balances, rechargeRows, refundRows, verificationRows, experienceRows, productPurchaseRows, retailProductRows] = await Promise.all([
    executeSql(
      `WITH recharge_history AS (
         SELECT recharge.product_id,
                COALESCE(SUM(recharge.unit_count) FILTER (WHERE recharge.recharge_type = 'NEW'), 0)::bigint AS gross_recharge_count,
                COALESCE(SUM(recharge.unit_count) FILTER (WHERE recharge.recharge_type = 'REFUND'), 0)::bigint AS total_refund_count
           FROM public.recharge_records recharge
          WHERE recharge.customer_id = ${sqlText(customerId)}::bigint
            AND recharge.record_status = 'APPROVED'
          GROUP BY recharge.product_id
       ), product_ids AS (
         SELECT product_id
           FROM public.customer_product_balances
          WHERE customer_id = ${sqlText(customerId)}::bigint
         UNION
         SELECT product_id FROM recharge_history
       )
       SELECT p.id AS product_id, p.product_code, p.product_name, p.product_status,
              COALESCE(history.gross_recharge_count, 0)::bigint AS total_recharge_count,
              COALESCE(history.total_refund_count, 0)::bigint AS total_refund_count,
              COALESCE(balance.total_verification_count, 0)::bigint AS total_verification_count,
              COALESCE(balance.remaining_count, 0)::bigint AS remaining_count,
              balance.updated_at
         FROM product_ids ids
         JOIN public.products p ON p.id = ids.product_id
    LEFT JOIN public.customer_product_balances balance
           ON balance.customer_id = ${sqlText(customerId)}::bigint
          AND balance.product_id = ids.product_id
    LEFT JOIN recharge_history history ON history.product_id = ids.product_id
        ORDER BY p.product_name, p.product_code`
    ),
    executeSql(historySql("RECHARGE")),
    executeSql(historySql("REFUND")),
    executeSql(historySql("VERIFICATION")),
    executeSql(historySql("EXPERIENCE")),
    executeSql(historySql("PRODUCT_PURCHASE")),
    executeSql(
      `WITH purchased AS (
         SELECT retail_product_id, SUM(unit_count)::bigint AS purchased_count
           FROM public.retail_product_purchase_records
          WHERE customer_id = ${sqlText(customerId)}::bigint
            AND record_status = 'APPROVED'
          GROUP BY retail_product_id
       ), gifted AS (
         SELECT gift.retail_product_id, SUM(gift.unit_count)::bigint AS gifted_count
           FROM public.recharge_product_gifts gift
           JOIN public.recharge_records recharge ON recharge.id = gift.recharge_id
          WHERE gift.customer_id = ${sqlText(customerId)}::bigint
            AND recharge.recharge_type = 'NEW'
            AND recharge.record_status = 'APPROVED'
          GROUP BY gift.retail_product_id
       ), product_ids AS (
         SELECT retail_product_id FROM purchased
         UNION
         SELECT retail_product_id FROM gifted
       )
       SELECT product.id AS retail_product_id, product.product_name,
              COALESCE(purchased.purchased_count, 0)::bigint AS purchased_count,
              COALESCE(gifted.gifted_count, 0)::bigint AS gifted_count
         FROM product_ids ids
         JOIN public.retail_products product ON product.id = ids.retail_product_id
         LEFT JOIN purchased ON purchased.retail_product_id = ids.retail_product_id
         LEFT JOIN gifted ON gifted.retail_product_id = ids.retail_product_id
        ORDER BY product.product_name, product.product_code, product.id`
    )
  ]);
  const rechargePage = customerHistoryPage(rechargeRows, historyOptions.limit, historyOptions);
  const refundPage = customerHistoryPage(refundRows, historyOptions.limit, historyOptions);
  const verificationPage = customerHistoryPage(verificationRows, historyOptions.limit, historyOptions);
  const experiencePage = customerHistoryPage(experienceRows, historyOptions.limit, historyOptions);
  const productPurchasePage = customerHistoryPage(productPurchaseRows, historyOptions.limit, historyOptions);
  return {
    ok: true,
    permissions: { canEditNotes: databaseBoolean(customer.can_edit_customer), canSendMessages: databaseBoolean(customer.can_edit_customer) },
    customer: {
      customerCode: customer.customer_code, customerName: customer.customer_name,
      birthDate: customer.birth_date, notes: customer.notes || "",
      customerStatus: customer.customer_status,
      customerProcessStatus: customer.customer_process_status,
      totalRechargeCount: Number(customer.gross_recharge_count || 0),
      totalRefundCount: Number(customer.total_refund_count || 0),
      totalVerificationCount: Number(customer.normal_verification_count || 0),
      totalExperienceCount: Number(customer.total_experience_count || 0),
      latestRechargeAt: customer.latest_recharge_at,
      latestVerificationAt: customer.latest_verification_at,
      createdAt: customer.created_at, updatedAt: customer.updated_at,
      storeId: String(customer.created_store_id), storeCode: customer.store_code, storeName: customer.store_name
    },
    balances: balances.map((row) => ({
      productId: String(row.product_id), productCode: row.product_code, productName: row.product_name,
      productStatus: row.product_status,
      totalRechargeCount: Number(row.total_recharge_count || 0),
      totalRefundCount: Number(row.total_refund_count || 0),
      totalVerificationCount: Number(row.total_verification_count || 0),
      remainingCount: Number(row.remaining_count || 0), updatedAt: row.updated_at
    })),
    retailProductSummary: retailProductRows.map((row) => ({
      productId: String(row.retail_product_id), productName: String(row.product_name || ""),
      purchasedCount: Number(row.purchased_count || 0), giftedCount: Number(row.gifted_count || 0)
    })),
    recharges: mapCustomerRecharges(rechargePage.rows),
    refunds: mapCustomerRecharges(refundPage.rows),
    verifications: mapCustomerVerifications(verificationPage.rows),
    experiences: mapCustomerVerifications(experiencePage.rows),
    productPurchases: mapCustomerProductPurchases(productPurchasePage.rows),
    history: {
      recharges: rechargePage.page, refunds: refundPage.page,
      verifications: verificationPage.page, experiences: experiencePage.page,
      productPurchases: productPurchasePage.page
    }
  };
}

async function uploadCustomerPhoto(storeId, personId, buffer) {
  const { bucketId, accessToken, envId } = photoStorageSettings();
  const objectName = `${storeId}/${personId}/${Date.now()}.jpg`;
  try {
    await manager().storage.uploadObject({
      bucketId,
      objectName,
      body: buffer,
      contentType: "image/jpeg",
      contentLength: buffer.length,
      cacheControl: "private, no-store",
      upsert: false,
      accessToken,
      envId
    });
  } catch (error) {
    if (!storageUploadResponseMismatch(error)) throw error;
    console.warn("CloudBase customer photo upload succeeded without Id/Key response metadata", {
      bucketId,
      objectName
    });
  }
  // Persist the objectName supplied to uploadObject. Some manager-node/storage
  // responses include the bucket name in Key; persisting that value produced
  // references such as pg://bucket/bucket/path and later lookups could miss the
  // real object. Retrieval still supports those legacy references below.
  const savedObjectName = objectName;
  return {
    bucketId,
    objectName: savedObjectName,
    reference: `pg://${bucketId}/${savedObjectName}`
  };
}

async function deleteUploadedFile(storedPhoto) {
  if (!storedPhoto?.bucketId || !storedPhoto?.objectName) return;
  try {
    const { accessToken, envId } = photoStorageSettings();
    for (const objectName of photoObjectCandidates(storedPhoto.bucketId, storedPhoto.objectName)) {
      try {
        await manager().storage.deleteObject({
          bucketId: storedPhoto.bucketId,
          objectName,
          accessToken,
          envId
        });
        return;
      } catch (error) {
        if (!storageObjectMissing(error)) throw error;
      }
    }
  } catch (error) {
    console.warn("Photo cleanup failed", error?.message || error);
  }
}

async function getCustomerPhotoUrl(event, options = {}) {
  const requireActiveStoreCustomer = options.requireActiveStoreCustomer === true;
  const caller = options.caller || (requireActiveStoreCustomer
    ? await activeStoreCaller()
    : await activeCustomerProfileCaller());
  const customerScope = requireActiveStoreCustomer
    ? customerStatusScope(caller, "c")
    : customerLookupReadScope(caller, event, "c");
  const customerCode = String(event.customerCode || "").trim();
  if (!customerCode || customerCode.length > 96) fail("必须提供已选择客户的有效编号。", "CUSTOMER_REQUIRED");

  const rows = await executeSql(
    `SELECT c.customer_code, c.customer_name, c.birth_date, c.notes,
            c.customer_status, c.customer_process_status,
            (SELECT COALESCE(SUM(recharge.unit_count), 0)::bigint
               FROM public.recharge_records recharge
              WHERE recharge.customer_id = c.id
                AND recharge.recharge_type = 'NEW'
                AND recharge.record_status = 'APPROVED') AS total_recharge_count,
            (SELECT COALESCE(SUM(verification.unit_count), 0)::bigint
               FROM public.verification_records verification
              WHERE verification.customer_id = c.id
                AND verification.record_status = 'APPROVED'
                AND verification.verification_type IN ('NORMAL', 'SUPPLEMENT')) AS total_verification_count,
            c.total_experience_count,
            c.created_store_id, c.created_at, c.profile_photo_file_id
      FROM public.customers c
      WHERE c.customer_code = ${sqlText(customerCode)}
        ${customerScope}
        ${requireActiveStoreCustomer ? "AND c.customer_status = 'ACTIVE'" : ""}
      LIMIT 1`
  );
  const customer = rows[0];
  if (!customer) fail("未找到当前账号有权查看的客户档案。", "CUSTOMER_NOT_FOUND");
  if (!customer.profile_photo_file_id) fail("该客户没有可用的建档照片。", "CUSTOMER_PHOTO_MISSING");

  const reference = parsePhotoReference(customer.profile_photo_file_id);
  const storage = photoStorageSettings();
  if (reference.bucketId !== storage.bucketId) fail("客户照片不属于指定私有存储桶。", "PHOTO_BUCKET_MISMATCH");
  const expiresIn = Math.floor(numberSetting("CUSTOMER_PHOTO_URL_TTL_SECONDS", 120, 30, 600));
  let photoUrl = "";
  let resolvedObjectName = "";
  let responseExpiresIn = expiresIn;
  const missingFailures = [];
  const signingFailures = [];
  const objectCandidates = photoObjectCandidates(reference.bucketId, reference.objectName);
  const cacheKey = `${reference.bucketId}/${reference.objectName}`;
  const cached = cachedCustomerPhoto(cacheKey);
  if (cached) {
    photoUrl = cached.photoUrl;
    resolvedObjectName = cached.resolvedObjectName;
    responseExpiresIn = Math.max(10, Math.floor((cached.expiresAt - Date.now()) / 1000));
  }
  for (const objectName of photoUrl ? [] : objectCandidates) {
    try {
      const signed = await manager().storage.signObject({
        bucketId: reference.bucketId,
        objectName,
        expiresIn,
        accessToken: storage.accessToken,
        envId: storage.envId
      });
      photoUrl = signedPhotoUrl(signed);

      // manager-node 5.6.x normally returns { signedURL }, while some
      // CloudBase gateways wrap the response. If the single-object response
      // resolves without a URL, try the documented batch endpoint once and
      // parse both response shapes without exposing the signed token.
      let batchSigned = null;
      if (!photoUrl && typeof manager().storage.signObjects === "function") {
        batchSigned = await manager().storage.signObjects({
          bucketId: reference.bucketId,
          paths: [objectName],
          expiresIn,
          accessToken: storage.accessToken,
          envId: storage.envId
        });
        photoUrl = signedPhotoUrl(batchSigned);
      }

      if (photoUrl) {
        resolvedObjectName = objectName;
        const cachedValue = { photoUrl, resolvedObjectName, expiresAt: Date.now() + expiresIn * 1000 };
        rememberCustomerPhoto([
          cacheKey,
          `${reference.bucketId}/${resolvedObjectName}`
        ], cachedValue);
        break;
      }

      const responseError = responseErrorText([signed, batchSigned]);
      if (storageObjectMissing({ message: responseError })) {
        missingFailures.push({ objectName });
      } else {
        signingFailures.push({
          objectName,
          responseShape: safeResponseShape([signed, batchSigned]),
          responseError: responseError.slice(0, 240)
        });
      }
    } catch (error) {
      const failure = {
        objectName,
        code: String(error?.code || ""),
        requestId: error?.requestId || error?.RequestId || "",
        message: String(error?.message || "").slice(0, 240)
      };
      if (storageObjectMissing(error)) missingFailures.push(failure);
      else signingFailures.push(failure);
    }
  }
  if (!photoUrl && missingFailures.length === objectCandidates.length) {
    console.warn("Customer photo object is missing", {
      customerCode: customer.customer_code,
      bucketId: reference.bucketId,
      candidates: objectCandidates,
      failures: missingFailures
    });
    fail("该客户的照片文件已不存在，需要在客户档案中重新采集照片。", "CUSTOMER_PHOTO_OBJECT_MISSING");
  }
  if (!photoUrl) {
    console.error("Customer photo signing returned no HTTPS URL", {
      customerCode: customer.customer_code,
      bucketId: reference.bucketId,
      candidates: objectCandidates,
      failures: signingFailures
    });
    fail("私有客户照片临时访问地址生成失败，请查看云函数日志中的签名阶段错误。", "PHOTO_SIGN_FAILED");
  }

  const resolvedReference = `pg://${reference.bucketId}/${resolvedObjectName}`;
  if (!event.teacherLookup && resolvedReference !== String(customer.profile_photo_file_id).trim()) {
    try {
      await executeSql(
        `UPDATE public.customers AS c
            SET profile_photo_file_id = ${sqlText(resolvedReference)}, updated_at = NOW()
          WHERE c.customer_code = ${sqlText(customer.customer_code)}
            ${customerScope}
            ${requireActiveStoreCustomer ? "AND c.customer_status = 'ACTIVE'" : ""}
            AND c.profile_photo_file_id = ${sqlText(String(customer.profile_photo_file_id).trim())}`
      );
    } catch (error) {
      console.warn("Customer photo reference normalization failed", {
        customerCode: customer.customer_code,
        message: error?.message || String(error)
      });
    }
  }
  return {
    ok: true,
    customerCode: customer.customer_code,
    notes: customer.notes || "",
    customer: {
      customerCode: customer.customer_code,
      customerName: customer.customer_name,
      birthDate: customer.birth_date,
      notes: customer.notes || "",
      customerStatus: customer.customer_status,
      customerProcessStatus: customer.customer_process_status,
      totalRechargeCount: Number(customer.total_recharge_count || 0),
      totalVerificationCount: Number(customer.total_verification_count || 0),
      totalExperienceCount: Number(customer.total_experience_count || 0),
      storeId: String(customer.created_store_id),
      hasProfilePhoto: true,
      createdAt: customer.created_at
    },
    photoUrl,
    expiresIn: responseExpiresIn
  };
}

async function getActiveStoreCustomerDetail(event) {
  const caller = await activeBusinessCaller(event);
  return getCustomerPhotoUrl(event, { requireActiveStoreCustomer: true, caller });
}

function activeStoreCustomerCursor(value) {
  if (value === undefined || value === null) return null;
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    fail("客户分页游标格式无效。", "BAD_REQUEST");
  }
  const expectedKeys = ["birthDate", "customerCode", "customerName"];
  const actualKeys = Object.keys(value).sort();
  if (actualKeys.length !== expectedKeys.length || actualKeys.some((key, index) => key !== expectedKeys[index])) {
    fail("客户分页游标字段无效。", "BAD_REQUEST");
  }
  if (expectedKeys.some((key) => typeof value[key] !== "string" || value[key] !== value[key].trim() || !value[key])) {
    fail("客户分页游标不完整。", "BAD_REQUEST");
  }
  const customerName = value.customerName;
  const birthDate = optionalBusinessQueryDate(value.birthDate, "客户分页游标生日");
  const customerCode = value.customerCode;
  if (customerName.length > 100 || /[\u0000-\u001f\u007f]/.test(customerName)) {
    fail("客户分页游标姓名无效。", "BAD_REQUEST");
  }
  if (customerCode.length > 96 || /[\u0000-\u001f\u007f]/.test(customerCode)) {
    fail("客户分页游标编号无效。", "BAD_REQUEST");
  }
  return { customerName, birthDate, customerCode };
}

async function listActiveStoreCustomers(event = {}) {
  const caller = await activeBusinessCaller(event);
  const requestedLimit = Number(event.limit);
  const limit = Number.isFinite(requestedLimit) ? Math.min(Math.max(Math.trunc(requestedLimit), 1), 100) : 100;
  const customerName = String(event.customerName || "").trim();
  const birthDate = optionalBusinessQueryDate(event.birthDate, "客户生日");
  const cursor = activeStoreCustomerCursor(event.cursor);
  if (customerName.length > 100) fail("客户姓名不能超过 100 个字符。", "BAD_REQUEST");
  if (cursor && customerName && cursor.customerName !== customerName) {
    fail("客户分页游标与当前姓名查询不一致。", "BAD_REQUEST");
  }
  if (cursor && birthDate && cursor.birthDate !== birthDate) {
    fail("客户分页游标与当前生日查询不一致。", "BAD_REQUEST");
  }
  const rows = await executeSql(
    `SELECT customer_code, customer_name, birth_date,
            TO_CHAR(COALESCE(birth_date, DATE '0001-01-01'), 'YYYY-MM-DD') AS cursor_birth_date
       FROM public.customers
      WHERE created_store_id = ${caller.storeId}
        AND customer_status = 'ACTIVE'
        ${customerName ? `AND customer_name = ${sqlText(customerName)}` : ""}
        ${birthDate ? `AND birth_date = ${sqlText(birthDate)}::date` : ""}
        ${cursor ? `AND (customer_name, COALESCE(birth_date, DATE '0001-01-01'), customer_code) > (${sqlText(cursor.customerName)}, ${sqlText(cursor.birthDate)}::date, ${sqlText(cursor.customerCode)})` : ""}
      ORDER BY customer_name ASC, COALESCE(birth_date, DATE '0001-01-01') ASC, customer_code ASC
      LIMIT ${limit + 1}`
  );
  const hasMore = rows.length > limit;
  const visibleRows = rows.slice(0, limit);
  const last = visibleRows[visibleRows.length - 1];
  return {
    ok: true,
    storeId: String(caller.storeId),
    storeCode: caller.storeCode,
    storeName: caller.storeName,
    customers: visibleRows.map((customer) => ({
      customerCode: customer.customer_code,
      customerName: customer.customer_name,
      birthDate: customer.birth_date
    })),
    hasMore,
    nextCursor: hasMore && last
      ? {
          customerName: String(last.customer_name || ""),
          birthDate: String(last.cursor_birth_date || ""),
          customerCode: String(last.customer_code || "")
        }
      : null
  };
}

function scopedQueryCursorTimestamp(value, label) {
  const text = String(value || "").trim();
  if (!text) return "";
  const match = text.match(/^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{1,9})?Z$/);
  if (text.length > 100 || !match) fail(`${label}格式无效。`, "BAD_REQUEST");
  optionalBusinessQueryDate(match[1], label);
  if (Number(match[2]) > 23 || Number(match[3]) > 59 || Number(match[4]) > 59) {
    fail(`${label}格式无效。`, "BAD_REQUEST");
  }
  return text;
}

// The browser supplies filters only. Headquarters may choose all stores or
// one verified store; a store account is always pinned to its own active
// binding by activeScopedQueryCaller.
async function queryStoreCustomers(event = {}) {
  const caller = await activeScopedQueryCaller(event);
  const mode = String(event.mode || "browse").trim().toLowerCase();
  if (!["browse", "manual"].includes(mode)) fail("客户查询方式无效。", "BAD_REQUEST");
  const process = String(event.processStatus || "all").trim().toUpperCase();
  const status = String(event.customerStatus || "all").trim().toUpperCase();
  const allowedProcesses = new Set(["ALL", "INFORMATION_ONLY", "RECHARGED_NO_CONSUMPTION", "RECHARGED_WITH_CONSUMPTION"]);
  if (!allowedProcesses.has(process)) fail("业务阶段筛选无效。", "BAD_REQUEST");
  if (!["ALL", "ACTIVE", "ARCHIVED"].includes(status)) fail("客户状态筛选无效。", "BAD_REQUEST");
  const name = String(event.name || "").trim();
  const birthDate = optionalBusinessQueryDate(event.birthDate, "生日");
  const startDate = optionalBusinessQueryDate(event.startDate, "开始日期");
  const endDate = optionalBusinessQueryDate(event.endDate, "结束日期");
  if (name.length > 100) fail("客户姓名查询不能超过 100 个字符。", "BAD_REQUEST");
  if (startDate && endDate && startDate > endDate) fail("开始日期不能晚于结束日期。", "BAD_REQUEST");

  const exportAll = event.exportAll === true;
  const requestedLimit = Number(event.limit);
  const limit = exportAll ? 1000 : Math.min(Math.max(Number.isFinite(requestedLimit) ? Math.trunc(requestedLimit) : 100, 1), 100);
  const cursorCreatedAt = scopedQueryCursorTimestamp(exportAll ? "" : event.cursorCreatedAt, "分页时间游标");
  const cursorIdText = exportAll ? "" : String(event.cursorId || "").trim();
  if (Boolean(cursorCreatedAt) !== Boolean(cursorIdText)) fail("分页游标不完整。", "BAD_REQUEST");
  const cursorId = cursorIdText ? businessQueryDatabaseId(cursorIdText, "分页客户") : "";

  const baseClauses = [scopedStoreClause(caller, "c.created_store_id")];
  if (mode === "manual") {
    if (name) baseClauses.push(`c.customer_name ILIKE '%' || ${sqlText(name)} || '%'`);
    if (birthDate) baseClauses.push(`c.birth_date = ${sqlText(birthDate)}::date`);
  } else {
    if (status !== "ALL") baseClauses.push(`c.customer_status = ${sqlText(status)}`);
    if (startDate) baseClauses.push(`c.created_at >= (${sqlText(startDate)}::date::timestamp AT TIME ZONE 'Asia/Shanghai')`);
    if (endDate) baseClauses.push(`c.created_at < ((${sqlText(endDate)}::date + 1)::timestamp AT TIME ZONE 'Asia/Shanghai')`);
  }

  const listClauses = [...baseClauses];
  if (mode === "browse" && process !== "ALL") {
    listClauses.push(`c.customer_process_status = ${sqlText(process)}`);
  }
  if (cursorCreatedAt) {
    listClauses.push(`(c.created_at, c.id) < (${sqlText(cursorCreatedAt)}::timestamptz, ${cursorId}::bigint)`);
  }

  const selectedProcessClause = mode === "browse" && process !== "ALL"
    ? `c.customer_process_status = ${sqlText(process)}`
    : "TRUE";
  const summarySql = `SELECT COUNT(*) AS total,
                             COUNT(*) FILTER (WHERE c.customer_status = 'ACTIVE' AND ${selectedProcessClause}) AS active,
                             COUNT(*) FILTER (WHERE c.customer_status = 'ARCHIVED' AND ${selectedProcessClause}) AS archived,
                             COUNT(*) FILTER (WHERE c.customer_process_status = 'INFORMATION_ONLY') AS information_only,
                             COUNT(*) FILTER (WHERE c.customer_process_status = 'RECHARGED_NO_CONSUMPTION') AS recharged_no_consumption,
                             COUNT(*) FILTER (WHERE c.customer_process_status = 'RECHARGED_WITH_CONSUMPTION') AS recharged_with_consumption
                        FROM public.customers c
                       WHERE ${baseClauses.join(" AND ")}`;
  const listSql = `SELECT c.id, c.customer_code, c.customer_name, c.birth_date, c.customer_status,
            c.customer_process_status,
            (SELECT COALESCE(SUM(recharge.unit_count), 0)::bigint
               FROM public.recharge_records recharge
              WHERE recharge.customer_id = c.id
                AND recharge.recharge_type = 'NEW'
                AND recharge.record_status = 'APPROVED') AS total_recharge_count,
            (SELECT COALESCE(SUM(v.unit_count), 0)::bigint
               FROM public.verification_records v
              WHERE v.customer_id = c.id
                AND v.record_status = 'APPROVED'
                AND v.verification_type IN ('NORMAL', 'SUPPLEMENT')) AS normal_verification_count,
            c.created_at, c.created_store_id AS store_id, s.store_name, s.store_code,
            TO_CHAR(c.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS cursor_created_at
       FROM public.customers c
       JOIN public.stores s ON s.id = c.created_store_id
      WHERE ${listClauses.join(" AND ")}
      ORDER BY c.created_at DESC, c.id DESC
      LIMIT ${limit + 1}`;
  // Export is one bounded statement/snapshot, never a loop across display pages.
  const [rawCustomers, summaryRows] = exportAll
    ? [await executeSql(listSql), []]
    : await Promise.all([executeSql(listSql), executeSql(summarySql)]);
  if (exportAll && rawCustomers.length > 1000) fail("匹配结果超过1000条，请缩小查询范围后导出。", "EXPORT_LIMIT_EXCEEDED");
  const hasMore = rawCustomers.length > limit;
  const pageRows = rawCustomers.slice(0, limit);
  const last = pageRows[pageRows.length - 1];
  const summary = summaryRows[0] || {};
  const processCounts = {
    INFORMATION_ONLY: Number(summary.information_only || 0),
    RECHARGED_NO_CONSUMPTION: Number(summary.recharged_no_consumption || 0),
    RECHARGED_WITH_CONSUMPTION: Number(summary.recharged_with_consumption || 0)
  };
  const selectedTotal = mode === "browse" && process !== "ALL"
    ? processCounts[process]
    : Number(summary.total || 0);
  return {
    ok: true,
    scopeMode: caller.scopeMode,
    storeId: caller.storeId ? String(caller.storeId) : "",
    storeCode: caller.storeCode,
    storeName: caller.storeName,
    storeStatus: caller.storeStatus || "",
    summary: {
      total: Number(summary.total || 0),
      selectedTotal,
      active: Number(summary.active || 0),
      archived: Number(summary.archived || 0),
      informationOnly: processCounts.INFORMATION_ONLY,
      rechargedNoConsumption: processCounts.RECHARGED_NO_CONSUMPTION,
      rechargedWithConsumption: processCounts.RECHARGED_WITH_CONSUMPTION
    },
    customers: pageRows.map((customer) => ({
      customerCode: customer.customer_code, customerName: customer.customer_name,
      birthDate: customer.birth_date, customerStatus: customer.customer_status,
      customerProcessStatus: customer.customer_process_status,
      totalRechargeCount: Number(customer.total_recharge_count || 0),
      totalVerificationCount: Number(customer.normal_verification_count || 0),
      createdAt: customer.created_at, storeId: String(customer.store_id),
      storeName: customer.store_name, storeCode: customer.store_code
    })),
    ...(exportAll ? { exportAll: true, total: pageRows.length } : {}),
    hasMore,
    nextCursor: hasMore && last ? { createdAt: last.cursor_created_at, id: String(last.id) } : null
  };
}

function inactiveVerificationCursor(event = {}) {
  const baselineAt = scopedQueryCursorTimestamp(event.cursorBaselineAt, "未核销客户分页时间游标");
  const customerIdText = String(event.cursorCustomerId || "").trim();
  if (Boolean(baselineAt) !== Boolean(customerIdText)) fail("未核销客户分页游标不完整。", "BAD_REQUEST");
  return {
    baselineAt,
    customerId: customerIdText ? businessQueryDatabaseId(customerIdText, "未核销客户分页编号") : ""
  };
}

function operationalBalanceCategory(event = {}) {
  const value = String(event.balanceCategory || "ALL").trim().toUpperCase();
  if (!["ALL", "ZERO", "NONZERO", "BOTH"].includes(value)) {
    fail("预警分类无效。", "BAD_REQUEST");
  }
  return value;
}

// Headquarters and stores can find customers who have not completed a NORMAL
// or EXPERIENCE verification for a caller-supplied number of Shanghai calendar
// days. The baseline follows the required fixed ladder: latest approved NORMAL
// first; only when no NORMAL exists may the latest approved EXPERIENCE be used;
// customers with neither type use their immutable customer-created time.
async function queryInactiveVerificationCustomers(event = {}, teamCaller = null) {
  const caller = teamCaller || await activeScopedQueryCaller(event);
  const balanceCategory = operationalBalanceCategory(event);
  const minimumDaysText = String(event.minimumDays ?? "").trim();
  const minimumDays = Number(minimumDaysText);
  if (!/^\d+$/.test(minimumDaysText) || !Number.isInteger(minimumDays) || minimumDays < 1 || minimumDays > 3650) {
    fail("未核销天数必须是 1 至 3650 的整数。", "BAD_REQUEST");
  }
  const exportAll = event.exportAll === true;
  const requestedLimit = Number(event.limit);
  const limit = exportAll
    ? OPERATIONAL_EXPORT_MAX_ROWS
    : Math.min(Math.max(Number.isFinite(requestedLimit) ? Math.trunc(requestedLimit) : 20, 1), 100);
  const cursor = inactiveVerificationCursor(event);
  if (exportAll && balanceCategory !== "BOTH") {
    fail("完整导出必须同时读取两个预警分类。", "BAD_REQUEST");
  }
  if (balanceCategory === "BOTH" && cursor.baselineAt) {
    fail("双分类首页查询不能携带单分类分页游标。", "BAD_REQUEST");
  }
  const eligibleSql = `WITH eligible_customers AS (
    SELECT c.id, c.customer_code, c.customer_name, c.birth_date, c.customer_status,
           c.created_at, c.created_store_id AS store_id,
           s.store_name, s.store_code,
           latest.id AS last_verification_id,
           latest.verification_code AS last_verification_code,
           latest.verification_type AS last_verification_type,
           latest.product_name AS last_product_name,
           COALESCE(latest.submitted_at, c.created_at) AS baseline_at,
           CASE WHEN latest.id IS NULL THEN 'CUSTOMER_CREATED'
                WHEN latest.verification_type = 'SUPPLEMENT' THEN 'NORMAL'
                ELSE latest.verification_type END AS baseline_source,
           CASE WHEN EXISTS (
             SELECT 1
               FROM public.customer_product_balances balance
              WHERE balance.customer_id = c.id
                AND balance.remaining_count <> 0
           ) THEN 'NONZERO' ELSE 'ZERO' END AS balance_category,
           ((CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Shanghai')::date
             - (COALESCE(latest.submitted_at, c.created_at) AT TIME ZONE 'Asia/Shanghai')::date)::integer AS days_since
      FROM public.customers c
      JOIN public.stores s ON s.id = c.created_store_id
 LEFT JOIN LATERAL (
        SELECT v.id, v.verification_code, v.verification_type, v.submitted_at,
               p.product_name
          FROM public.verification_records v
          JOIN public.products p ON p.id = v.product_id
         WHERE v.customer_id = c.id
           AND ${caller.teamVerificationScope || 'TRUE'}
           AND v.record_status = 'APPROVED'
           AND v.verification_type IN ('NORMAL', 'SUPPLEMENT', 'EXPERIENCE')
         ORDER BY CASE WHEN v.verification_type IN ('NORMAL', 'SUPPLEMENT') THEN 0 ELSE 1 END ASC,
                  v.submitted_at DESC, v.id DESC
         LIMIT 1
      ) latest ON TRUE
     WHERE ${scopedStoreClause(caller, "c.created_store_id")}
       AND c.customer_status = 'ACTIVE'
       AND ((CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Shanghai')::date
             - (COALESCE(latest.submitted_at, c.created_at) AT TIME ZONE 'Asia/Shanghai')::date) >= ${minimumDays}
  )`;
  const cursorClause = cursor.baselineAt
    ? `(inactive.baseline_at, inactive.id) > (${sqlText(cursor.baselineAt)}::timestamptz, ${cursor.customerId}::bigint)`
    : "TRUE";
  const categoryClause = balanceCategory === "ZERO"
    ? "inactive.balance_category = 'ZERO'"
    : balanceCategory === "NONZERO"
      ? "inactive.balance_category = 'NONZERO'"
      : "TRUE";
  const summaryCategoryClause = balanceCategory === "ZERO"
    ? "balance_category = 'ZERO'"
    : balanceCategory === "NONZERO"
      ? "balance_category = 'NONZERO'"
      : "TRUE";
  const pageSql = exportAll
    ? `SELECT inactive.*
         FROM eligible_customers inactive
        ORDER BY CASE inactive.balance_category WHEN 'ZERO' THEN 0 ELSE 1 END,
                 inactive.baseline_at ASC, inactive.id ASC
        LIMIT ${OPERATIONAL_EXPORT_MAX_ROWS + 1}`
    : balanceCategory === "BOTH"
    ? `SELECT ranked.*
         FROM (
           SELECT inactive.*,
                  ROW_NUMBER() OVER (
                    PARTITION BY inactive.balance_category
                    ORDER BY inactive.baseline_at ASC, inactive.id ASC
                  ) AS category_row_number
             FROM eligible_customers inactive
         ) ranked
        WHERE ranked.category_row_number <= ${limit + 1}`
    : `SELECT inactive.*
         FROM eligible_customers inactive
        WHERE ${categoryClause}
          AND ${cursorClause}
        ORDER BY inactive.baseline_at ASC, inactive.id ASC
        LIMIT ${limit + 1}`;
  // The summary and visible rows intentionally share one SQL statement. The
  // BOTH mode gives the mini-program both first sections from the same MVCC
  // snapshot, so a concurrent recharge cannot put one customer in both cards.
  const queryRows = await executeSql(`${eligibleSql},
    summary AS (
      SELECT COUNT(*) AS selected_total,
             COUNT(*) FILTER (WHERE ${summaryCategoryClause}) AS category_total,
             COUNT(*) FILTER (WHERE balance_category = 'ZERO') AS zero_balance_customers,
             COUNT(*) FILTER (WHERE balance_category = 'NONZERO') AS nonzero_balance_customers,
             COUNT(*) FILTER (WHERE baseline_source = 'NORMAL') AS normal_baseline,
             COUNT(*) FILTER (WHERE baseline_source = 'EXPERIENCE') AS experience_baseline,
             COUNT(*) FILTER (WHERE baseline_source = 'CUSTOMER_CREATED') AS never_verified
        FROM eligible_customers
    ),
    page_rows AS (
      ${pageSql}
    )
    SELECT page_rows.*,
           TO_CHAR(page_rows.baseline_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS cursor_baseline_at,
           summary.*
      FROM summary
      LEFT JOIN page_rows ON TRUE
     ORDER BY CASE page_rows.balance_category WHEN 'ZERO' THEN 0 WHEN 'NONZERO' THEN 1 ELSE 2 END,
              page_rows.baseline_at ASC NULLS LAST, page_rows.id ASC NULLS LAST`);
  const summary = queryRows[0] || {};
  const resultRows = queryRows.filter((row) => row.id !== null && row.id !== undefined && row.id !== "");
  const summaryView = {
    selectedTotal: Number(summary.selected_total || 0),
    categoryTotal: Number(summary.category_total || 0),
    zeroBalanceCustomers: Number(summary.zero_balance_customers || 0),
    nonzeroBalanceCustomers: Number(summary.nonzero_balance_customers || 0),
    normalBaseline: Number(summary.normal_baseline || 0),
    experienceBaseline: Number(summary.experience_baseline || 0),
    neverVerified: Number(summary.never_verified || 0)
  };
  const mapCustomer = (customer) => ({
    customerCode: customer.customer_code,
    customerName: customer.customer_name,
    birthDate: customer.birth_date,
    customerStatus: customer.customer_status,
    storeId: String(customer.store_id),
    storeName: customer.store_name,
    storeCode: customer.store_code,
    baselineAt: customer.baseline_at,
    baselineSource: customer.baseline_source,
    balanceCategory: customer.balance_category,
    daysSince: Number(customer.days_since || 0),
    lastVerificationId: customer.last_verification_id ? String(customer.last_verification_id) : "",
    lastVerificationCode: customer.last_verification_code || "",
    lastVerificationType: customer.last_verification_type === "SUPPLEMENT" ? "NORMAL" : customer.last_verification_type || "",
    lastProductName: customer.last_product_name || ""
  });
  const categoryPage = (category) => {
    const categoryRows = resultRows.filter((row) => !category || row.balance_category === category);
    const hasMore = categoryRows.length > limit;
    const pageRows = categoryRows.slice(0, limit);
    const last = pageRows[pageRows.length - 1];
    return {
      categoryTotal: category === "ZERO"
        ? summaryView.zeroBalanceCustomers
        : category === "NONZERO" ? summaryView.nonzeroBalanceCustomers : summaryView.selectedTotal,
      customers: pageRows.map(mapCustomer),
      hasMore,
      nextCursor: hasMore && last
        ? { baselineAt: last.cursor_baseline_at, customerId: String(last.id) }
        : null
    };
  };
  const baseResult = {
    ok: true,
    scopeMode: caller.scopeMode,
    storeId: caller.storeId ? String(caller.storeId) : "",
    storeCode: caller.storeCode || "",
    storeName: caller.storeName || "",
    minimumDays,
    balanceCategory,
    summary: summaryView
  };
  if (exportAll) {
    if (summaryView.selectedTotal > OPERATIONAL_EXPORT_MAX_ROWS || resultRows.length > OPERATIONAL_EXPORT_MAX_ROWS) {
      fail(`当前结果有 ${summaryView.selectedTotal} 位，单次最多导出 ${OPERATIONAL_EXPORT_MAX_ROWS} 位，请缩小查询范围。`, "EXPORT_TOO_LARGE");
    }
    return { ...baseResult, exportCustomers: resultRows.map(mapCustomer) };
  }
  if (balanceCategory === "BOTH") {
    return {
      ...baseResult,
      sections: {
        ZERO: categoryPage("ZERO"),
        NONZERO: categoryPage("NONZERO")
      }
    };
  }
  return { ...baseResult, ...categoryPage(balanceCategory === "ALL" ? "" : balanceCategory) };
}

function lowBalanceCursor(event = {}) {
  const remainingText = String(event.cursorRemainingCount ?? "").trim();
  const customerIdText = String(event.cursorCustomerId || "").trim();
  const productIdText = String(event.cursorProductId || "").trim();
  const supplied = [remainingText, customerIdText, productIdText].filter(Boolean).length;
  if (supplied !== 0 && supplied !== 3) fail("低余次客户分页游标不完整。", "BAD_REQUEST");
  if (!supplied) return { remainingCount: "", customerId: "", productId: "" };
  const remainingCount = Number(remainingText);
  if (!/^\d+$/.test(remainingText) || !Number.isSafeInteger(remainingCount)) {
    fail("低余次客户分页余次无效。", "BAD_REQUEST");
  }
  return {
    remainingCount,
    customerId: businessQueryDatabaseId(customerIdText, "低余次客户分页客户"),
    productId: businessQueryDatabaseId(productIdText, "低余次客户分页项目")
  };
}

// A balance row is the authoritative proof that a customer opened the project
// card.  Never synthesize zero-balance rows for products the customer did not
// purchase.  EXPERIENCE verifications are already excluded by the balance
// state machine and therefore cannot lower the remaining purchased units.
async function queryLowBalanceCustomers(event = {}, teamCaller = null) {
  const caller = teamCaller || await activeScopedQueryCaller(event);
  const balanceCategory = operationalBalanceCategory(event);
  const remainingBelowText = String(event.remainingBelow ?? "").trim();
  const remainingBelow = Number(remainingBelowText);
  if (!/^\d+$/.test(remainingBelowText) || !Number.isInteger(remainingBelow)
      || remainingBelow < 1 || remainingBelow > 999999) {
    fail("剩余次数阈值必须是 1 至 999999 的整数。", "BAD_REQUEST");
  }
  const productIdText = String(event.productId || "").trim();
  const productId = productIdText && productIdText.toUpperCase() !== "ALL"
    ? businessQueryDatabaseId(productIdText, "项目")
    : "";
  const exportAll = event.exportAll === true;
  const requestedLimit = Number(event.limit);
  const limit = exportAll
    ? OPERATIONAL_EXPORT_MAX_ROWS
    : Math.min(Math.max(Number.isFinite(requestedLimit) ? Math.trunc(requestedLimit) : 20, 1), 100);
  const cursor = lowBalanceCursor(event);
  if (exportAll && balanceCategory !== "BOTH") {
    fail("完整导出必须同时读取两个预警分类。", "BAD_REQUEST");
  }
  if (balanceCategory === "BOTH" && cursor.customerId) {
    fail("双分类首页查询不能携带单分类分页游标。", "BAD_REQUEST");
  }
  const baseClauses = [
    scopedStoreClause(caller, "c.created_store_id"),
    "c.customer_status = 'ACTIVE'",
    "p.product_status = 'ACTIVE'",
    "b.total_recharge_count > 0",
    `b.remaining_count < ${remainingBelow}`
  ];
  if (productId) baseClauses.push(`b.product_id = ${productId}::bigint`);
  const categoryClause = balanceCategory === "ZERO"
    ? "balance.remaining_count = 0"
    : balanceCategory === "NONZERO"
      ? "balance.remaining_count <> 0"
      : "TRUE";
  const cursorClause = cursor.customerId
    ? `(balance.remaining_count, balance.customer_id, balance.product_id) > (${cursor.remainingCount}::integer, ${cursor.customerId}::bigint, ${cursor.productId}::bigint)`
    : "TRUE";
  const fromSql = `FROM public.customer_product_balances b
       JOIN public.customers c ON c.id = b.customer_id
       JOIN public.products p ON p.id = b.product_id
       JOIN public.stores s ON s.id = c.created_store_id
      WHERE ${baseClauses.join("\n        AND ")}`;
  const eligibleSql = `WITH eligible_balances AS (
      SELECT c.id AS customer_id, c.customer_code, c.customer_name, c.birth_date,
              c.created_store_id AS store_id, s.store_code, s.store_name,
              p.id AS product_id, p.product_code, p.product_name,
              b.total_recharge_count, b.total_verification_count,
              b.remaining_count, b.updated_at,
              CASE WHEN b.remaining_count = 0 THEN 'ZERO' ELSE 'NONZERO' END AS balance_category
         ${fromSql}
  )`;
  const pageSql = exportAll
    ? `SELECT balance.*
         FROM eligible_balances balance
        ORDER BY CASE balance.balance_category WHEN 'ZERO' THEN 0 ELSE 1 END,
                 balance.remaining_count ASC, balance.customer_id ASC, balance.product_id ASC
        LIMIT ${OPERATIONAL_EXPORT_MAX_ROWS + 1}`
    : balanceCategory === "BOTH"
    ? `SELECT ranked.*
         FROM (
           SELECT balance.*,
                  ROW_NUMBER() OVER (
                    PARTITION BY balance.balance_category
                    ORDER BY balance.remaining_count ASC, balance.customer_id ASC, balance.product_id ASC
                  ) AS category_row_number
             FROM eligible_balances balance
         ) ranked
        WHERE ranked.category_row_number <= ${limit + 1}`
    : `SELECT balance.*
         FROM eligible_balances balance
        WHERE ${categoryClause}
          AND ${cursorClause}
        ORDER BY balance.remaining_count ASC, balance.customer_id ASC, balance.product_id ASC
        LIMIT ${limit + 1}`;
  const queryRows = await executeSql(`${eligibleSql},
    summary AS (
      SELECT COUNT(*) AS selected_total,
             COUNT(*) FILTER (WHERE ${categoryClause}) AS category_total,
             COUNT(DISTINCT customer_id) AS customer_total,
             COUNT(DISTINCT product_id) AS product_total,
             COUNT(*) FILTER (WHERE remaining_count = 0) AS zero_balance,
             COUNT(*) FILTER (WHERE remaining_count <> 0) AS nonzero_below_threshold
        FROM eligible_balances balance
    ),
    page_rows AS (
      ${pageSql}
    )
    SELECT page_rows.*, summary.*
      FROM summary
      LEFT JOIN page_rows ON TRUE
     ORDER BY CASE page_rows.balance_category WHEN 'ZERO' THEN 0 WHEN 'NONZERO' THEN 1 ELSE 2 END,
              page_rows.remaining_count ASC NULLS LAST,
              page_rows.customer_id ASC NULLS LAST, page_rows.product_id ASC NULLS LAST`);
  const summary = queryRows[0] || {};
  const resultRows = queryRows.filter((row) => row.customer_id !== null && row.customer_id !== undefined && row.customer_id !== "");
  const summaryView = {
    selectedTotal: Number(summary.selected_total || 0),
    categoryTotal: Number(summary.category_total || 0),
    customerTotal: Number(summary.customer_total || 0),
    productTotal: Number(summary.product_total || 0),
    zeroBalance: Number(summary.zero_balance || 0),
    nonzeroBelowThreshold: Number(summary.nonzero_below_threshold || 0)
  };
  const mapBalance = (row) => ({
    customerCode: row.customer_code,
    customerName: row.customer_name,
    birthDate: row.birth_date,
    storeId: String(row.store_id),
    storeCode: row.store_code,
    storeName: row.store_name,
    productId: String(row.product_id),
    productCode: row.product_code,
    productName: row.product_name,
    purchasedCount: Number(row.total_recharge_count || 0),
    consumedCount: Number(row.total_verification_count || 0),
    remainingCount: Number(row.remaining_count || 0),
    balanceCategory: row.balance_category,
    updatedAt: row.updated_at
  });
  const categoryPage = (category) => {
    const categoryRows = resultRows.filter((row) => !category || row.balance_category === category);
    const hasMore = categoryRows.length > limit;
    const pageRows = categoryRows.slice(0, limit);
    const last = pageRows[pageRows.length - 1];
    return {
      categoryTotal: category === "ZERO"
        ? summaryView.zeroBalance
        : category === "NONZERO" ? summaryView.nonzeroBelowThreshold : summaryView.selectedTotal,
      balances: pageRows.map(mapBalance),
      hasMore,
      nextCursor: hasMore && last ? {
        remainingCount: Number(last.remaining_count || 0),
        customerId: String(last.customer_id),
        productId: String(last.product_id)
      } : null
    };
  };
  const baseResult = {
    ok: true,
    scopeMode: caller.scopeMode,
    storeId: caller.storeId ? String(caller.storeId) : "",
    storeCode: caller.storeCode || "",
    storeName: caller.storeName || "",
    remainingBelow,
    productId: productId || "",
    balanceCategory,
    summary: summaryView
  };
  if (exportAll) {
    if (summaryView.selectedTotal > OPERATIONAL_EXPORT_MAX_ROWS || resultRows.length > OPERATIONAL_EXPORT_MAX_ROWS) {
      fail(`当前结果有 ${summaryView.selectedTotal} 个卡项，单次最多导出 ${OPERATIONAL_EXPORT_MAX_ROWS} 个卡项，请缩小查询范围。`, "EXPORT_TOO_LARGE");
    }
    return { ...baseResult, exportBalances: resultRows.map(mapBalance) };
  }
  if (balanceCategory === "BOTH") {
    return {
      ...baseResult,
      sections: {
        ZERO: categoryPage("ZERO"),
        NONZERO: categoryPage("NONZERO")
      }
    };
  }
  return { ...baseResult, ...categoryPage(balanceCategory === "ALL" ? "" : balanceCategory) };
}

function optionalBusinessQueryDate(value, label) {
  const text = String(value || "").trim();
  if (!text) return "";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) fail(`${label}格式无效。`, "BAD_REQUEST");
  const parsed = new Date(`${text}T00:00:00.000Z`);
  if (Number.isNaN(parsed.valueOf()) || parsed.toISOString().slice(0, 10) !== text) {
    fail(`${label}不是有效日期。`, "BAD_REQUEST");
  }
  return text;
}

function businessQueryDatabaseId(value, label) {
  const id = positiveDatabaseId(value, label);
  if (BigInt(id) > 9223372036854775807n) fail(`${label}超出数据库编号范围。`, "BAD_REQUEST");
  return id;
}

// Business-record search is intentionally separate from the HQ review queue.
// The authenticated UID establishes either one store scope or HQ's verified
// all/single-store scope; browser filters never grant access by themselves.
async function queryStoreBusinessRecords(event = {}) {
  const caller = await activeScopedQueryCaller(event);
  const recordType = String(event.recordType || "").trim().toUpperCase();
  if (!["RECHARGE", "VERIFICATION"].includes(recordType)) fail("工单类型无效。", "BAD_REQUEST");

  const mode = String(event.mode || "browse").trim().toLowerCase();
  if (!["browse", "manual"].includes(mode)) fail("工单查询方式无效。", "BAD_REQUEST");
  const statusCategory = String(event.statusCategory || "ALL").trim().toUpperCase();
  if (!["ALL", "PENDING", "APPROVED", "REJECTED"].includes(statusCategory)) {
    fail("工单状态筛选无效。", "BAD_REQUEST");
  }
  const verificationType = String(event.verificationType || "ALL").trim().toUpperCase();
  if (!["ALL", "NORMAL", "EXPERIENCE"].includes(verificationType)) {
    fail("核销类型筛选无效。", "BAD_REQUEST");
  }
  const rechargeType = String(event.rechargeType || "ALL").trim().toUpperCase();
  if (!["ALL", "NEW", "REFUND"].includes(rechargeType)) {
    fail("充值类型筛选无效。", "BAD_REQUEST");
  }

  const customerName = String(event.customerName || "").trim();
  if (customerName.length > 100) fail("客户姓名查询不能超过 100 个字符。", "BAD_REQUEST");
  const birthDate = optionalBusinessQueryDate(event.birthDate, "生日");
  const startDate = optionalBusinessQueryDate(event.startDate, "开始日期");
  const endDate = optionalBusinessQueryDate(event.endDate, "结束日期");
  if (startDate && endDate && startDate > endDate) fail("开始日期不能晚于结束日期。", "BAD_REQUEST");

  const productIdText = String(event.productId || "").trim();
  const productId = productIdText && productIdText.toUpperCase() !== "ALL"
    ? businessQueryDatabaseId(productIdText, "项目")
    : "";
  const exportAll = event.exportAll === true;
  const requestedLimit = Number(event.limit);
  const limit = Math.min(Math.max(Number.isFinite(requestedLimit) ? Math.trunc(requestedLimit) : 100, 1), 100);
  const numberedPage = Object.prototype.hasOwnProperty.call(event, "page")
    || Object.prototype.hasOwnProperty.call(event, "pageSize");
  const requestedPage = Number(event.page || 1);
  const requestedPageSize = Number(event.pageSize || 10);
  if (numberedPage && (!Number.isInteger(requestedPage) || requestedPage < 1)) fail("业务明细页码必须是正整数。", "BAD_REQUEST");
  if (numberedPage && (!Number.isInteger(requestedPageSize) || requestedPageSize < 1 || requestedPageSize > 100)) {
    fail("业务明细每页数量必须是 1 至 100。", "BAD_REQUEST");
  }
  const page = numberedPage ? requestedPage : 1;
  const pageSize = numberedPage ? requestedPageSize : limit;
  const cursorSubmittedAt = scopedQueryCursorTimestamp(exportAll ? "" : event.cursorSubmittedAt, "分页时间游标");
  const cursorIdText = exportAll ? "" : String(event.cursorId || "").trim();
  if (Boolean(cursorSubmittedAt) !== Boolean(cursorIdText)) fail("分页游标不完整。", "BAD_REQUEST");
  if (numberedPage && cursorSubmittedAt) fail("页码分页不能同时提交游标。", "BAD_REQUEST");
  const cursorId = cursorIdText ? businessQueryDatabaseId(cursorIdText, "分页工单") : "";

  const alias = recordType === "RECHARGE" ? "r" : "v";
  const table = recordType === "RECHARGE" ? "recharge_records" : "verification_records";
  // The record table is the source of truth for scope, type, status and time.
  // Only exact customer search needs the customer table during filtering.  In
  // particular, never join every display dimension before LIMIT/OFFSET: the
  // ten-year stress dataset makes that plan needlessly expensive and can make
  // the refund page time out before PostgreSQL returns its first row.
  const filterCustomerJoin = mode === "manual"
    ? `JOIN public.customers customer_filter ON customer_filter.id = ${alias}.customer_id`
    : "";
  const baseClauses = [scopedStoreClause(caller, `${alias}.store_id`)];
  if (recordType === "RECHARGE" && rechargeType !== "ALL") {
    baseClauses.push(`r.recharge_type = ${sqlText(rechargeType)}`);
  }
  if (mode === "manual") {
    if (customerName) baseClauses.push(`customer_filter.customer_name ILIKE '%' || ${sqlText(customerName)} || '%'`);
    if (birthDate) baseClauses.push(`customer_filter.birth_date = ${sqlText(birthDate)}::date`);
  } else {
    if (productId) baseClauses.push(`${alias}.product_id = ${productId}`);
    if (recordType === "VERIFICATION" && verificationType !== "ALL") {
      baseClauses.push(verificationType === "NORMAL"
        ? "v.verification_type IN ('NORMAL', 'SUPPLEMENT')"
        : `v.verification_type = ${sqlText(verificationType)}`);
    }
    if (startDate) baseClauses.push(`${alias}.submitted_at >= (${sqlText(startDate)}::date::timestamp AT TIME ZONE 'Asia/Shanghai')`);
    if (endDate) baseClauses.push(`${alias}.submitted_at < ((${sqlText(endDate)}::date + 1)::timestamp AT TIME ZONE 'Asia/Shanghai')`);
  }

  const listClauses = [...baseClauses];
  if (statusCategory === "PENDING") listClauses.push(`${alias}.record_status = 'PENDING'`);
  else if (statusCategory === "APPROVED") listClauses.push(`${alias}.record_status = 'APPROVED'`);
  else if (statusCategory === "REJECTED") listClauses.push(`${alias}.record_status IN ('REJECTED', 'VOIDED')`);
  if (cursorSubmittedAt) {
    listClauses.push(`(${alias}.submitted_at, ${alias}.id) < (${sqlText(cursorSubmittedAt)}::timestamptz, ${cursorId}::bigint)`);
  }

  const recordSelect = recordType === "RECHARGE"
    ? `r.id, r.recharge_code AS record_code, r.recharge_type AS original_type,
       r.unit_count, r.balance_before_count, r.balance_after_count,
       r.record_status, r.void_request_status, r.submitted_at, r.reviewed_at,
       TO_CHAR(r.submitted_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS cursor_submitted_at,
       FALSE AS has_face_request`
    : `v.id, v.verification_code AS record_code, v.verification_type AS original_type,
       v.unit_count, v.record_status, v.void_request_status, v.submitted_at, v.reviewed_at,
       TO_CHAR(v.submitted_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS cursor_submitted_at,
       (NULLIF(BTRIM(v.face_request_id), '') IS NOT NULL) AS has_face_request`;
  const teacherJoin = `LEFT JOIN public.teachers t
                         ON t.id = ${alias}.teacher_id
                        AND ${teacherBusinessAttributionSourceCondition(alias, recordType)}`;
  const baseJoin = `JOIN public.customers c
                      ON c.id = ${alias}.customer_id
                    JOIN public.stores s ON s.id = ${alias}.store_id
                    JOIN public.products p ON p.id = ${alias}.product_id
                    ${teacherJoin}`;
  const summarySql = `SELECT COUNT(*) AS total,
                             COUNT(*) FILTER (WHERE ${alias}.record_status = 'PENDING') AS pending,
                             COUNT(*) FILTER (WHERE ${alias}.record_status = 'APPROVED') AS approved,
                             COUNT(*) FILTER (WHERE ${alias}.record_status IN ('REJECTED', 'VOIDED')) AS rejected
                        FROM public.${table} ${alias}
                        ${filterCustomerJoin}
                       WHERE ${baseClauses.join(" AND ")}`;
  const buildListSql = (effectivePage) => `WITH page_records AS (
                    SELECT ${alias}.*
                      FROM public.${table} ${alias}
                      ${filterCustomerJoin}
                     WHERE ${listClauses.join(" AND ")}
                     ORDER BY ${alias}.submitted_at DESC, ${alias}.id DESC
                     LIMIT ${exportAll ? 1001 : numberedPage ? pageSize : limit + 1}
                     ${!exportAll && numberedPage ? `OFFSET ${(effectivePage - 1) * pageSize}` : ""}
                   )
                   SELECT ${recordSelect},
                          c.customer_code, c.customer_name, c.birth_date,
                          s.id AS store_id, s.store_code, s.store_name,
                          s.province AS store_province, s.city AS store_city,
                          s.district AS store_district, s.address_detail AS store_address_detail,
                          p.id AS product_id, p.product_code, p.product_name,
                          t.id AS teacher_id, t.teacher_code, t.teacher_name
                     FROM page_records ${alias}
                    ${baseJoin}
                   ORDER BY ${alias}.submitted_at DESC, ${alias}.id DESC
                   `;
  const productsSql = `SELECT p.id AS product_id, p.product_code, p.product_name, p.product_status
                          FROM public.products p
                         WHERE p.product_status = 'ACTIVE'
                            OR EXISTS (
                              SELECT 1
                                FROM public.${table} product_record
                               WHERE product_record.product_id = p.id
                                 AND ${scopedStoreClause(caller, "product_record.store_id")}
                            )
                         ORDER BY CASE WHEN p.product_status = 'ACTIVE' THEN 0 ELSE 1 END,
                                  p.product_name, p.product_code`;

  // Count first, then clamp the requested page before loading display joins.
  // A rapid filter change can otherwise leave the client briefly requesting a
  // page that existed for the previous filter, producing an avoidable error or
  // an empty result under the stress dataset.
  const [summaryRows, productRows] = exportAll ? [[], []] : await Promise.all([
    executeSql(summarySql),
    executeSql(productsSql)
  ]);
  const summary = summaryRows[0] || {};
  const filteredTotal = Number(
    statusCategory === "PENDING" ? summary.pending
      : statusCategory === "APPROVED" ? summary.approved
        : statusCategory === "REJECTED" ? summary.rejected
          : summary.total
    || 0
  );
  const totalPages = Math.max(1, Math.ceil(filteredTotal / pageSize));
  const effectivePage = numberedPage ? Math.min(page, totalPages) : 1;
  const rawRecords = await executeSql(buildListSql(effectivePage));
  if (exportAll && rawRecords.length > 1000) fail("匹配结果超过1000条，请缩小查询范围后导出。", "EXPORT_LIMIT_EXCEEDED");
  const hasMore = exportAll ? false : numberedPage ? effectivePage < totalPages : rawRecords.length > limit;
  const pageRows = exportAll || numberedPage ? rawRecords : rawRecords.slice(0, limit);
  const last = pageRows[pageRows.length - 1];
  return {
    ok: true,
    scopeMode: caller.scopeMode,
    storeId: caller.storeId ? String(caller.storeId) : "",
    storeCode: caller.storeCode,
    storeName: caller.storeName,
    storeStatus: caller.storeStatus || "",
    recordType,
    summary: {
      total: Number(summary.total || 0),
      pending: Number(summary.pending || 0),
      approved: Number(summary.approved || 0),
      rejected: Number(summary.rejected || 0)
    },
    products: productRows.map((product) => ({
      productId: String(product.product_id),
      productCode: product.product_code,
      productName: product.product_name,
      productStatus: product.product_status
    })),
    records: pageRows.map((record) => ({
      id: String(record.id),
      recordCode: record.record_code,
      originalType: record.original_type,
      unitCount: Number(record.unit_count || 0),
      balanceBeforeCount: record.balance_before_count === null || record.balance_before_count === undefined ? null : Number(record.balance_before_count),
      balanceAfterCount: record.balance_after_count === null || record.balance_after_count === undefined ? null : Number(record.balance_after_count),
      recordStatus: record.record_status,
      voidRequestStatus: record.void_request_status,
      submittedAt: record.submitted_at,
      reviewedAt: record.reviewed_at,
      customerCode: record.customer_code,
      customerName: record.customer_name,
      birthDate: record.birth_date,
      storeId: String(record.store_id),
      storeCode: record.store_code,
      storeName: record.store_name,
      storeProvince: record.store_province,
      storeCity: record.store_city,
      storeDistrict: record.store_district,
      storeAddressDetail: record.store_address_detail,
      productId: String(record.product_id),
      productCode: record.product_code,
      productName: record.product_name,
      teacherId: record.teacher_id === null || record.teacher_id === undefined ? "" : String(record.teacher_id),
      teacherCode: record.teacher_code || "",
      teacherName: record.teacher_name || "",
      hasFaceRequest: databaseBoolean(record.has_face_request)
    })),
    total: exportAll ? pageRows.length : filteredTotal,
    ...(exportAll ? { exportAll: true } : {}),
    page: effectivePage,
    pageSize,
    totalPages,
    hasMore,
    nextCursor: !numberedPage && hasMore && last ? { submittedAt: last.cursor_submitted_at, id: String(last.id) } : null
  };
}

function customerListPageSize(event = {}) {
  const size = event.customerPageSize === undefined ? 20 : Number(event.customerPageSize);
  if (!Number.isInteger(size) || size < 1 || size > 100) fail("客户列表每页数量必须是 1 至 100。", "BAD_REQUEST");
  return size;
}

async function getStoreDashboard(event = {}) {
  const caller = await activeScopedQueryCaller(event);
  if (!caller.storeId) fail("总部查看门店主页时必须选择具体门店。", "STORE_REQUIRED");
  const storeId = businessQueryDatabaseId(caller.storeId, "门店");
  const dashboardCustomerPage = (value, label) => {
    const requested = Number(value || 1);
    if (!Number.isInteger(requested) || requested < 1) fail(`${label}分页必须是正整数。`, "BAD_REQUEST");
    return Math.min(requested, 100000);
  };
  const customerPage = dashboardCustomerPage(event.activeCustomerPage || event.customerPage, "活跃客户");
  const archivedCustomerPage = dashboardCustomerPage(event.archivedCustomerPage, "封存客户");
  const customerPageSize = customerListPageSize(event);
  const customerOffset = (customerPage - 1) * customerPageSize;
  const archivedCustomerOffset = (archivedCustomerPage - 1) * customerPageSize;
  const dashboardCustomersSql = (status, offset) =>
    `SELECT c.id AS customer_id, c.customer_code, c.customer_name, c.birth_date,
            c.customer_status,
            (SELECT COALESCE(SUM(recharge.unit_count), 0)::bigint
               FROM public.recharge_records recharge
              WHERE recharge.customer_id = c.id
                AND recharge.recharge_type = 'NEW'
                AND recharge.record_status = 'APPROVED') AS total_recharge_count,
            (SELECT COALESCE(SUM(v.unit_count), 0)::bigint
               FROM public.verification_records v
              WHERE v.customer_id = c.id
                AND v.record_status = 'APPROVED'
                AND v.verification_type IN ('NORMAL', 'SUPPLEMENT')) AS total_verification_count,
            COALESCE(COUNT(b.product_id) FILTER (
              WHERE b.total_recharge_count > 0 OR b.total_verification_count > 0
            ), 0) AS product_count,
            COALESCE(SUM(b.remaining_count), 0) AS remaining_count,
            GREATEST(c.latest_recharge_at, c.latest_verification_at) AS last_business_at
       FROM public.customers c
       LEFT JOIN public.customer_product_balances b ON b.customer_id = c.id
      WHERE c.created_store_id = ${storeId}::bigint
        AND c.customer_status = ${customerStatusSql(status)}
      GROUP BY c.id, c.customer_code, c.customer_name, c.birth_date,
               c.customer_status, c.total_recharge_count,
               c.latest_recharge_at, c.latest_verification_at
      ORDER BY c.created_at DESC, c.id DESC
      LIMIT ${customerPageSize} OFFSET ${offset}`;
  const layout = await getStoreBindingLayout();
  const accountJoin = layout === "stores"
    ? "LEFT JOIN public.staff_accounts account ON account.id = s.store_account_id"
    : `LEFT JOIN public.staff_store_assignments assignment
         ON assignment.store_id = s.id AND assignment.assignment_status = 'ACTIVE'
       LEFT JOIN public.staff_accounts account ON account.id = assignment.staff_account_id`;
  // Project totals are derived only from approved orders handled by this
  // store. Customer status and customer.created_store_id must not remove
  // historical business. Only NORMAL and EXPERIENCE remain in the current
  // verification model; legacy VOID reduces remaining units but is not reported as a refund. Remaining
  // is floored per customer/product ledger before the project-level sum, and
  // EXPERIENCE never consumes purchased units.
  //
  // A project-wide subtraction is deliberately not used for the displayed
  // balance: one customer's negative raw balance must never cancel another
  // customer's available units. The response therefore also returns the raw
  // aggregate and its customer-level zero-floor adjustment. Refunds are
  // reported along two independent axes: whether a paid verification had
  // already taken effect when the refund took effect, and how much of the
  // final customer-by-product balance the refund actually consumes.
  const [storeRows, projects, customerCountRows, customers, archivedCustomerCountRows, archivedCustomers] = await Promise.all([
    executeSql(
    `SELECT s.id, s.store_code, s.store_name, s.province, s.city, s.district,
            s.address_detail, s.store_status,
            contact.contact_name, contact.contact_phone, account.auth_uid
       FROM public.stores s
       ${accountJoin}
       LEFT JOIN LATERAL (
         SELECT sc.contact_name, sc.contact_phone
           FROM public.store_contacts sc
          WHERE sc.store_id = s.id
            AND sc.contact_status = 'ACTIVE'
          ORDER BY sc.is_primary DESC, sc.id ASC
          LIMIT 1
       ) contact ON TRUE
      WHERE s.id = ${storeId}::bigint
      LIMIT 1`
    ),
    executeSql(
    `WITH store_business_events AS (
       SELECT r.customer_id, r.product_id,
              COALESCE(r.reviewed_at, r.submitted_at) AS effective_at,
              CASE WHEN r.recharge_type = 'NEW' THEN r.unit_count ELSE 0 END::bigint AS recharge_count,
              CASE WHEN r.recharge_type = 'REFUND' THEN r.unit_count ELSE 0 END::bigint AS refund_count,
              CASE WHEN r.recharge_type = 'VOID' THEN r.unit_count ELSE 0 END::bigint AS legacy_void_count,
              0::bigint AS verification_count,
              0::bigint AS experience_count
         FROM public.recharge_records r
        WHERE r.store_id = ${storeId}::bigint
          AND r.record_status = 'APPROVED'
          AND r.recharge_type IN ('NEW', 'REFUND', 'VOID')
       UNION ALL
       SELECT v.customer_id, v.product_id,
              COALESCE(v.reviewed_at, v.submitted_at) AS effective_at,
              0::bigint AS recharge_count,
              0::bigint AS refund_count,
              0::bigint AS legacy_void_count,
              CASE WHEN v.verification_type IN ('NORMAL', 'SUPPLEMENT') THEN v.unit_count ELSE 0 END::bigint AS verification_count,
              CASE WHEN v.verification_type = 'EXPERIENCE' THEN v.unit_count ELSE 0 END::bigint AS experience_count
         FROM public.verification_records v
        WHERE v.store_id = ${storeId}::bigint
          AND v.record_status = 'APPROVED'
          AND v.verification_type IN ('NORMAL', 'SUPPLEMENT', 'EXPERIENCE')
     ), customer_product_totals AS (
       SELECT event.customer_id, event.product_id,
              SUM(event.recharge_count) AS total_recharge_count,
              SUM(event.verification_count) AS total_verification_count,
              SUM(event.experience_count) AS total_experience_count,
              SUM(event.refund_count) AS total_refund_count,
              SUM(event.legacy_void_count) AS total_legacy_void_count,
              GREATEST(
                SUM(event.recharge_count)
                  - SUM(event.legacy_void_count)
                  - SUM(event.verification_count),
                0
              ) AS balance_before_refund_count,
              LEAST(
                SUM(event.refund_count),
                GREATEST(
                  SUM(event.recharge_count)
                    - SUM(event.legacy_void_count)
                    - SUM(event.verification_count),
                  0
                )
              ) AS refund_from_remaining_count,
              GREATEST(
                SUM(event.refund_count)
                  - GREATEST(
                    SUM(event.recharge_count)
                      - SUM(event.legacy_void_count)
                      - SUM(event.verification_count),
                    0
                  ),
                0
              ) AS refund_excess_over_remaining_count,
              SUM(event.recharge_count)
                - SUM(event.refund_count)
                - SUM(event.legacy_void_count)
                - SUM(event.verification_count) AS raw_remaining_count,
              GREATEST(
                SUM(event.recharge_count)
                  - SUM(event.refund_count)
                  - SUM(event.legacy_void_count)
                  - SUM(event.verification_count),
                0
              ) AS remaining_count,
              GREATEST(
                SUM(event.recharge_count)
                  - SUM(event.refund_count)
                  - SUM(event.legacy_void_count)
                  - SUM(event.verification_count),
                0
              ) - (
                SUM(event.recharge_count)
                  - SUM(event.refund_count)
                  - SUM(event.legacy_void_count)
                  - SUM(event.verification_count)
              ) AS balance_floor_adjustment
         FROM store_business_events event
        GROUP BY event.customer_id, event.product_id
     ), first_paid_verification AS (
       SELECT event.customer_id, event.product_id,
              MIN(event.effective_at) AS first_paid_verification_at
         FROM store_business_events event
        WHERE event.verification_count > 0
        GROUP BY event.customer_id, event.product_id
     ), project_balance_totals AS (
       SELECT customer_product.product_id,
              SUM(customer_product.total_recharge_count) AS total_recharge_count,
              SUM(customer_product.total_verification_count) AS total_verification_count,
              SUM(customer_product.total_experience_count) AS total_experience_count,
              SUM(customer_product.total_refund_count) AS total_refund_count,
              SUM(customer_product.total_legacy_void_count) AS total_legacy_void_count,
              SUM(customer_product.refund_from_remaining_count) AS refund_from_remaining_count,
              SUM(customer_product.refund_excess_over_remaining_count) AS refund_excess_over_remaining_count,
              SUM(customer_product.raw_remaining_count) AS raw_remaining_count,
              SUM(customer_product.balance_floor_adjustment) AS balance_floor_adjustment,
              SUM(customer_product.remaining_count) AS remaining_count
         FROM customer_product_totals customer_product
        GROUP BY customer_product.product_id
     ), project_refund_relationships AS (
       SELECT event.product_id,
              SUM(CASE
                WHEN paid.first_paid_verification_at IS NULL
                  OR paid.first_paid_verification_at > event.effective_at
                THEN event.refund_count ELSE 0 END) AS refund_before_consumption_count,
              SUM(CASE
                WHEN paid.first_paid_verification_at IS NOT NULL
                  AND paid.first_paid_verification_at <= event.effective_at
                THEN event.refund_count ELSE 0 END) AS refund_after_consumption_count,
              COUNT(DISTINCT CASE
                WHEN paid.first_paid_verification_at IS NULL
                  OR paid.first_paid_verification_at > event.effective_at
                THEN event.customer_id END) AS refund_before_consumption_customer_count,
              COUNT(DISTINCT CASE
                WHEN paid.first_paid_verification_at IS NOT NULL
                  AND paid.first_paid_verification_at <= event.effective_at
                THEN event.customer_id END) AS refund_after_consumption_customer_count
         FROM store_business_events event
         LEFT JOIN first_paid_verification paid
           ON paid.customer_id = event.customer_id
          AND paid.product_id = event.product_id
        WHERE event.refund_count > 0
        GROUP BY event.product_id
     ), project_members AS (
       SELECT p.id AS product_id
         FROM public.products p
        WHERE p.product_status = 'ACTIVE'
       UNION
       SELECT event.product_id
         FROM store_business_events event
     )
     SELECT p.id AS product_id, p.product_code, p.product_name, p.product_status,
            COALESCE(totals.total_recharge_count, 0) AS total_recharge_count,
            COALESCE(totals.total_verification_count, 0) AS total_verification_count,
            COALESCE(totals.total_experience_count, 0) AS total_experience_count,
            COALESCE(totals.total_refund_count, 0) AS total_refund_count,
            COALESCE(totals.total_legacy_void_count, 0) AS total_legacy_void_count,
            COALESCE(totals.refund_from_remaining_count, 0) AS refund_from_remaining_count,
            COALESCE(totals.refund_excess_over_remaining_count, 0) AS refund_after_consumption_balance_count,
            COALESCE(relationships.refund_before_consumption_count, 0) AS refund_before_consumption_count,
            COALESCE(relationships.refund_after_consumption_count, 0) AS refund_after_consumption_count,
            COALESCE(relationships.refund_before_consumption_customer_count, 0) AS refund_before_consumption_customer_count,
            COALESCE(relationships.refund_after_consumption_customer_count, 0) AS refund_after_consumption_customer_count,
            0::bigint AS refund_breakdown_unknown_count,
            COALESCE(totals.raw_remaining_count, 0) AS raw_remaining_count,
            COALESCE(totals.balance_floor_adjustment, 0) AS balance_floor_adjustment,
            COALESCE(totals.remaining_count, 0) AS remaining_count
       FROM project_members member
       JOIN public.products p ON p.id = member.product_id
       LEFT JOIN project_balance_totals totals ON totals.product_id = p.id
       LEFT JOIN project_refund_relationships relationships ON relationships.product_id = p.id
      ORDER BY p.product_name, p.product_code`
    ),
    executeSql(
      `SELECT COUNT(*) AS customer_total
         FROM public.customers
        WHERE created_store_id = ${storeId}::bigint
          AND customer_status = 'ACTIVE'`
    ),
    executeSql(dashboardCustomersSql("ACTIVE", customerOffset)),
    executeSql(
      `SELECT COUNT(*) AS customer_total
         FROM public.customers
        WHERE created_store_id = ${storeId}::bigint
          AND customer_status = 'ARCHIVED'`
    ),
    executeSql(dashboardCustomersSql("ARCHIVED", archivedCustomerOffset))
  ]);
  const store = storeRows[0];
  if (!store) fail("未找到当前登录账号绑定的门店。", "STORE_NOT_FOUND");
  const customerTotal = Number(customerCountRows?.[0]?.customer_total || 0);
  const customerPages = Math.max(1, Math.ceil(customerTotal / customerPageSize));
  const effectiveCustomerPage = Math.min(customerPage, customerPages);
  const archivedCustomerTotal = Number(archivedCustomerCountRows?.[0]?.customer_total || 0);
  const archivedCustomerPages = Math.max(1, Math.ceil(archivedCustomerTotal / customerPageSize));
  const effectiveArchivedCustomerPage = Math.min(archivedCustomerPage, archivedCustomerPages);
  if (effectiveCustomerPage !== customerPage) {
    customers.splice(0, customers.length, ...(await executeSql(
      dashboardCustomersSql("ACTIVE", (effectiveCustomerPage - 1) * customerPageSize)
    )));
  }
  if (effectiveArchivedCustomerPage !== archivedCustomerPage) {
    archivedCustomers.splice(0, archivedCustomers.length, ...(await executeSql(
      dashboardCustomersSql("ARCHIVED", (effectiveArchivedCustomerPage - 1) * customerPageSize)
    )));
  }

  return {
    ok: true,
    store: {
      ...store,
      auth_uid: String(store.auth_uid || ""),
      projects,
      teachers: [],
      customers,
      customer_total: customerTotal,
      customer_page: effectiveCustomerPage,
      customer_page_size: customerPageSize,
      archived_customers: archivedCustomers,
      archived_customer_total: archivedCustomerTotal,
      archived_customer_page: effectiveArchivedCustomerPage,
      archived_customer_page_size: customerPageSize
    }
  };
}

const STORE_ANALYTICS_METRICS = Object.freeze(["recharge", "verification", "experience", "refund"]);

function storeAnalyticsRange(event = {}) {
  const startDate = optionalBusinessQueryDate(event.startDate, "开始日期");
  const endDate = optionalBusinessQueryDate(event.endDate, "结束日期");
  if (Boolean(startDate) !== Boolean(endDate)) fail("开始日期和结束日期必须同时提供。", "BAD_REQUEST");
  if (startDate && startDate > endDate) fail("开始日期不能晚于结束日期。", "BAD_REQUEST");
  const allTime = event.allTime === true && !startDate && !endDate;
  if (startDate) {
    const days = Math.floor((Date.parse(`${endDate}T00:00:00.000Z`) - Date.parse(`${startDate}T00:00:00.000Z`)) / 86400000) + 1;
    if (days > 366) fail("单次统计范围不能超过 366 天。", "BAD_REQUEST");
  }
  return {
    startSql: startDate ? `${sqlText(startDate)}::date` : allTime ? "'2000-01-01'::date" : "(CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Shanghai')::date",
    endSql: endDate ? `${sqlText(endDate)}::date` : "(CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Shanghai')::date"
  };
}

function storeAnalyticsEventCte(storeId, range) {
  return `date_bounds AS (
      SELECT ${range.startSql} AS start_date, ${range.endSql} AS end_date
    ), time_bounds AS (
      SELECT start_date, end_date,
             start_date::timestamp AT TIME ZONE 'Asia/Shanghai' AS start_at,
             (end_date + 1)::timestamp AT TIME ZONE 'Asia/Shanghai' AS end_at
        FROM date_bounds
    ), business_events AS (
      SELECT CASE WHEN r.recharge_type = 'REFUND' THEN 'refund' ELSE 'recharge' END AS metric,
             r.store_id, r.product_id, ${trustedBusinessTeacherIdSql("r", "RECHARGE")} AS teacher_id,
             r.unit_count::bigint AS amount
        FROM public.recharge_records r
        CROSS JOIN time_bounds bounds
       WHERE r.store_id = ${storeId}::bigint
         AND r.record_status = 'APPROVED'
         AND r.recharge_type IN ('NEW', 'REFUND')
         AND r.submitted_at >= bounds.start_at
         AND r.submitted_at < bounds.end_at
      UNION ALL
      SELECT CASE WHEN v.verification_type = 'EXPERIENCE' THEN 'experience' ELSE 'verification' END AS metric,
             v.store_id, v.product_id, ${trustedBusinessTeacherIdSql("v", "VERIFICATION")} AS teacher_id,
             v.unit_count::bigint AS amount
        FROM public.verification_records v
        CROSS JOIN time_bounds bounds
       WHERE v.store_id = ${storeId}::bigint
         AND v.record_status = 'APPROVED'
         AND v.verification_type IN ('NORMAL', 'SUPPLEMENT', 'EXPERIENCE')
         AND v.submitted_at >= bounds.start_at
         AND v.submitted_at < bounds.end_at
    )`;
}

function storeAnalyticsCounts(row) {
  return {
    recharge: Number(row.recharge_count || 0),
    verification: Number(row.verification_count || 0),
    experience: Number(row.experience_count || 0),
    refund: Number(row.refund_count || 0)
  };
}

function storeAnalyticsDateText(value) {
  if (value instanceof Date && !Number.isNaN(value.valueOf())) return value.toISOString().slice(0, 10);
  const text = String(value || "");
  return text.match(/\d{4}-\d{2}-\d{2}/)?.[0] || text;
}

function storeAnalyticsMetricColumns(alias = "event") {
  return STORE_ANALYTICS_METRICS.map((metric) =>
    `COALESCE(SUM(${alias}.amount) FILTER (WHERE ${alias}.metric = '${metric}'), 0) AS ${metric}_count`
  ).join(",\n             ");
}

async function getStoreBusinessAnalytics(event = {}) {
  const caller = await activeScopedQueryCaller(event);
  if (!caller.storeId) fail("门店全局视图必须选择具体门店。", "STORE_REQUIRED");
  const storeId = businessQueryDatabaseId(caller.storeId, "门店");
  const range = storeAnalyticsRange(event);
  const eventCte = storeAnalyticsEventCte(storeId, range);
  const metricColumns = storeAnalyticsMetricColumns();

  const [storeRows, productRows, teacherRows] = await Promise.all([
    executeSql(
      `WITH ${eventCte}
       SELECT s.id AS store_id, s.store_code, s.store_name, s.store_status,
              COALESCE(contact.contact_phone, '') AS phone,
              bounds.start_date, bounds.end_date,
              ${metricColumns}
         FROM public.stores s
         CROSS JOIN date_bounds bounds
         LEFT JOIN business_events event ON event.store_id = s.id
         LEFT JOIN LATERAL (
           SELECT sc.contact_phone
             FROM public.store_contacts sc
            WHERE sc.store_id = s.id
              AND sc.contact_status = 'ACTIVE'
            ORDER BY sc.is_primary DESC, sc.id ASC
            LIMIT 1
         ) contact ON TRUE
        WHERE s.id = ${storeId}::bigint
        GROUP BY s.id, s.store_code, s.store_name, s.store_status,
                 contact.contact_phone, bounds.start_date, bounds.end_date`
    ),
    executeSql(
      `WITH ${eventCte}, product_members AS (
         SELECT p.id AS product_id
           FROM public.products p
          WHERE p.product_status = 'ACTIVE'
         UNION
         SELECT event.product_id
           FROM business_events event
       )
       SELECT p.id AS product_id, p.product_code, p.product_name, p.product_status,
              ${metricColumns}
         FROM product_members member
         JOIN public.products p ON p.id = member.product_id
         LEFT JOIN business_events event ON event.product_id = p.id
        GROUP BY p.id, p.product_code, p.product_name, p.product_status`
    ),
    executeSql(
      `WITH ${eventCte}, teacher_members AS (
         SELECT t.id AS teacher_id
           FROM public.teachers t
           JOIN public.staff_accounts account ON account.id = t.staff_account_id
          WHERE t.teacher_status = 'ACTIVE'
            AND account.account_status = 'ACTIVE'
         UNION
         SELECT event.teacher_id
           FROM business_events event
          WHERE event.teacher_id IS NOT NULL
       ), teacher_counts AS (
         SELECT t.id AS teacher_id, t.teacher_code, t.teacher_name, t.teacher_status,
                COALESCE(account.phone, '') AS phone,
                ${metricColumns}
           FROM teacher_members member
           JOIN public.teachers t ON t.id = member.teacher_id
           LEFT JOIN public.staff_accounts account ON account.id = t.staff_account_id
           LEFT JOIN business_events event ON event.teacher_id = t.id
          GROUP BY t.id, t.teacher_code, t.teacher_name, t.teacher_status, account.phone
       ), unassigned_counts AS (
         SELECT NULL::bigint AS teacher_id, ''::text AS teacher_code,
                '未指定老师'::text AS teacher_name, 'HISTORICAL'::text AS teacher_status,
                ''::text AS phone,
                ${metricColumns}
           FROM business_events event
          WHERE event.teacher_id IS NULL
         HAVING COALESCE(SUM(event.amount), 0) > 0
       )
       SELECT * FROM teacher_counts
       UNION ALL
       SELECT * FROM unassigned_counts`
    )
  ]);

  const store = storeRows[0];
  if (!store) fail("未找到门店统计资料。", "STORE_NOT_FOUND");
  const products = productRows.map((row) => ({
    productId: String(row.product_id),
    productCode: String(row.product_code || ""),
    productName: String(row.product_name || ""),
    status: String(row.product_status || ""),
    ...storeAnalyticsCounts(row)
  }));
  const teachers = teacherRows.map((row) => ({
    teacherId: row.teacher_id === null || row.teacher_id === undefined ? "" : String(row.teacher_id),
    teacherCode: String(row.teacher_code || ""),
    teacherName: String(row.teacher_name || ""),
    phone: String(row.phone || ""),
    status: String(row.teacher_status || ""),
    ...storeAnalyticsCounts(row)
  }));
  const storeSummary = {
    storeId: String(store.store_id),
    storeCode: String(store.store_code || ""),
    storeName: String(store.store_name || ""),
    phone: String(store.phone || ""),
    status: String(store.store_status || ""),
    ...storeAnalyticsCounts(store)
  };
  const dimensions = {};
  STORE_ANALYTICS_METRICS.forEach((metric) => {
    const descending = (a, b) => Number(b.value || 0) - Number(a.value || 0) || String(a.name || "").localeCompare(String(b.name || ""), "zh-CN");
    dimensions[metric] = {
      stores: [{ id: storeSummary.storeId, name: storeSummary.storeName, phone: storeSummary.phone, value: storeSummary[metric] }],
      teachers: teachers.map((teacher) => ({ id: teacher.teacherId, name: teacher.teacherName, phone: teacher.phone, value: teacher[metric] })).sort(descending),
      products: products.map((product) => ({ id: product.productId, name: product.productName, phone: "", value: product[metric] })).sort(descending)
    };
  });
  return {
    ok: true,
    range: { startDate: storeAnalyticsDateText(store.start_date), endDate: storeAnalyticsDateText(store.end_date) },
    store: storeSummary,
    products: products.sort((a, b) => {
      const aTotal = STORE_ANALYTICS_METRICS.reduce((sum, metric) => sum + a[metric], 0);
      const bTotal = STORE_ANALYTICS_METRICS.reduce((sum, metric) => sum + b[metric], 0);
      return bTotal - aTotal || a.productName.localeCompare(b.productName, "zh-CN");
    }),
    totals: storeAnalyticsCounts(store),
    dimensions
  };
}

async function requireTeacherExperienceQuotaLifecycleSchema() {
  const rows = await executeSql(
    `SELECT TO_REGCLASS('public.teacher_product_experience_quotas') IS NOT NULL AS has_quota_table,
            TO_REGCLASS('public.teacher_experience_quota_usages') IS NOT NULL AS has_quota_usage_table,
            EXISTS (
              SELECT 1 FROM information_schema.columns
               WHERE table_schema = 'public'
                 AND table_name = 'teacher_product_experience_quotas'
                 AND column_name = 'quota_status'
            ) AS has_quota_status`
  );
  const schema = rows?.[0] || {};
  if (!databaseBoolean(schema.has_quota_table) || !databaseBoolean(schema.has_quota_usage_table)
      || !databaseBoolean(schema.has_quota_status)) {
    fail("体验额度生命周期尚未启用，请先执行迁移 048。", "DATABASE_SCHEMA_MISSING");
  }
}

async function getTeacherExperienceEntitlements(event = {}) {
  const caller = await activeBusinessCaller(event);
  if (caller.role !== "teacher") {
    fail("只有老师账号可以读取并使用自己的体验次数。", "FORBIDDEN");
  }
  await requireTeacherExperienceQuotaLifecycleSchema();
  const requestedTeacherId = String(event.teacherId || "").trim();
  if (requestedTeacherId && requestedTeacherId !== String(caller.teacherId)) {
    fail("老师账号只能读取自己的体验额度。", "FORBIDDEN");
  }
  const teacherId = positiveDatabaseId(caller.teacherId, "老师");

  // The timer performs the month-boundary reset proactively.  This targeted
  // call is a race-safe fallback for a delayed timer or a newly read quota.
  await executeSql(
    `SELECT public.reset_teacher_experience_quota(q.id)
       FROM public.teacher_product_experience_quotas q
      WHERE q.teacher_id = ${sqlText(teacherId)}::bigint
        AND q.quota_status = 'ACTIVE'
        AND q.quota_month < public.teacher_experience_quota_month()`
  );

  const rows = await executeSql(
    `SELECT q.id, q.teacher_id, q.product_id, q.monthly_allowance, q.quota_month,
            q.available_count, q.used_count, q.manual_recharge_count, q.monthly_reset_at,
            p.product_code, p.product_name, p.product_status,
            COALESCE((
              SELECT SUM(u.unit_count)::bigint
                FROM public.teacher_experience_quota_usages u
                JOIN public.verification_records usage_verification
                  ON usage_verification.id = u.verification_id
               WHERE u.teacher_id = q.teacher_id
                 AND u.product_id = q.product_id
                 AND usage_verification.teacher_id = u.teacher_id
                 AND usage_verification.product_id = u.product_id
                 AND usage_verification.record_status = 'APPROVED'
                 AND usage_verification.verification_type = 'EXPERIENCE'
                 AND ${teacherBusinessAttributionSourceCondition("usage_verification", "VERIFICATION")}
            ), 0)::bigint AS total_experience_count
       FROM public.teacher_product_experience_quotas q
       JOIN public.teachers t ON t.id = q.teacher_id
       JOIN public.staff_accounts a ON a.id = t.staff_account_id
       JOIN public.products p ON p.id = q.product_id
      WHERE q.teacher_id = ${sqlText(teacherId)}::bigint
        AND t.teacher_status = 'ACTIVE'
        AND a.role_code = 'teacher'
        AND a.account_status = 'ACTIVE'
        AND p.product_status = 'ACTIVE'
        AND q.quota_status = 'ACTIVE'
        AND q.available_count > 0
      ORDER BY p.product_name, p.product_code, q.id`
  );
  return {
    ok: true,
    teacherId: String(teacherId),
    entitlements: rows.map((row) => ({
      id: String(row.id),
      teacherId: String(row.teacher_id),
      productId: String(row.product_id),
      productCode: String(row.product_code || ""),
      productName: String(row.product_name || ""),
      productStatus: String(row.product_status || ""),
      monthlyAllowance: Number(row.monthly_allowance || 0),
      quotaMonth: row.quota_month,
      availableCount: Number(row.available_count || 0),
      usedCount: Number(row.used_count || 0),
      totalExperienceCount: Number(row.total_experience_count || 0),
      totalUsedCount: Number(row.total_experience_count || 0),
      manualRechargeCount: Number(row.manual_recharge_count || 0),
      monthlyResetAt: row.monthly_reset_at
    }))
  };
}

async function listActiveTeachers(event = {}) {
  // Teachers are not permanently assigned to one store in the canonical
  // schema. A real active store caller may choose only teachers whose profile
  // and login account are both active.
  const caller = await activeBusinessCaller(event);
  const rows = caller.role === "teacher" ? [{
    teacher_id: caller.teacherId,
    teacher_code: caller.teacherCode,
    teacher_name: caller.teacherName,
    teacher_phone: caller.teacherPhone
  }] : await executeSql(
    `SELECT t.id AS teacher_id, t.teacher_code, t.teacher_name, a.phone AS teacher_phone
       FROM public.teachers t
      JOIN public.staff_accounts a ON a.id = t.staff_account_id
      WHERE t.teacher_status = 'ACTIVE'
        AND a.role_code = 'teacher'
        AND a.account_status = 'ACTIVE'
      ORDER BY t.teacher_name, t.teacher_code
      LIMIT 1000`
  );
  return {
    ok: true,
    teachers: rows.map((teacher) => ({
      teacherId: String(teacher.teacher_id),
      teacherCode: teacher.teacher_code,
      teacherName: teacher.teacher_name,
      teacherPhone: teacher.teacher_phone
    }))
  };
}

async function listActiveProducts(event = {}) {
  await activeBusinessCaller(event);
  const rows = await executeSql(
    `SELECT id AS product_id, product_code, product_name
       FROM public.products
      WHERE product_status = 'ACTIVE'
      ORDER BY product_name, product_code
      LIMIT 1000`
  );
  return {
    ok: true,
    products: rows.map((product) => ({
      productId: String(product.product_id),
      productCode: product.product_code,
      productName: product.product_name
    }))
  };
}

async function rechargeProductGiftSchemaAvailable() {
  const rows = await executeSql(
    `SELECT TO_REGCLASS('public.recharge_product_gifts') IS NOT NULL AS ready`
  );
  return databaseBoolean(rows?.[0]?.ready);
}

async function listActiveRetailProducts(event = {}) {
  await activeBusinessCaller(event);
  const rows = await executeSql(
    `SELECT TO_REGCLASS('public.retail_products') IS NOT NULL AS ready`
  );
  if (!databaseBoolean(rows?.[0]?.ready)) {
    fail("产品主档尚未启用，请先执行迁移 060。", "DATABASE_SCHEMA_MISSING");
  }
  const products = await executeSql(
    `SELECT id AS product_id, product_code, product_name
       FROM public.retail_products
      WHERE product_status = 'ACTIVE'
      ORDER BY product_name, product_code, id
      LIMIT 1000`
  );
  return {
    ok: true,
    products: products.map((item) => ({
      productId: String(item.product_id),
      productCode: String(item.product_code || ""),
      productName: String(item.product_name || "")
    }))
  };
}

async function requireRetailProductPurchaseSchema() {
  const rows = await executeSql(
    `SELECT TO_REGCLASS('public.retail_product_purchase_records') IS NOT NULL AS has_table,
            TO_REGPROCEDURE('public.review_retail_product_purchase(bigint,bigint,text,text)') IS NOT NULL AS has_review,
            COALESCE(POSITION(
              'STORE_RETAIL_PRODUCT_TEACHER_OPTIONAL_V65' IN PG_GET_FUNCTIONDEF(
                TO_REGPROCEDURE('public.validate_retail_product_purchase_insert()')
              )
            ), 0) > 0 AS has_optional_teacher`
  );
  if (!databaseBoolean(rows?.[0]?.has_table)
      || !databaseBoolean(rows?.[0]?.has_review)
      || !databaseBoolean(rows?.[0]?.has_optional_teacher)) {
    fail("产品购买数据库尚未启用门店可选业务老师规则，请先依次执行迁移 062 和 065。", "DATABASE_SCHEMA_MISSING");
  }
}

async function createRetailProductPurchaseApplication(event = {}) {
  const caller = await activeBusinessCaller(event);
  await requireRetailProductPurchaseSchema();
  const customerCode = String(event.customerCode || "").trim();
  if (!customerCode || customerCode.length > 96) fail("必须先确认本门店的活跃客户。", "CUSTOMER_REQUIRED");
  const retailProductId = positiveDatabaseId(event.retailProductId ?? event.productId, "产品");
  const unitCount = Number(event.unitCount);
  if (!Number.isInteger(unitCount) || unitCount < 1 || unitCount > 999) {
    fail("购买数量必须是 1 至 999 的整数。", "INVALID_UNIT_COUNT");
  }
  const message = String(event.message || "").trim();
  if (message.length > 500) fail("填报留言不能超过 500 个字符。", "MESSAGE_TOO_LONG");
  const idempotencyKey = rechargeSubmissionKey(event.clientRequestId);
  const [customers, products] = await Promise.all([
    executeSql(
      `SELECT id, customer_code, customer_name
         FROM public.customers
        WHERE customer_code = ${sqlText(customerCode)}
          AND created_store_id = ${caller.storeId}
          AND customer_status = 'ACTIVE'
        LIMIT 1`
    ),
    executeSql(
      `SELECT id, product_code, product_name
         FROM public.retail_products
        WHERE id = ${sqlText(retailProductId)}::bigint
          AND product_status = 'ACTIVE'
        LIMIT 1`
    )
  ]);
  const customer = customers[0];
  const product = products[0];
  if (!customer) fail("未找到本门店已确认的活跃客户。", "CUSTOMER_NOT_FOUND");
  if (!product) fail("所选产品不存在或已经封存，请重新选择。", "RETAIL_PRODUCT_NOT_ACTIVE");
  const requestedTeacherId = String(event.teacherId || "").trim();
  if (caller.role === "teacher" && requestedTeacherId && requestedTeacherId !== String(caller.teacherId)) {
    fail("老师账号只能把产品购买绑定到本人。", "FORBIDDEN");
  }
  const teacherId = caller.role === "teacher"
    ? positiveDatabaseId(caller.teacherId, "老师")
    : (requestedTeacherId ? positiveDatabaseId(requestedTeacherId, "老师") : "");
  let selectedTeacher = null;
  if (teacherId) {
    const teachers = await executeSql(
      `SELECT t.id, t.teacher_code, t.teacher_name
         FROM public.teachers t
         JOIN public.staff_accounts a ON a.id = t.staff_account_id
        WHERE t.id = ${sqlText(teacherId)}::bigint
          AND t.teacher_status = 'ACTIVE'
          AND a.role_code = 'teacher'
          AND a.account_status = 'ACTIVE'
        LIMIT 1`
    );
    selectedTeacher = teachers[0] || null;
    if (!selectedTeacher) fail("所选老师不存在或已经封存，请重新选择。", "TEACHER_NOT_ACTIVE");
  }
  const rows = await executeSql(
    `WITH inserted AS (
       INSERT INTO public.retail_product_purchase_records
         (store_id, teacher_id, customer_id, retail_product_id, unit_count,
          submitted_by_account_id, message, idempotency_key,
          product_code_snapshot, product_name_snapshot)
       VALUES (${caller.storeId}::bigint, ${teacherId ? `${sqlText(teacherId)}::bigint` : "NULL"},
               ${sqlText(customer.id)}::bigint, ${sqlText(retailProductId)}::bigint, ${unitCount},
               ${caller.staffId}::bigint, ${sqlText(message)}, ${sqlText(idempotencyKey)},
               ${sqlText(product.product_code)}, ${sqlText(product.product_name)})
       ON CONFLICT (idempotency_key) DO NOTHING
       RETURNING *, TRUE AS created_now
     )
     SELECT * FROM inserted
     UNION ALL
     SELECT purchase.*, FALSE AS created_now
       FROM public.retail_product_purchase_records purchase
      WHERE purchase.idempotency_key = ${sqlText(idempotencyKey)}
        AND NOT EXISTS (SELECT 1 FROM inserted)
     LIMIT 1`
  );
  const record = rows[0];
  if (!record) fail("产品购买申请未能写入数据库，请稍后重试。", "RETAIL_PRODUCT_PURCHASE_CREATE_FAILED");
  const sameRequest = String(record.store_id) === String(caller.storeId)
    && String(record.teacher_id || "") === String(teacherId)
    && String(record.customer_id) === String(customer.id)
    && String(record.retail_product_id) === String(retailProductId)
    && String(record.submitted_by_account_id) === String(caller.staffId)
    && Number(record.unit_count) === unitCount
    && String(record.message || "") === message;
  if (!sameRequest) fail("该防重复提交编号已经用于另一张产品购买单，请刷新页面后重新提交。", "IDEMPOTENCY_CONFLICT");
  return {
    ok: true,
    createdNow: databaseBoolean(record.created_now),
    purchaseId: String(record.id), purchaseCode: String(record.purchase_code || ""),
    recordStatus: String(record.record_status || "PENDING"), submittedAt: record.submitted_at,
    unitCount: Number(record.unit_count || 0),
    customer: { customerCode: customer.customer_code, customerName: customer.customer_name },
    product: { productId: String(product.id), productCode: product.product_code, productName: product.product_name },
    teacher: selectedTeacher ? {
      teacherId: String(selectedTeacher.id),
      teacherCode: selectedTeacher.teacher_code,
      teacherName: selectedTeacher.teacher_name
    } : null
  };
}

function normalizeRechargeProductGifts(value, refund) {
  if (value === undefined || value === null) return [];
  if (!Array.isArray(value)) fail("产品赠予清单格式无效。", "INVALID_PRODUCT_GIFTS");
  if (refund && value.length) fail("退费申请不能附带产品赠予。", "PRODUCT_GIFTS_RECHARGE_ONLY");
  if (value.length > 20) fail("一张充值单最多赠予 20 种产品。", "TOO_MANY_PRODUCT_GIFTS");
  const seen = new Set();
  return value.map((item, index) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) {
      fail("产品赠予清单格式无效。", "INVALID_PRODUCT_GIFTS");
    }
    const retailProductId = positiveDatabaseId(item.retailProductId ?? item.productId, "赠予产品");
    if (seen.has(retailProductId)) fail("同一种赠予产品只能加入一次。", "DUPLICATE_PRODUCT_GIFT");
    seen.add(retailProductId);
    const unitCount = Number(item.unitCount ?? item.quantity);
    if (!Number.isInteger(unitCount) || unitCount < 1 || unitCount > 999) {
      fail("赠予产品数量必须是 1 至 999 的整数。", "INVALID_PRODUCT_GIFT_COUNT");
    }
    return { displayOrder: index + 1, retailProductId, unitCount };
  });
}

function parsedProductGiftRows(value) {
  let rows = value;
  if (typeof rows === "string") {
    try { rows = JSON.parse(rows); } catch (_) { rows = []; }
  }
  return (Array.isArray(rows) ? rows : []).map((row) => ({
    id: row.id === undefined || row.id === null ? "" : String(row.id),
    retailProductId: String(row.retail_product_id ?? row.retailProductId ?? row.product_id ?? row.productId ?? ""),
    productCode: String(row.product_code_snapshot ?? row.productCode ?? row.product_code ?? ""),
    productName: String(row.product_name_snapshot ?? row.productName ?? row.product_name ?? ""),
    unitCount: Number(row.unit_count ?? row.unitCount ?? row.quantity ?? 0),
    displayOrder: Number(row.display_order ?? row.displayOrder ?? 0)
  })).filter((row) => row.retailProductId && row.unitCount > 0)
    .sort((left, right) => left.displayOrder - right.displayOrder || Number(left.id || 0) - Number(right.id || 0));
}

async function readRechargeProductGifts(rechargeId, schemaAvailable = null) {
  const ready = schemaAvailable === null ? await rechargeProductGiftSchemaAvailable() : schemaAvailable;
  if (!ready) return [];
  const rows = await executeSql(
    `SELECT id, retail_product_id, product_code_snapshot, product_name_snapshot,
            unit_count, display_order
       FROM public.recharge_product_gifts
      WHERE recharge_id = ${sqlText(rechargeId)}::bigint
      ORDER BY display_order, id`
  );
  return parsedProductGiftRows(rows);
}

function positiveDatabaseId(value, label) {
  const text = String(value ?? "").trim();
  if (!/^[1-9]\d{0,18}$/.test(text)) fail(`必须选择有效的${label}。`, "BAD_REQUEST");
  return text;
}

function rechargeSubmissionKey(value) {
  const text = String(value || "").trim();
  if (!/^[A-Za-z0-9][A-Za-z0-9_-]{7,63}$/.test(text)) {
    fail("充值申请缺少有效的防重复提交编号，请刷新页面后重试。", "IDEMPOTENCY_KEY_REQUIRED");
  }
  return text;
}

async function requireRechargeSubmissionSchema({ refund = false, giftRequired = false } = {}) {
  const rows = await executeSql(
    `SELECT EXISTS (
       SELECT 1
         FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'recharge_records'
          AND column_name = 'idempotency_key'
     ) AS has_idempotency_key,
     EXISTS (
       SELECT 1
         FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'recharge_records'
          AND column_name = 'teacher_id'
          AND is_nullable = 'YES'
     ) AS teacher_is_optional,
     EXISTS (
       SELECT 1
         FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'recharge_records'
          AND column_name = 'balance_before_count'
     ) AND EXISTS (
       SELECT 1
         FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'recharge_records'
          AND column_name = 'balance_after_count'
     ) AS has_refund_snapshots,
     TO_REGCLASS('public.recharge_product_gifts') IS NOT NULL AS has_gift_table,
     COALESCE(POSITION(
       'STORE_BUSINESS_TEACHER_OPTIONAL_V65' IN PG_GET_FUNCTIONDEF(
         TO_REGPROCEDURE('public.enforce_business_teacher_matrix_v65()')
       )
     ), 0) > 0 AS has_optional_teacher_guard`
  );
  if (!databaseBoolean(rows?.[0]?.has_idempotency_key)) {
    fail("充值单数据库缺少防重复提交字段，请先执行迁移 023。", "DATABASE_SCHEMA_MISSING");
  }
  if (!databaseBoolean(rows?.[0]?.teacher_is_optional)) {
    fail("充值单数据库尚未允许业务老师为空，请先执行迁移 065。", "DATABASE_SCHEMA_MISSING");
  }
  if (!databaseBoolean(rows?.[0]?.has_optional_teacher_guard)) {
    fail("充值与退费数据库尚未启用门店可选业务老师规则，请先执行迁移 065。", "DATABASE_SCHEMA_MISSING");
  }
  if (refund && !databaseBoolean(rows?.[0]?.has_refund_snapshots)) {
    fail("退费单数据库结构尚未启用，请先执行迁移 044。", "DATABASE_SCHEMA_MISSING");
  }
  if (giftRequired && !databaseBoolean(rows?.[0]?.has_gift_table)) {
    fail("充值产品赠予尚未启用，请先执行迁移 061。", "DATABASE_SCHEMA_MISSING");
  }
  return rows?.[0] || {};
}

async function createRechargeApplication(event) {
  const caller = await activeBusinessCaller(event);
  const applicationType = String(event.applicationType || "NEW").trim().toUpperCase();
  if (!["NEW", "REFUND"].includes(applicationType)) fail("申请类型只能是充值或退费。", "BAD_REQUEST");
  const refund = applicationType === "REFUND";
  const requestedProductGifts = normalizeRechargeProductGifts(event.productGifts, refund);
  const customerCode = String(event.customerCode || "").trim();
  if (!customerCode || customerCode.length > 96) fail("必须先确认本门店的活跃客户。", "CUSTOMER_REQUIRED");
  const productId = positiveDatabaseId(event.productId, "项目");
  const teacherIdText = String(event.teacherId ?? "").trim();
  if (caller.role === "teacher" && teacherIdText && teacherIdText !== String(caller.teacherId)) {
    fail(`老师账号只能把${refund ? "退费" : "充值"}申请绑定到本人。`, "FORBIDDEN");
  }
  const teacherId = caller.role === "teacher"
    ? positiveDatabaseId(caller.teacherId, "老师")
    : (teacherIdText ? positiveDatabaseId(teacherIdText, "老师") : null);
  const unitCount = Number(event.unitCount);
  if (!Number.isInteger(unitCount) || unitCount < 1 || unitCount > 999) {
    fail(`${refund ? "退费" : "充值"}次数必须是 1 至 999 的整数。`, "INVALID_UNIT_COUNT");
  }
  const message = String(event.message || "").trim();
  if (message.length > 500) fail("门店留言不能超过 500 个字符。", "MESSAGE_TOO_LONG");
  const idempotencyKey = rechargeSubmissionKey(event.clientRequestId);

  const rechargeSchema = await requireRechargeSubmissionSchema({ refund, giftRequired: requestedProductGifts.length > 0 });
  const hasGiftSchema = databaseBoolean(rechargeSchema.has_gift_table);
  const customers = await executeSql(
    `SELECT id, customer_code, customer_name
       FROM public.customers
      WHERE customer_code = ${sqlText(customerCode)}
        AND created_store_id = ${caller.storeId}
        AND customer_status = 'ACTIVE'
      LIMIT 1`
  );
  const customer = customers[0];
  if (!customer) fail("未找到本门店已确认的活跃客户。", "CUSTOMER_NOT_FOUND");

  const products = await executeSql(
    `SELECT id, product_code, product_name
       FROM public.products
      WHERE id = ${sqlText(productId)}::bigint
        AND product_status = 'ACTIVE'
      LIMIT 1`
  );
  const product = products[0];
  if (!product) fail("所选项目不存在或已经封存，请重新选择。", "PRODUCT_NOT_ACTIVE");

  let productGifts = [];
  if (requestedProductGifts.length) {
    const giftIds = requestedProductGifts.map((item) => `${sqlText(item.retailProductId)}::bigint`).join(", ");
    const giftProducts = await executeSql(
      `SELECT id, product_code, product_name
         FROM public.retail_products
        WHERE product_status = 'ACTIVE'
          AND id IN (${giftIds})`
    );
    const giftById = new Map(giftProducts.map((item) => [String(item.id), item]));
    productGifts = requestedProductGifts.map((item) => {
      const giftProduct = giftById.get(item.retailProductId);
      if (!giftProduct) fail("所选赠予产品不存在或已经封存，请重新选择。", "RETAIL_PRODUCT_NOT_ACTIVE");
      return {
        ...item,
        productCode: String(giftProduct.product_code || ""),
        productName: String(giftProduct.product_name || "")
      };
    });
  }

  let teacher = null;
  if (teacherId) {
    const teachers = await executeSql(
      `SELECT t.id, t.teacher_code, t.teacher_name
         FROM public.teachers t
         JOIN public.staff_accounts a ON a.id = t.staff_account_id
        WHERE t.id = ${sqlText(teacherId)}::bigint
          AND t.teacher_status = 'ACTIVE'
          AND a.role_code = 'teacher'
          AND a.account_status = 'ACTIVE'
        LIMIT 1`
    );
    teacher = teachers[0] || null;
    if (!teacher) fail("所选老师不存在或已经封存，请重新选择。", "TEACHER_NOT_ACTIVE");
  }
  const teacherIdSql = teacherId ? `${sqlText(teacherId)}::bigint` : "NULL";

  const giftSourceSql = productGifts.length
    ? `VALUES ${productGifts.map((item) => `(${item.displayOrder}::smallint, ${sqlText(item.retailProductId)}::bigint, ${item.unitCount}::integer, ${sqlText(item.productCode)}::text, ${sqlText(item.productName)}::text)`).join(", ")}`
    : `SELECT NULL::smallint, NULL::bigint, NULL::integer, NULL::text, NULL::text WHERE FALSE`;
  const giftWriteCte = hasGiftSchema ? `, gift_source(display_order, retail_product_id, unit_count, product_code_snapshot, product_name_snapshot) AS (
       ${giftSourceSql}
     ), inserted_gifts AS (
       INSERT INTO public.recharge_product_gifts
         (recharge_id, retail_product_id, display_order, unit_count,
          store_id, customer_id, teacher_id, product_code_snapshot, product_name_snapshot)
       SELECT inserted.id, gift_source.retail_product_id, gift_source.display_order, gift_source.unit_count,
              inserted.store_id, inserted.customer_id, inserted.teacher_id,
              gift_source.product_code_snapshot, gift_source.product_name_snapshot
         FROM inserted
         JOIN gift_source ON TRUE
       RETURNING id
     )` : "";
  const insertedGiftCountSql = hasGiftSchema ? `(SELECT COUNT(*)::bigint FROM inserted_gifts)` : `0::bigint`;
  const rows = await executeSql(
    `WITH current_balance AS (
       SELECT b.total_recharge_count, GREATEST(b.remaining_count, 0) AS remaining_count
         FROM public.customer_product_balances b
        WHERE b.customer_id = ${sqlText(customer.id)}::bigint
          AND b.product_id = ${sqlText(productId)}::bigint
        LIMIT 1
     ), inserted AS (
       INSERT INTO public.recharge_records
         (recharge_type, store_id, teacher_id, customer_id, product_id,
          unit_count, record_status, submitted_by_account_id, message, idempotency_key,
          balance_before_count)
       SELECT ${sqlText(applicationType)}, ${caller.storeId}, ${teacherIdSql},
              ${sqlText(customer.id)}::bigint, ${sqlText(productId)}::bigint,
              ${unitCount}, 'PENDING', ${caller.staffId}, ${sqlText(message)}, ${sqlText(idempotencyKey)},
              CASE WHEN ${sqlText(applicationType)} = 'REFUND'
                   THEN COALESCE((SELECT remaining_count FROM current_balance), 0)
                   ELSE NULL END
        WHERE ${sqlText(applicationType)} = 'NEW'
           OR COALESCE((SELECT total_recharge_count FROM current_balance), 0) >= ${unitCount}
       ON CONFLICT (idempotency_key) WHERE idempotency_key IS NOT NULL DO NOTHING
       RETURNING id, recharge_code, recharge_type, store_id, teacher_id, customer_id,
                 product_id, unit_count, record_status, submitted_by_account_id,
                 submitted_at, message, idempotency_key, balance_before_count, balance_after_count
     )${giftWriteCte}
     SELECT *, TRUE AS created_now, ${insertedGiftCountSql} AS inserted_gift_count FROM inserted
     UNION ALL
     SELECT r.id, r.recharge_code, r.recharge_type, r.store_id, r.teacher_id,
            r.customer_id, r.product_id, r.unit_count, r.record_status,
            r.submitted_by_account_id, r.submitted_at, r.message,
            r.idempotency_key, r.balance_before_count, r.balance_after_count,
            FALSE AS created_now, 0::bigint AS inserted_gift_count
       FROM public.recharge_records r
      WHERE r.idempotency_key = ${sqlText(idempotencyKey)}
        AND NOT EXISTS (SELECT 1 FROM inserted)
     LIMIT 1`
  );
  const record = rows[0];
  if (!record) fail(refund ? "退费次数超过该项目尚未退费的总购买次数，请重新填写。" : "充值申请未能写入数据库，请稍后重试。", refund ? "REFUND_COUNT_EXCEEDS_PURCHASED" : "RECHARGE_CREATE_FAILED");

  const storedProductGifts = await readRechargeProductGifts(record.id, hasGiftSchema);
  const sameGiftRequest = storedProductGifts.length === productGifts.length
    && storedProductGifts.every((stored, index) => (
      stored.retailProductId === productGifts[index].retailProductId
      && stored.unitCount === productGifts[index].unitCount
      && stored.displayOrder === productGifts[index].displayOrder
    ));
  const sameRequest = record.recharge_type === applicationType
    && String(record.store_id) === String(caller.storeId)
    && String(record.submitted_by_account_id) === String(caller.staffId)
    && String(record.teacher_id || "") === String(teacherId || "")
    && String(record.customer_id) === String(customer.id)
    && String(record.product_id) === String(productId)
    && Number(record.unit_count) === unitCount
    && String(record.message || "") === message
    && sameGiftRequest;
  if (!sameRequest) {
    fail(`该防重复提交编号已经用于另一张${refund ? "退费" : "充值"}单，请刷新页面后重新提交。`, "IDEMPOTENCY_CONFLICT");
  }

  return {
    ok: true,
    createdNow: databaseBoolean(record.created_now),
    rechargeId: String(record.id),
    rechargeCode: record.recharge_code,
    rechargeType: record.recharge_type,
    recordStatus: record.record_status,
    submittedAt: record.submitted_at,
    unitCount: Number(record.unit_count),
    balanceBeforeCount: record.balance_before_count === null || record.balance_before_count === undefined ? null : Number(record.balance_before_count),
    balanceAfterCount: record.balance_after_count === null || record.balance_after_count === undefined ? null : Number(record.balance_after_count),
    customer: { customerCode: customer.customer_code, customerName: customer.customer_name },
    product: { productId: String(product.id), productCode: product.product_code, productName: product.product_name },
    teacher: teacher ? { teacherId: String(teacher.id), teacherCode: teacher.teacher_code, teacherName: teacher.teacher_name } : null,
    productGifts: storedProductGifts
  };
}

async function requireVerificationSubmissionSchema() {
  const rows = await executeSql(
    `SELECT EXISTS (
       SELECT 1
         FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'verification_records'
          AND column_name = 'idempotency_key'
     ) AS has_idempotency_key,
     TO_REGPROCEDURE(
       'public.create_verification_with_face_photo(character varying,bigint,bigint,bigint,bigint,integer,character varying,bigint,text,text,character varying,character varying,character varying)'
     ) IS NOT NULL AS has_photo_create_function,
     COALESCE(POSITION(
       'PROFILE_BOUND' IN PG_GET_FUNCTIONDEF(TO_REGPROCEDURE(
         'public.create_verification_with_face_photo(character varying,bigint,bigint,bigint,bigint,integer,character varying,bigint,text,text,character varying,character varying,character varying)'
       ))
     ), 0) > 0 AS has_profile_snapshot,
     TO_REGCLASS('public.device_signal_outbox') IS NOT NULL AS has_device_signal_outbox,
     COALESCE(POSITION(
       'device_signal_outbox' IN PG_GET_FUNCTIONDEF(TO_REGPROCEDURE(
         'public.create_verification_with_face_photo(character varying,bigint,bigint,bigint,bigint,integer,character varying,bigint,text,text,character varying,character varying,character varying)'
       ))
     ), 0) > 0 AS has_atomic_device_signal,
     COALESCE(POSITION(
       'STORE_BUSINESS_TEACHER_OPTIONAL_V65' IN PG_GET_FUNCTIONDEF(
         TO_REGPROCEDURE('public.enforce_business_teacher_matrix_v65()')
       )
     ), 0) > 0 AS has_optional_teacher`
  );
  if (!databaseBoolean(rows?.[0]?.has_idempotency_key)
      || !databaseBoolean(rows?.[0]?.has_photo_create_function)
      || !databaseBoolean(rows?.[0]?.has_profile_snapshot)
      || !databaseBoolean(rows?.[0]?.has_device_signal_outbox)
      || !databaseBoolean(rows?.[0]?.has_atomic_device_signal)
      || !databaseBoolean(rows?.[0]?.has_optional_teacher)) {
    fail("核销单数据库缺少可选次数、照片证据、设备信号或门店可选老师规则，请先依次执行迁移 026、037、038、041、064 和 065。", "DATABASE_SCHEMA_MISSING");
  }
}

async function requireVerificationFaceSubjectSchema() {
  const rows = await executeSql(
    `SELECT EXISTS (
              SELECT 1 FROM information_schema.columns
               WHERE table_schema = 'public' AND table_name = 'verification_photo_drafts'
                 AND column_name = 'face_subject_type'
            ) AS draft_subject_column,
            EXISTS (
              SELECT 1 FROM information_schema.columns
               WHERE table_schema = 'public' AND table_name = 'verification_records'
                 AND column_name = 'face_subject_type'
            ) AS record_subject_column`
  );
  const schema = rows?.[0] || {};
  if (!databaseBoolean(schema.draft_subject_column)
      || !databaseBoolean(schema.record_subject_column)) {
    fail("核销人脸主体结构尚未启用，请先执行迁移 049。", "DATABASE_SCHEMA_MISSING");
  }
}

async function requireCustomerFaceExperienceSchema() {
  const rows = await executeSql(
    `SELECT
            TO_REGPROCEDURE(
              'public.create_experience_verification_with_customer_face_photo(bigint,bigint,bigint,bigint,integer,bigint,text,character varying,character varying,character varying)'
            ) IS NOT NULL AS create_function`
  );
  const schema = rows?.[0] || {};
  if (!databaseBoolean(schema.create_function)) {
    fail("老师赠送体验核销的可选次数与客户人脸结构尚未启用，请先执行迁移 054 和 064。", "DATABASE_SCHEMA_MISSING");
  }
}

async function requireVerificationBleSchema() {
  const rows = await executeSql(
    `SELECT TO_REGCLASS('public.verification_ble_qualifications') IS NOT NULL AS qualifications,
            TO_REGCLASS('public.verification_ble_authorizations') IS NOT NULL AS authorizations,
            EXISTS (
              SELECT 1 FROM information_schema.columns
               WHERE table_schema = 'public'
                 AND table_name = 'verification_ble_qualifications'
                 AND column_name = 'units_reserved_at'
            ) AS unit_reservation_column,
            TO_REGPROCEDURE('public.reserve_verification_ble_units(bigint)') IS NOT NULL
              AS unit_reservation_function`
  );
  const schema = rows?.[0] || {};
  if (!databaseBoolean(schema.qualifications)
      || !databaseBoolean(schema.authorizations)
      || !databaseBoolean(schema.unit_reservation_column)
      || !databaseBoolean(schema.unit_reservation_function)) {
    fail("BLE 授权前次数预留尚未启用，请先执行并验收数据库迁移 072。", "BLE_SCHEMA_MISSING");
  }
}

function verificationDeviceType(productName) {
  const normalizedProductName = String(productName || "").replace(/\s+/g, "");
  if (normalizedProductName.includes("魔法柔肤")) return "LASER-BLE";
  pinyinFunction ||= require("pinyin-pro").pinyin;
  const segments = pinyinFunction(String(productName || ""), { toneType: "none", type: "array" });
  const value = segments.join("").toLowerCase().replace(/[^a-z0-9]/g, "");
  if (!value) fail("项目名称无法转换成有效设备类型，请先修正项目名称。", "BLE_DEVICE_TYPE_INVALID");
  return value.slice(0, 128);
}

function isSupportedVerificationDeviceSerial(value) {
  const serial = String(value || "").trim().toUpperCase();
  return /^LA[0-9A-F]{12}$/.test(serial) || /^NCM[0-9A-F]{11}$/.test(serial);
}

function verificationBleName(serial) {
  const normalized = String(serial || "").trim().toUpperCase();
  if (/^LA[0-9A-F]{12}$/.test(normalized)) return `LA-${normalized.slice(-6)}`;
  if (/^NCM[0-9A-F]{11}$/.test(normalized)) return `NCM-${normalized.slice(-6)}`;
  return "";
}

function sha256Text(value) {
  return crypto.createHash("sha256").update(String(value || ""), "utf8").digest("hex");
}

function verificationBleAuthorizationPayload(input) {
  return {
    command: "enter_work",
    device_id: input.deviceId,
    device_type: input.deviceType,
    nonce: input.nonce,
    usage_count: input.unitCount,
    issued_at: input.issuedAt,
    expire_at: input.expireAt
  };
}

function verificationBleSignature(nonce) {
  const normalizedNonce = String(nonce || "").trim().toLowerCase();
  if (!/^[0-9a-f]{32}$/.test(normalizedNonce)) {
    fail("设备随机数格式不正确。", "BLE_NONCE_INVALID");
  }
  return Array.from(normalizedNonce, (character, index) => {
    const offset = (4 * (index + 1)) % 7;
    if (character >= "0" && character <= "9") {
      return String.fromCharCode(48 + ((character.charCodeAt(0) - 48 + offset) % 10));
    }
    return String.fromCharCode(97 + ((character.charCodeAt(0) - 97 + offset) % 26));
  }).join("");
}

async function reserveVerificationBleUnits(qualificationId) {
  let rows;
  try {
    rows = await executeSql(
      `SELECT * FROM public.reserve_verification_ble_units(${sqlText(qualificationId)}::bigint)`
    );
  } catch (error) {
    const detail = String(error?.message || "").toLowerCase();
    if (detail.includes("insufficient purchased units for ble authorization")) {
      fail("该客户所选项目的剩余次数不足，禁止签发设备授权。", "INSUFFICIENT_BALANCE");
    }
    if (detail.includes("insufficient teacher experience quota for ble authorization")) {
      fail("该老师该项目的体验次数不足，禁止签发设备授权。", "TEACHER_EXPERIENCE_QUOTA_EXHAUSTED");
    }
    if (detail.includes("no active configured experience quota for ble authorization")) {
      fail("该老师尚未配置有效的项目体验次数，禁止签发设备授权。", "TEACHER_EXPERIENCE_QUOTA_NOT_CONFIGURED");
    }
    if (detail.includes("ble qualification is not active")) {
      fail("90 秒 BLE 核销资格已过期，请重新拍照验证。", "BLE_QUALIFICATION_EXPIRED");
    }
    if (detail.includes("ble qualification is already finalized")) {
      fail("这笔核销已经完成，二维码窗口已永久关闭。", "BLE_ALREADY_FINALIZED");
    }
    throw error;
  }
  const reservation = rows?.[0];
  if (!reservation) {
    fail("数据库未确认本次核销次数预留，已禁止签发设备授权。", "BLE_UNIT_RESERVATION_FAILED");
  }
  return reservation;
}

async function createVerificationBleQualification(event) {
  const caller = await activeBusinessCaller(event);
  await requireVerificationSubmissionSchema();
  await requireVerificationFaceSubjectSchema();
  await requireVerificationBleSchema();
  const customerCode = String(event.customerCode || "").trim();
  if (!customerCode || customerCode.length > 96) fail("必须先确认本门店的活跃客户。", "CUSTOMER_REQUIRED");
  const productId = positiveDatabaseId(event.productId, "项目");
  const unitCount = Number(event.unitCount);
  if (!Number.isInteger(unitCount) || unitCount < 1 || unitCount > 999) {
    fail("核销次数必须由办理人员选择，并且是 1 至 999 的整数。", "INVALID_UNIT_COUNT");
  }
  const verificationType = String(event.verificationType || "").trim().toUpperCase();
  if (!["NORMAL", "EXPERIENCE"].includes(verificationType)) {
    fail("仅支持正常核销或体验核销。", "INVALID_VERIFICATION_TYPE");
  }
  const experienceVerification = verificationType === "EXPERIENCE";
  if (experienceVerification && caller.role !== "teacher") {
    fail("体验核销只能由老师账号赠送，门店和总部账号不能发起。", "FORBIDDEN");
  }
  const requestedTeacherId = String(event.teacherId || "").trim();
  if (caller.role === "teacher" && requestedTeacherId && requestedTeacherId !== String(caller.teacherId)) {
    fail("老师账号只能把核销绑定到本人。", "FORBIDDEN");
  }
  const teacherId = caller.role === "teacher"
    ? positiveDatabaseId(caller.teacherId, "老师")
    : (requestedTeacherId ? positiveDatabaseId(requestedTeacherId, "老师") : "");
  const message = String(event.message || "").trim();
  if (message.length > 500) fail("门店留言不能超过 500 个字符。", "MESSAGE_TOO_LONG");
  const faceRequestId = String(event.faceRequestId || "").trim();
  const faceEvidenceToken = String(event.faceEvidenceToken || "").trim();
  if (!/^[A-Za-z0-9_-]{8,128}$/.test(faceRequestId)) {
    fail("必须先完成现场拍照及所选客户的 1:1 人脸验证。", "FACE_VERIFICATION_REQUIRED");
  }
  if (!/^[0-9a-f]{48}$/.test(faceEvidenceToken)) {
    fail("现场人脸照片尚未安全保存，请重新拍照验证。", "FACE_PHOTO_EVIDENCE_REQUIRED");
  }
  if (experienceVerification) {
    await requireTeacherExperienceQuotaLifecycleSchema();
    await requireCustomerFaceExperienceSchema();
  }

  const customers = await executeSql(
    `SELECT id, customer_code, customer_name
       FROM public.customers
      WHERE customer_code = ${sqlText(customerCode)}
        AND created_store_id = ${caller.storeId}
        AND customer_status = 'ACTIVE'
      LIMIT 1`
  );
  const customer = customers[0];
  if (!customer) fail("未找到本门店已确认的活跃客户。", "CUSTOMER_NOT_FOUND");
  const products = await executeSql(
    `SELECT id, product_code, product_name
       FROM public.products
      WHERE id = ${sqlText(productId)}::bigint
        AND product_status = 'ACTIVE'
      LIMIT 1`
  );
  const selectedProduct = products[0];
  if (!selectedProduct) fail("所选项目不存在或已经封存，请重新选择。", "PRODUCT_NOT_ACTIVE");

  let selectedTeacher = null;
  if (teacherId) {
    const teachers = await executeSql(
      `SELECT teacher.id, teacher.teacher_code, teacher.teacher_name
         FROM public.teachers AS teacher
         JOIN public.staff_accounts AS account ON account.id = teacher.staff_account_id
        WHERE teacher.id = ${sqlText(teacherId)}::bigint
          AND teacher.teacher_status = 'ACTIVE'
          AND account.role_code = 'teacher'
          AND account.account_status = 'ACTIVE'
        LIMIT 1`
    );
    selectedTeacher = teachers[0] || null;
    if (!selectedTeacher) fail("所选老师不存在或已经封存，请重新选择。", "TEACHER_NOT_ACTIVE");
  }
  if (experienceVerification && !selectedTeacher) {
    fail("体验核销必须绑定当前老师。", "TEACHER_REQUIRED");
  }

  const draftRows = await executeSql(
    `SELECT evidence_token
       FROM public.verification_photo_drafts
      WHERE evidence_token = ${sqlText(faceEvidenceToken)}
        AND store_id = ${caller.storeId}
        AND customer_id = ${sqlText(customer.id)}::bigint
        AND submitted_by_account_id = ${caller.staffId}
        AND face_request_id = ${sqlText(faceRequestId)}
        AND face_subject_type = 'CUSTOMER'
        AND consumed_at IS NULL
        AND expires_at > CLOCK_TIMESTAMP()
      LIMIT 1`
  );
  if (!draftRows[0]) {
    fail("现场人脸照片已过期、已使用或不属于当前提交，请重新拍照验证。", "FACE_PHOTO_EVIDENCE_INVALID");
  }

  if (experienceVerification) {
    const quotaRows = await executeSql(
      `SELECT available_count
         FROM public.teacher_product_experience_quotas
        WHERE teacher_id = ${sqlText(teacherId)}::bigint
          AND product_id = ${sqlText(productId)}::bigint
        LIMIT 1`
    );
    if (!quotaRows[0]) fail("该老师尚未配置这个项目的体验次数。", "TEACHER_EXPERIENCE_QUOTA_NOT_CONFIGURED");
    if (Number(quotaRows[0].available_count || 0) < unitCount) {
      fail("该老师该项目的体验次数不足。", "TEACHER_EXPERIENCE_QUOTA_EXHAUSTED");
    }
  } else {
    const balanceRows = await executeSql(
      `SELECT remaining_count
         FROM public.customer_product_balances
        WHERE customer_id = ${sqlText(customer.id)}::bigint
          AND product_id = ${sqlText(productId)}::bigint
        LIMIT 1`
    );
    if (Number(balanceRows?.[0]?.remaining_count || 0) < unitCount) {
      fail("该客户所选项目的剩余次数不足。", "INSUFFICIENT_BALANCE");
    }
  }

  const idempotencyKey = rechargeSubmissionKey(event.clientRequestId);
  const deviceType = verificationDeviceType(selectedProduct.product_name);
  const existingRows = await executeSql(
    `SELECT qualification.*,
            GREATEST(0, LEAST(90,
              CEIL(EXTRACT(EPOCH FROM (qualification.expires_at - CLOCK_TIMESTAMP())))::integer
            )) AS valid_seconds,
            customer.customer_code, customer.customer_name,
            product.product_code, product.product_name,
            teacher.teacher_code, teacher.teacher_name
       FROM public.verification_ble_qualifications AS qualification
       JOIN public.customers AS customer ON customer.id = qualification.customer_id
       JOIN public.products AS product ON product.id = qualification.product_id
       LEFT JOIN public.teachers AS teacher ON teacher.id = qualification.teacher_id
      WHERE qualification.idempotency_key = ${sqlText(idempotencyKey)}
      LIMIT 1`
  );
  let qualification = existingRows[0];
  const matchesQualificationRequest = (row) => row
    && String(row.store_id) === String(caller.storeId)
    && String(row.submitted_by_account_id) === String(caller.staffId)
    && String(row.verification_type) === verificationType
    && String(row.teacher_id || "") === String(teacherId)
    && String(row.customer_id) === String(customer.id)
    && String(row.product_id) === String(productId)
    && Number(row.unit_count) === unitCount
    && String(row.face_request_id) === faceRequestId
    && String(row.face_evidence_token) === faceEvidenceToken;
  if (qualification) {
    if (!matchesQualificationRequest(qualification)) fail("该防重复提交编号已经用于另一笔核销。", "IDEMPOTENCY_CONFLICT");
  } else {
    const token = crypto.randomBytes(24).toString("hex");
    const teacherSql = teacherId ? `${sqlText(teacherId)}::bigint` : "NULL";
    try {
      await executeSql(
        `INSERT INTO public.verification_ble_qualifications
           (qualification_token, verification_type, store_id, teacher_id, customer_id,
            product_id, unit_count, submitted_by_account_id, message, face_request_id,
            face_evidence_token, idempotency_key, expected_device_type, expires_at)
         VALUES
           (${sqlText(token)}, ${sqlText(verificationType)}, ${caller.storeId}, ${teacherSql},
            ${sqlText(customer.id)}::bigint, ${sqlText(productId)}::bigint, ${unitCount},
            ${caller.staffId}, ${sqlText(message)}, ${sqlText(faceRequestId)},
            ${sqlText(faceEvidenceToken)}, ${sqlText(idempotencyKey)}, ${sqlText(deviceType)},
            NOW() + INTERVAL '90 seconds')`
      );
    } catch (error) {
      const detail = String(error?.message || "").toLowerCase();
      if (!detail.includes("unique") && !detail.includes("duplicate") && !detail.includes("23505")) throw error;
    }
    const insertedRows = await executeSql(
      `SELECT qualification.*,
              GREATEST(0, LEAST(90,
                CEIL(EXTRACT(EPOCH FROM (qualification.expires_at - CLOCK_TIMESTAMP())))::integer
              )) AS valid_seconds,
              customer.customer_code, customer.customer_name,
              product.product_code, product.product_name,
              teacher.teacher_code, teacher.teacher_name
         FROM public.verification_ble_qualifications AS qualification
         JOIN public.customers AS customer ON customer.id = qualification.customer_id
         JOIN public.products AS product ON product.id = qualification.product_id
         LEFT JOIN public.teachers AS teacher ON teacher.id = qualification.teacher_id
        WHERE qualification.idempotency_key = ${sqlText(idempotencyKey)}
        LIMIT 1`
    );
    qualification = insertedRows[0];
    if (!qualification) {
      fail("设备资格写入后未能读取，请稍后重试；本次没有扣次。", "BLE_QUALIFICATION_CREATE_FAILED");
    }
    if (!matchesQualificationRequest(qualification)) {
      fail("该防重复提交编号已经用于另一笔核销。", "IDEMPOTENCY_CONFLICT");
    }
  }

  if (qualification?.verification_id) {
    return recoverBusinessSubmission({ ...event, recordType: "VERIFICATION", clientRequestId: event.clientRequestId });
  }
  const validSeconds = Number(qualification.valid_seconds || 0);
  if (qualification.qualification_status === "CANCELLED" || validSeconds <= 0) {
    await executeSql(
      `UPDATE public.verification_ble_qualifications
          SET qualification_status = 'EXPIRED', updated_at = CLOCK_TIMESTAMP()
        WHERE id = ${sqlText(qualification.id)}::bigint
          AND verification_id IS NULL`
    );
    fail("本次人脸核验后的 90 秒 BLE 资格已过期，请重新拍照验证。", "BLE_QUALIFICATION_EXPIRED");
  }
  return {
    ok: true,
    complete: false,
    qualificationToken: qualification.qualification_token,
    qualificationStatus: qualification.qualification_status,
    expiresAt: qualification.expires_at,
    validSeconds,
    faceRequestId: qualification.face_request_id,
    expectedDeviceType: qualification.expected_device_type,
    unitCount: Number(qualification.unit_count),
    verificationType: qualification.verification_type,
    customer: { customerCode: customer.customer_code, customerName: customer.customer_name },
    product: { productId: String(selectedProduct.id), productCode: selectedProduct.product_code, productName: selectedProduct.product_name },
    teacher: selectedTeacher ? {
      teacherId: String(selectedTeacher.id), teacherCode: selectedTeacher.teacher_code, teacherName: selectedTeacher.teacher_name
    } : null
  };
}

async function recoverVerificationBleQualification(event) {
  const caller = await activeBusinessCaller(event);
  await requireVerificationBleSchema();
  const idempotencyKey = rechargeSubmissionKey(event.clientRequestId);
  const rows = await executeSql(
    `SELECT qualification.*,
            GREATEST(0, LEAST(90,
              CEIL(EXTRACT(EPOCH FROM (qualification.expires_at - CLOCK_TIMESTAMP())))::integer
            )) AS valid_seconds,
            customer.customer_code, customer.customer_name,
            product.product_code, product.product_name,
            teacher.teacher_code, teacher.teacher_name
       FROM public.verification_ble_qualifications AS qualification
       JOIN public.customers AS customer ON customer.id = qualification.customer_id
       JOIN public.products AS product ON product.id = qualification.product_id
       LEFT JOIN public.teachers AS teacher ON teacher.id = qualification.teacher_id
      WHERE qualification.idempotency_key = ${sqlText(idempotencyKey)}
      LIMIT 1`
  );
  const qualification = rows[0];
  if (!qualification) return { ok: true, found: false, complete: false };
  if (String(qualification.store_id) !== String(caller.storeId)
      || String(qualification.submitted_by_account_id) !== String(caller.staffId)) {
    fail("该 BLE 核销资格不属于当前账号和门店。", "FORBIDDEN");
  }
  if (qualification.verification_id) {
    return recoverBusinessSubmission({ ...event, recordType: "VERIFICATION" });
  }
  const authorizationRows = await executeSql(
    `SELECT authorization_status, verification_id, device_id, expires_at,
            GREATEST(0,
              CEIL(EXTRACT(EPOCH FROM (expires_at - CLOCK_TIMESTAMP())))::integer
            ) AS valid_seconds
       FROM public.verification_ble_authorizations
      WHERE qualification_id = ${sqlText(qualification.id)}::bigint
      LIMIT 1`
  );
  let authorization = authorizationRows[0] || null;
  if (authorization?.verification_id) {
    return recoverBusinessSubmission({ ...event, recordType: "VERIFICATION" });
  }
  const recoveredStatus = String(authorization?.authorization_status || "");
  const recoveredValidSeconds = Number(authorization?.valid_seconds || 0);
  if (recoveredStatus === "ISSUED" && recoveredValidSeconds <= 0) {
    await executeSql(
      `UPDATE public.verification_ble_authorizations
          SET authorization_status = 'EXPIRED', updated_at = CLOCK_TIMESTAMP()
        WHERE qualification_id = ${sqlText(qualification.id)}::bigint
          AND authorization_status = 'ISSUED'
          AND expires_at <= CLOCK_TIMESTAMP()`
    );
    authorization = { ...authorization, authorization_status: "EXPIRED", valid_seconds: 0 };
  }
  const authorizationStatus = String(authorization?.authorization_status || "");
  const authorizationIssued = ["ISSUED", "DEVICE_WORKING"].includes(authorizationStatus);
  const validSeconds = Number(qualification.valid_seconds || 0);
  const expired = validSeconds <= 0 || qualification.qualification_status === "EXPIRED";
  if (expired && qualification.qualification_status !== "EXPIRED") {
    await executeSql(
      `UPDATE public.verification_ble_qualifications
          SET qualification_status = 'EXPIRED', updated_at = CLOCK_TIMESTAMP()
        WHERE id = ${sqlText(qualification.id)}::bigint
          AND verification_id IS NULL`
    );
  }
  return {
    ok: true, found: true, complete: false,
    expired,
    qualificationToken: qualification.qualification_token,
    qualificationStatus: expired ? "EXPIRED" : qualification.qualification_status,
    expiresAt: qualification.expires_at,
    validSeconds: expired ? 0 : validSeconds,
    faceRequestId: qualification.face_request_id,
    authorizationIssued,
    authorizationStatus,
    authorizationDeviceId: authorization?.device_id || "",
    authorizationValidSeconds: Number(authorization?.valid_seconds || 0),
    expectedDeviceType: qualification.expected_device_type,
    unitCount: Number(qualification.unit_count),
    verificationType: qualification.verification_type,
    customer: { customerCode: qualification.customer_code, customerName: qualification.customer_name },
    product: {
      productId: String(qualification.product_id), productCode: qualification.product_code,
      productName: qualification.product_name
    },
    teacher: qualification.teacher_id ? {
      teacherId: String(qualification.teacher_id), teacherCode: qualification.teacher_code,
      teacherName: qualification.teacher_name
    } : null
  };
}

async function issueVerificationBleAuthorization(event) {
  const caller = await activeBusinessCaller(event);
  await requireVerificationBleSchema();
  const qualificationToken = String(event.qualificationToken || "").trim();
  const qrSn = String(event.qrSn || "").trim().toUpperCase();
  const qrCode = String(event.qrCode || "").trim();
  const device = event.deviceInfo && typeof event.deviceInfo === "object" ? event.deviceInfo : {};
  const deviceId = String(device.device_id || device.deviceId || "").trim().toUpperCase();
  const deviceType = String(device.device_type || device.deviceType || "").trim();
  const bleName = String(device.ble_name || device.bleName || "").trim();
  const nonce = String(device.nonce || "").trim().toLowerCase();
  const status = Number(device.status);
  if (!/^[0-9a-f]{48}$/.test(qualificationToken)) fail("BLE 核销资格无效。", "BLE_QUALIFICATION_INVALID");
  if (!isSupportedVerificationDeviceSerial(qrSn) || !/^\d{6}$/.test(qrCode)) fail("设备二维码格式不正确。", "BLE_QR_INVALID");
  if (deviceId !== qrSn) fail("二维码编号与蓝牙设备编号不一致。", "BLE_DEVICE_ID_MISMATCH");
  if (!/^[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*$/.test(deviceType)) fail("设备类型格式不正确。", "BLE_DEVICE_TYPE_INVALID");
  if (bleName !== verificationBleName(qrSn)) fail("设备蓝牙名称与二维码不一致。", "BLE_NAME_MISMATCH");
  if (!/^[0-9a-fA-F]{32}$/.test(nonce)) fail("设备随机数格式不正确。", "BLE_NONCE_INVALID");
  if (status !== 1) fail(status === 2 ? "设备正在服务中，不能重复授权。" : "设备尚未进入待机状态。", "BLE_DEVICE_NOT_READY");

  const qualificationRows = await executeSql(
    `SELECT qualification.*,
            FLOOR(EXTRACT(EPOCH FROM CLOCK_TIMESTAMP()))::bigint AS server_epoch_seconds,
            FLOOR(EXTRACT(EPOCH FROM qualification.expires_at))::bigint AS qualification_expires_epoch,
            GREATEST(0, LEAST(90,
              CEIL(EXTRACT(EPOCH FROM (qualification.expires_at - CLOCK_TIMESTAMP())))::integer
            )) AS valid_seconds
       FROM public.verification_ble_qualifications AS qualification
      WHERE qualification_token = ${sqlText(qualificationToken)}
        AND store_id = ${caller.storeId}
        AND submitted_by_account_id = ${caller.staffId}
      LIMIT 1`
  );
  const qualification = qualificationRows[0];
  if (!qualification) fail("未找到属于当前账号的 BLE 核销资格。", "BLE_QUALIFICATION_NOT_FOUND");
  if (qualification.verification_id || qualification.qualification_status === "COMPLETED") {
    fail("这笔核销已经完成，二维码窗口已永久关闭。", "BLE_ALREADY_FINALIZED");
  }
  if (Number(qualification.valid_seconds || 0) <= 0) {
    fail("90 秒 BLE 核销资格已过期，请重新拍照验证。", "BLE_QUALIFICATION_EXPIRED");
  }
  if (String(qualification.expected_device_type).toUpperCase() !== deviceType.toUpperCase()) {
    fail(`设备类型不匹配：本次需要 ${qualification.expected_device_type}。`, "BLE_DEVICE_TYPE_MISMATCH");
  }
  const canonicalDeviceType = String(qualification.expected_device_type);
  const magicSoftSkinProfile = canonicalDeviceType.toUpperCase() === "LASER-BLE";
  const magicSoftSkinSerial = /^LA[0-9A-F]{12}$/.test(qrSn);
  if (magicSoftSkinProfile !== magicSoftSkinSerial) {
    fail("魔法柔肤必须使用 LA 设备，其他项目不能使用 LA 设备。", "BLE_DEVICE_TYPE_MISMATCH");
  }

  const otherLiveAuthorizationRows = await executeSql(
    `SELECT ble_authorization.device_id, ble_authorization.authorization_status
       FROM public.verification_ble_authorizations AS ble_authorization
       JOIN public.verification_ble_qualifications AS other_qualification
         ON other_qualification.id = ble_authorization.qualification_id
      WHERE other_qualification.submitted_by_account_id = ${caller.staffId}
        AND ble_authorization.qualification_id <> ${sqlText(qualification.id)}::bigint
        AND ble_authorization.verification_id IS NULL
        AND (
          ble_authorization.authorization_status = 'DEVICE_WORKING'
          OR (
            ble_authorization.authorization_status = 'ISSUED'
            AND ble_authorization.expires_at > CLOCK_TIMESTAMP()
          )
        )
      LIMIT 1`
  );
  if (otherLiveAuthorizationRows[0]) {
    fail("上一份设备授权仍然有效，禁止扫描另一台设备或签发新授权；请等待原授权结束。", "BLE_PREVIOUS_AUTHORIZATION_ACTIVE");
  }

  const qrCodeHash = sha256Text(qrCode);
  const previousAuthorizationRows = await executeSql(
    `SELECT authorization_token, authorization_status, verification_id, qr_sn, qr_code_hash,
            device_id, device_type, nonce, unit_count,
            FLOOR(EXTRACT(EPOCH FROM issued_at))::bigint AS issued_epoch_seconds,
            FLOOR(EXTRACT(EPOCH FROM expires_at))::bigint AS expires_epoch_seconds,
            GREATEST(0, CEIL(EXTRACT(EPOCH FROM (expires_at - CLOCK_TIMESTAMP())))::integer) AS valid_seconds
       FROM public.verification_ble_authorizations
      WHERE qualification_id = ${sqlText(qualification.id)}::bigint
      LIMIT 1`
  );
  let previousAuthorization = previousAuthorizationRows[0] || null;
  if (previousAuthorization?.verification_id || previousAuthorization?.authorization_status === "FINALIZED") {
    fail("这笔核销已经完成，二维码窗口已永久关闭。", "BLE_ALREADY_FINALIZED");
  }
  if (previousAuthorization?.authorization_status === "DEVICE_WORKING") {
    fail("设备已经确认进入工作状态，正在恢复原核销工单。", "BLE_AUTHORIZATION_RECOVERY_REQUIRED");
  }
  if (previousAuthorization?.authorization_status === "ISSUED"
      && Number(previousAuthorization.valid_seconds || 0) <= 0) {
    await executeSql(
      `UPDATE public.verification_ble_authorizations
          SET authorization_status = 'EXPIRED', updated_at = CLOCK_TIMESTAMP()
        WHERE qualification_id = ${sqlText(qualification.id)}::bigint
          AND authorization_status = 'ISSUED'
          AND verification_id IS NULL
          AND expires_at <= CLOCK_TIMESTAMP()`
    );
    previousAuthorization = { ...previousAuthorization, authorization_status: "EXPIRED", valid_seconds: 0 };
  }
  if (previousAuthorization?.authorization_status === "ISSUED") {
    const sameAuthorizedDevice = String(previousAuthorization.qr_sn || "") === qrSn
      && String(previousAuthorization.qr_code_hash || "") === qrCodeHash
      && String(previousAuthorization.device_id || "").toUpperCase() === deviceId
      && String(previousAuthorization.device_type || "").toUpperCase() === canonicalDeviceType.toUpperCase()
      && Number(previousAuthorization.unit_count) === Number(qualification.unit_count);
    if (!sameAuthorizedDevice) {
      fail("本次90秒资格已绑定原设备，重复扫码只能连接同一台设备，禁止更换设备。", "BLE_AUTHORIZATION_DEVICE_LOCKED");
    }
  }
  if (previousAuthorization
      && !["ISSUED", "EXPIRED", "FAILED"].includes(String(previousAuthorization.authorization_status || ""))) {
    fail("原设备授权状态尚未结束，不能重复签发。", "BLE_AUTHORIZATION_ALREADY_ISSUED");
  }
  if (previousAuthorization
      && String(previousAuthorization.device_id || "").toUpperCase() !== deviceId) {
    fail("本次90秒资格已经绑定原设备，不能更换另一台设备。", "BLE_AUTHORIZATION_DEVICE_LOCKED");
  }

  // This is the authoritative pre-authorization gate. Migration 072 locks
  // the customer/product or teacher/product bucket, subtracts every other
  // live qualification reservation, and records this qualification exactly
  // once. No signature, token or device command is created before it succeeds.
  await reserveVerificationBleUnits(qualification.id);

  const issuedAt = Number(qualification.server_epoch_seconds);
  const qualificationExpireAt = Number(qualification.qualification_expires_epoch);
  const expireAt = Math.min(issuedAt + 30, qualificationExpireAt);
  if (expireAt <= issuedAt) {
    fail("90 秒 BLE 核销资格已过期，请重新拍照验证。", "BLE_QUALIFICATION_EXPIRED");
  }
  const payload = verificationBleAuthorizationPayload({
    deviceId, deviceType: canonicalDeviceType, nonce, unitCount: Number(qualification.unit_count), issuedAt, expireAt
  });
  const signature = verificationBleSignature(nonce);
  const authorizationToken = crypto.randomBytes(24).toString("hex");
  try {
    if (previousAuthorization) {
      const rotatedRows = await executeSql(
        `UPDATE public.verification_ble_authorizations
            SET authorization_token = ${sqlText(authorizationToken)},
                qr_sn = ${sqlText(qrSn)}, qr_code_hash = ${sqlText(qrCodeHash)},
                device_id = ${sqlText(deviceId)}, device_type = ${sqlText(canonicalDeviceType)},
                nonce = ${sqlText(nonce)}, unit_count = ${Number(qualification.unit_count)},
                issued_at = TO_TIMESTAMP(${issuedAt}), expires_at = TO_TIMESTAMP(${expireAt}),
                signature_hash = ${sqlText(sha256Text(signature))},
                authorization_status = 'ISSUED', verification_id = NULL,
                updated_at = CLOCK_TIMESTAMP()
          WHERE qualification_id = ${sqlText(qualification.id)}::bigint
            AND authorization_status IN ('ISSUED', 'EXPIRED', 'FAILED')
            AND verification_id IS NULL
            AND device_id = ${sqlText(deviceId)}
            AND authorization_token = ${sqlText(previousAuthorization.authorization_token)}
        RETURNING authorization_token`
      );
      if (!rotatedRows[0]) {
        fail("设备授权正在由另一条请求签发，已禁止重复授权。", "BLE_AUTHORIZATION_RACE");
      }
    } else {
      await executeSql(
        `INSERT INTO public.verification_ble_authorizations
          (authorization_token, qualification_id, qr_sn, qr_code_hash, device_id,
           device_type, nonce, unit_count, issued_at, expires_at, signature_hash)
         VALUES
          (${sqlText(authorizationToken)}, ${sqlText(qualification.id)}::bigint,
           ${sqlText(qrSn)}, ${sqlText(qrCodeHash)}, ${sqlText(deviceId)},
           ${sqlText(canonicalDeviceType)}, ${sqlText(nonce)}, ${Number(qualification.unit_count)},
           TO_TIMESTAMP(${issuedAt}), TO_TIMESTAMP(${expireAt}), ${sqlText(sha256Text(signature))})`
      );
    }
  } catch (error) {
    const detail = String(error?.message || "").toLowerCase();
    if (detail.includes("qualification_id")
        && (detail.includes("unique") || detail.includes("duplicate") || detail.includes("23505"))) {
      fail("设备授权正在由另一条请求签发，已禁止重复授权。", "BLE_AUTHORIZATION_RACE");
    }
    if (detail.includes("verification_ble_authorizations_device_id_nonce_key")) {
      fail(
        "数据库尚未执行允许设备重复随机码的迁移 071，请管理员先完成迁移后重试。",
        "BLE_NONCE_POLICY_NOT_MIGRATED"
      );
    }
    throw error;
  }
  await executeSql(
    `UPDATE public.verification_ble_qualifications
        SET qualification_status = 'AUTHORIZED', updated_at = CLOCK_TIMESTAMP()
      WHERE id = ${sqlText(qualification.id)}::bigint
        AND verification_id IS NULL`
  );
  return {
    ok: true,
    authorizationToken,
    expiresAt: new Date(expireAt * 1000).toISOString(),
    authCommand: {
      ver: "1.0",
      seq: 2,
      cmd: "auth",
      auth: {
        ...payload,
        signature
      }
    }
  };
}

async function confirmVerificationBleWorkStarted(event) {
  const caller = await activeBusinessCaller(event);
  await requireVerificationBleSchema();
  const authorizationToken = String(event.authorizationToken || "").trim();
  const result = event.deviceResult && typeof event.deviceResult === "object" ? event.deviceResult : {};
  const deviceId = String(result.device_id || result.deviceId || "").trim().toUpperCase();
  const deviceType = String(result.device_type || result.deviceType || "").trim();
  const nonce = String(result.nonce || "").trim();
  if (!/^[0-9a-f]{48}$/.test(authorizationToken)) fail("BLE 设备授权回执无效。", "BLE_AUTHORIZATION_INVALID");
  if (result.ok !== true || Number(result.status) !== 2) {
    fail("设备尚未确认进入工作状态，本次没有核销。", "BLE_DEVICE_NOT_WORKING");
  }
  const rows = await executeSql(
    `SELECT ble_authorization.*, qualification.verification_type, qualification.store_id,
            qualification.teacher_id, qualification.customer_id, qualification.product_id,
            qualification.submitted_by_account_id, qualification.message,
            qualification.face_request_id, qualification.face_evidence_token,
            qualification.idempotency_key, qualification.qualification_token,
            qualification.units_reserved_at
       FROM public.verification_ble_authorizations AS ble_authorization
       JOIN public.verification_ble_qualifications AS qualification
         ON qualification.id = ble_authorization.qualification_id
      WHERE ble_authorization.authorization_token = ${sqlText(authorizationToken)}
      LIMIT 1`
  );
  const authorization = rows[0];
  if (!authorization) fail("未找到 BLE 设备授权。", "BLE_AUTHORIZATION_NOT_FOUND");
  if (!authorization.units_reserved_at) {
    fail("这张设备授权没有通过次数预留，已禁止核销。", "BLE_UNIT_RESERVATION_REQUIRED");
  }
  if (String(authorization.store_id) !== String(caller.storeId)
      || String(authorization.submitted_by_account_id) !== String(caller.staffId)) {
    fail("该 BLE 授权不属于当前账号和门店。", "FORBIDDEN");
  }
  if (deviceId !== String(authorization.device_id)
      || deviceType.toUpperCase() !== String(authorization.device_type).toUpperCase()
      || nonce !== String(authorization.nonce)) {
    fail("设备工作回执与本次授权不一致，已禁止核销。", "BLE_DEVICE_RECEIPT_MISMATCH");
  }
  if (authorization.verification_id) {
    return recoverBusinessSubmission({
      ...event,
      recordType: "VERIFICATION",
      clientRequestId: String(authorization.idempotency_key)
    });
  }
  if (!["ISSUED", "DEVICE_WORKING"].includes(String(authorization.authorization_status))) {
    fail("这张一次性设备授权已经失效，禁止继续核销。", "BLE_AUTHORIZATION_NOT_ACTIVE");
  }
  if (authorization.authorization_status === "ISSUED"
      && new Date(authorization.expires_at).getTime() <= Date.now()) {
    await executeSql(
      `UPDATE public.verification_ble_authorizations
          SET authorization_status = 'EXPIRED', updated_at = CLOCK_TIMESTAMP()
        WHERE id = ${sqlText(authorization.id)}::bigint
          AND authorization_status = 'ISSUED'
          AND verification_id IS NULL`
    );
    fail("设备没有在一次性授权有效期内进入工作状态，本次没有核销。", "BLE_AUTHORIZATION_EXPIRED");
  }
  await executeSql(
    `UPDATE public.verification_ble_authorizations
        SET authorization_status = 'DEVICE_WORKING',
            updated_at = CLOCK_TIMESTAMP()
      WHERE id = ${sqlText(authorization.id)}::bigint
        AND authorization_status = 'ISSUED'
        AND verification_id IS NULL`
  );

  const customerRows = await executeSql(
    `SELECT customer_code FROM public.customers WHERE id = ${sqlText(authorization.customer_id)}::bigint LIMIT 1`
  );
  const finalResult = await finalizeVerificationApplicationInternal({
    ...event,
    storeId: String(authorization.store_id),
    customerCode: customerRows?.[0]?.customer_code,
    productId: String(authorization.product_id),
    unitCount: Number(authorization.unit_count),
    teacherId: authorization.teacher_id ? String(authorization.teacher_id) : "",
    verificationType: authorization.verification_type,
    message: authorization.message,
    faceRequestId: authorization.face_request_id,
    faceEvidenceToken: authorization.face_evidence_token,
    clientRequestId: String(authorization.idempotency_key),
    _trustedBleIdempotencyKey: String(authorization.idempotency_key)
  });
  await executeSql(
    `UPDATE public.verification_ble_authorizations
        SET authorization_status = 'FINALIZED', verification_id = ${sqlText(finalResult.verificationId)}::bigint,
            updated_at = CLOCK_TIMESTAMP()
      WHERE id = ${sqlText(authorization.id)}::bigint`
  );
  await executeSql(
    `UPDATE public.verification_ble_qualifications
        SET qualification_status = 'COMPLETED', verification_id = ${sqlText(finalResult.verificationId)}::bigint,
            updated_at = CLOCK_TIMESTAMP()
      WHERE id = ${sqlText(authorization.qualification_id)}::bigint`
  );
  return { ...finalResult, bleFinalized: true, bleDeviceId: deviceId };
}

async function finalizeVerificationApplicationInternal(event) {
  const caller = await activeBusinessCaller(event);
  const customerCode = String(event.customerCode || "").trim();
  if (!customerCode || customerCode.length > 96) fail("必须先确认本门店的活跃客户。", "CUSTOMER_REQUIRED");
  const productId = positiveDatabaseId(event.productId, "项目");
  const unitCount = Number(event.unitCount);
  if (!Number.isInteger(unitCount) || unitCount < 1 || unitCount > 999) {
    fail("核销次数必须由办理人员选择，并且是 1 至 999 的整数。", "INVALID_UNIT_COUNT");
  }
  const verificationType = String(event.verificationType || "").trim().toUpperCase();
  if (!["NORMAL", "EXPERIENCE"].includes(verificationType)) {
    fail("仅支持正常核销或体验核销。", "INVALID_VERIFICATION_TYPE");
  }
  const experienceVerification = verificationType === "EXPERIENCE";
  if (experienceVerification && caller.role !== "teacher") {
    fail("体验核销只能由老师账号赠送，门店和总部账号不能发起。", "FORBIDDEN");
  }
  const requestedTeacherId = String(event.teacherId || "").trim();
  if (caller.role === "teacher" && requestedTeacherId && requestedTeacherId !== String(caller.teacherId)) {
    fail("老师账号只能把核销绑定到本人。", "FORBIDDEN");
  }
  const teacherId = caller.role === "teacher"
    ? positiveDatabaseId(caller.teacherId, "老师")
    : (requestedTeacherId ? positiveDatabaseId(requestedTeacherId, "老师") : "");
  const message = String(event.message || "").trim();
  if (message.length > 500) fail("门店留言不能超过 500 个字符。", "MESSAGE_TOO_LONG");
  const faceRequestId = String(event.faceRequestId || "").trim();
  if (!/^[A-Za-z0-9_-]{8,128}$/.test(faceRequestId)) {
    fail("必须先完成现场拍照及所选客户的 1:1 人脸验证。", "FACE_VERIFICATION_REQUIRED");
  }
  const faceEvidenceToken = String(event.faceEvidenceToken || "").trim();
  if (!/^[0-9a-f]{48}$/.test(faceEvidenceToken)) {
    fail("现场人脸照片尚未安全保存，请重新拍照验证。", "FACE_PHOTO_EVIDENCE_REQUIRED");
  }
  const idempotencyKey = event._trustedBleIdempotencyKey
    ? String(event._trustedBleIdempotencyKey)
    : rechargeSubmissionKey(event.clientRequestId);
  await requireVerificationSubmissionSchema();
  await requireVerificationFaceSubjectSchema();
  if (experienceVerification) {
    await requireTeacherExperienceQuotaLifecycleSchema();
    await requireCustomerFaceExperienceSchema();
  }

  const customers = await executeSql(
    `SELECT id, customer_code, customer_name
       FROM public.customers
      WHERE customer_code = ${sqlText(customerCode)}
        AND created_store_id = ${caller.storeId}
        AND customer_status = 'ACTIVE'
      LIMIT 1`
  );
  const customer = customers[0];
  if (!customer) fail("未找到本门店已确认的活跃客户。", "CUSTOMER_NOT_FOUND");

  const products = await executeSql(
    `SELECT id, product_code, product_name
       FROM public.products
      WHERE id = ${sqlText(productId)}::bigint
        AND product_status = 'ACTIVE'
      LIMIT 1`
  );
  const product = products[0];
  if (!product) fail("所选项目不存在或已经封存，请重新选择。", "PRODUCT_NOT_ACTIVE");

  let teacher = null;
  if (teacherId) {
    const teachers = await executeSql(
      `SELECT t.id, t.teacher_code, t.teacher_name
         FROM public.teachers t
         JOIN public.staff_accounts a ON a.id = t.staff_account_id
        WHERE t.id = ${sqlText(teacherId)}::bigint
          AND t.teacher_status = 'ACTIVE'
          AND a.role_code = 'teacher'
          AND a.account_status = 'ACTIVE'
        LIMIT 1`
    );
    teacher = teachers[0] || null;
    if (!teacher) fail("所选老师不存在或已经封存，请重新选择。", "TEACHER_NOT_ACTIVE");
  }
  const teacherIdSql = teacherId ? `${sqlText(teacherId)}::bigint` : "NULL";

  const initialStatus = "APPROVED";
  const supplementNote = "";
  let rows;
  try {
    const createSql = experienceVerification
      ? `SELECT * FROM public.create_experience_verification_with_customer_face_photo(
           ${caller.storeId}::bigint, ${teacherIdSql},
           ${sqlText(customer.id)}::bigint, ${sqlText(productId)}::bigint,
           ${unitCount}::integer, ${caller.staffId}::bigint, ${sqlText(message)}::text,
           ${sqlText(faceRequestId)}::varchar, ${sqlText(faceEvidenceToken)}::varchar,
           ${sqlText(idempotencyKey)}::varchar
         )`
      : `SELECT * FROM public.create_verification_with_face_photo(
           ${sqlText(verificationType)}::varchar, ${caller.storeId}::bigint,
           ${teacherIdSql}, ${sqlText(customer.id)}::bigint,
           ${sqlText(productId)}::bigint, ${unitCount}::integer, ${sqlText(initialStatus)}::varchar,
           ${caller.staffId}::bigint, ${sqlText(message)}::text,
           ${sqlText(supplementNote)}::text, ${sqlText(faceRequestId)}::varchar,
           ${sqlText(faceEvidenceToken)}::varchar, ${sqlText(idempotencyKey)}::varchar
         )`;
    rows = await executeSql(createSql);
  } catch (error) {
    const detail = String(error?.message || "").toLowerCase();
    if (detail.includes("insufficient purchased units")) {
      fail("该客户所选项目的剩余次数不足，不能提交正常核销。", "INSUFFICIENT_BALANCE");
    }
    if (detail.includes("insufficient teacher experience quota")) {
      fail("该老师该项目的体验次数不足，不能提交体验核销。", "TEACHER_EXPERIENCE_QUOTA_EXHAUSTED");
    }
    if (detail.includes("no configured experience quota") || detail.includes("no active configured experience quota")) {
      fail("该老师尚未配置这个项目的体验次数，不能提交体验核销。", "TEACHER_EXPERIENCE_QUOTA_NOT_CONFIGURED");
    }
    if (detail.includes("face photo evidence")) {
      fail("现场人脸照片已过期、已使用或不属于当前提交，请重新拍照验证。", "FACE_PHOTO_EVIDENCE_INVALID");
    }
    if (detail.includes("idempotency key belongs")) {
      fail("该防重复提交编号已经用于另一张核销单，请刷新页面后重新提交。", "IDEMPOTENCY_CONFLICT");
    }
    throw error;
  }
  const record = rows[0];
  if (!record) fail("核销申请未能写入数据库，请稍后重试。", "VERIFICATION_CREATE_FAILED");

  const sameRequest = String(record.verification_type) === verificationType
    && String(record.store_id) === String(caller.storeId)
    && String(record.teacher_id || "") === String(teacherId)
    && String(record.customer_id) === String(customer.id)
    && String(record.product_id) === String(productId)
    && Number(record.unit_count) === unitCount
    && String(record.message || "") === message
    && String(record.face_request_id || "") === faceRequestId;
  if (!sameRequest) {
    fail("该防重复提交编号已经用于另一张核销单，请刷新页面后重新提交。", "IDEMPOTENCY_CONFLICT");
  }

  const signalRows = await executeSql(
    `SELECT id, signal_type, signal_status, created_at
       FROM public.device_signal_outbox
      WHERE verification_id = ${sqlText(record.id)}::bigint
      LIMIT 1`
  );
  const signal = signalRows[0];
  if (!signal) {
    fail("核销单已创建，但设备开启信号没有进入虚拟端口队列，请立即联系管理员。", "DEVICE_SIGNAL_NOT_QUEUED");
  }

  let experienceQuota = null;
  if (experienceVerification) {
    const quotaRows = await executeSql(
      `SELECT q.id AS quota_id, q.monthly_allowance, q.quota_month,
              q.available_count, q.used_count, q.manual_recharge_count, q.monthly_reset_at,
              u.available_before_count, u.available_after_count, u.consumed_at
         FROM public.teacher_experience_quota_usages u
         JOIN public.teacher_product_experience_quotas q ON q.id = u.quota_id
        WHERE u.verification_id = ${sqlText(record.id)}::bigint
        LIMIT 1`
    );
    const quota = quotaRows[0];
    if (!quota) fail("体验核销缺少老师体验额度扣减记录，请立即联系管理员。", "TEACHER_EXPERIENCE_QUOTA_AUDIT_MISSING");
    experienceQuota = {
      quotaId: String(quota.quota_id),
      monthlyAllowance: Number(quota.monthly_allowance || 0),
      quotaMonth: quota.quota_month,
      availableCount: Number(quota.available_count || 0),
      usedCount: Number(quota.used_count || 0),
      manualRechargeCount: Number(quota.manual_recharge_count || 0),
      monthlyResetAt: quota.monthly_reset_at,
      availableBeforeCount: Number(quota.available_before_count || 0),
      availableAfterCount: Number(quota.available_after_count || 0),
      consumedAt: quota.consumed_at
    };
  }

  return {
    ok: true,
    createdNow: databaseBoolean(record.created_now),
    verificationId: String(record.id),
    verificationCode: record.verification_code,
    verificationType: record.verification_type,
    recordStatus: record.record_status,
    submittedAt: record.submitted_at,
    unitCount: Number(record.unit_count),
    customer: { customerCode: customer.customer_code, customerName: customer.customer_name },
    product: { productId: String(product.id), productCode: product.product_code, productName: product.product_name },
    teacher: teacher ? {
      teacherId: String(teacher.id), teacherCode: teacher.teacher_code, teacherName: teacher.teacher_name
    } : null,
    experienceQuota,
    deviceSignal: {
      id: String(signal.id),
      port: "VIRTUAL_DEVICE_START",
      type: signal.signal_type,
      status: signal.signal_status,
      unitCount: Number(record.unit_count),
      queuedAt: signal.created_at
    }
  };
}

async function createSupplementVerificationApplication(event) {
  const caller = await activeBusinessCaller(event);
  const customerCode = String(event.customerCode || "").trim();
  if (!customerCode || customerCode.length > 96) {
    fail("必须先确认本门店的活跃客户。", "CUSTOMER_REQUIRED");
  }
  const productId = positiveDatabaseId(event.productId, "项目");
  const unitCount = Number(event.unitCount);
  if (!Number.isInteger(unitCount) || unitCount < 1 || unitCount > 999) {
    fail("核销次数必须由办理人员填写，并且是 1 至 999 的整数。", "INVALID_UNIT_COUNT");
  }
  const requestedTeacherId = String(event.teacherId || "").trim();
  if (caller.role === "teacher" && requestedTeacherId
      && requestedTeacherId !== String(caller.teacherId)) {
    fail("老师账号只能把核销绑定到本人。", "FORBIDDEN");
  }
  const teacherId = caller.role === "teacher"
    ? positiveDatabaseId(caller.teacherId, "老师")
    : (requestedTeacherId ? positiveDatabaseId(requestedTeacherId, "老师") : "");
  const message = String(event.message || "").trim();
  if (message.length > 500) fail("门店留言不能超过 500 个字符。", "MESSAGE_TOO_LONG");
  const idempotencyKey = rechargeSubmissionKey(event.clientRequestId);

  const schemaRows = await executeSql(
    `SELECT TO_REGPROCEDURE(
       'public.create_supplement_verification_application(bigint,bigint,bigint,bigint,integer,bigint,text,character varying)'
     ) IS NOT NULL AS ready`
  );
  if (!databaseBoolean(schemaRows?.[0]?.ready)) {
    fail("补录核销数据库尚未启用，请先执行迁移 079。", "DATABASE_SCHEMA_MISSING");
  }

  const customers = await executeSql(
    `SELECT id, customer_code, customer_name
       FROM public.customers
      WHERE customer_code = ${sqlText(customerCode)}
        AND created_store_id = ${caller.storeId}
        AND customer_status = 'ACTIVE'
      LIMIT 1`
  );
  const customer = customers[0];
  if (!customer) fail("未找到本门店已确认的活跃客户。", "CUSTOMER_NOT_FOUND");

  const products = await executeSql(
    `SELECT p.id, p.product_code, p.product_name,
            COALESCE(balance.remaining_count, 0) AS remaining_count
       FROM public.products p
  LEFT JOIN public.customer_product_balances balance
         ON balance.customer_id = ${sqlText(customer.id)}::bigint
        AND balance.product_id = p.id
      WHERE p.id = ${sqlText(productId)}::bigint
        AND p.product_status = 'ACTIVE'
      LIMIT 1`
  );
  const selectedProduct = products[0];
  if (!selectedProduct) fail("所选项目不存在或已经封存，请重新选择。", "PRODUCT_NOT_ACTIVE");
  if (Number(selectedProduct.remaining_count || 0) < unitCount) {
    fail("该客户所选项目的剩余次数不足，不能提交核销审核。", "INSUFFICIENT_BALANCE");
  }

  let selectedTeacher = null;
  if (teacherId) {
    const teachers = await executeSql(
      `SELECT teacher.id, teacher.teacher_code, teacher.teacher_name
         FROM public.teachers teacher
         JOIN public.staff_accounts account ON account.id = teacher.staff_account_id
        WHERE teacher.id = ${sqlText(teacherId)}::bigint
          AND teacher.teacher_status = 'ACTIVE'
          AND account.role_code = 'teacher'
          AND account.account_status = 'ACTIVE'
        LIMIT 1`
    );
    selectedTeacher = teachers[0] || null;
    if (!selectedTeacher) fail("所选老师不存在或已经封存，请重新选择。", "TEACHER_NOT_ACTIVE");
  }
  const teacherIdSql = teacherId ? `${sqlText(teacherId)}::bigint` : "NULL";

  let rows;
  try {
    rows = await executeSql(
      `SELECT * FROM public.create_supplement_verification_application(
         ${caller.storeId}::bigint, ${teacherIdSql},
         ${sqlText(customer.id)}::bigint, ${sqlText(productId)}::bigint,
         ${unitCount}::integer, ${caller.staffId}::bigint,
         ${sqlText(message)}::text, ${sqlText(idempotencyKey)}::varchar
       )`
    );
  } catch (error) {
    const detail = String(error?.message || "").toLowerCase();
    if (detail.includes("insufficient purchased units")) {
      fail("该客户所选项目的剩余次数不足，不能提交核销审核。", "INSUFFICIENT_BALANCE");
    }
    if (detail.includes("idempotency key belongs")) {
      fail("该防重复提交编号已经用于另一张核销单，请刷新页面后重新提交。", "IDEMPOTENCY_CONFLICT");
    }
    throw error;
  }
  const record = rows?.[0];
  if (!record) fail("补录核销申请未能写入数据库，请稍后重试。", "VERIFICATION_CREATE_FAILED");
  const sameRequest = String(record.verification_type) === "SUPPLEMENT"
    && String(record.store_id) === String(caller.storeId)
    && String(record.teacher_id || "") === String(teacherId)
    && String(record.customer_id) === String(customer.id)
    && String(record.product_id) === String(productId)
    && Number(record.unit_count) === unitCount
    && String(record.message || "") === message;
  if (!sameRequest) {
    fail("该防重复提交编号已经用于另一张核销单，请刷新页面后重新提交。", "IDEMPOTENCY_CONFLICT");
  }
  return {
    ok: true,
    createdNow: databaseBoolean(record.created_now),
    verificationId: String(record.id),
    verificationCode: record.verification_code,
    verificationType: record.verification_type,
    recordStatus: record.record_status,
    submittedAt: record.submitted_at,
    unitCount: Number(record.unit_count),
    customer: { customerCode: customer.customer_code, customerName: customer.customer_name },
    product: {
      productId: String(selectedProduct.id),
      productCode: selectedProduct.product_code,
      productName: selectedProduct.product_name
    },
    teacher: selectedTeacher ? {
      teacherId: String(selectedTeacher.id),
      teacherCode: selectedTeacher.teacher_code,
      teacherName: selectedTeacher.teacher_name
    } : null
  };
}

async function recoverBusinessSubmission(event) {
  const caller = await activeBusinessCaller(event);
  const recordType = String(event.recordType || "").trim().toUpperCase();
  if (!['RECHARGE', 'VERIFICATION', 'SUPPLEMENT', 'PRODUCT_PURCHASE'].includes(recordType)) {
    fail("必须指定需要恢复的充值、核销或产品购买提交。", "BAD_REQUEST");
  }
  const idempotencyKey = rechargeSubmissionKey(event.clientRequestId);

  if (recordType === "PRODUCT_PURCHASE") {
    await requireRetailProductPurchaseSchema();
    const rows = await executeSql(
      `SELECT purchase.id, purchase.purchase_code, purchase.store_id, purchase.teacher_id,
              purchase.customer_id, purchase.retail_product_id, purchase.unit_count,
              purchase.record_status, purchase.submitted_by_account_id, purchase.submitted_at,
              customer.customer_code, customer.customer_name,
              purchase.product_code_snapshot, purchase.product_name_snapshot,
              teacher.teacher_code, teacher.teacher_name
         FROM public.retail_product_purchase_records purchase
         JOIN public.customers customer ON customer.id = purchase.customer_id
         LEFT JOIN public.teachers teacher ON teacher.id = purchase.teacher_id
        WHERE purchase.idempotency_key = ${sqlText(idempotencyKey)}
        LIMIT 1`
    );
    const record = rows[0];
    if (!record) return { ok: true, found: false, complete: false, recordType };
    if (String(record.store_id) !== String(caller.storeId)
        || String(record.submitted_by_account_id) !== String(caller.staffId)) {
      fail("该防重复提交编号不属于当前账号和门店。", "FORBIDDEN");
    }
    return {
      ok: true, found: true, complete: true, recovered: true, recordType,
      purchaseId: String(record.id), purchaseCode: record.purchase_code,
      recordStatus: record.record_status, submittedAt: record.submitted_at,
      unitCount: Number(record.unit_count || 0),
      customer: { customerCode: record.customer_code, customerName: record.customer_name },
      product: {
        productId: String(record.retail_product_id), productCode: record.product_code_snapshot,
        productName: record.product_name_snapshot
      },
      teacher: record.teacher_id ? {
        teacherId: String(record.teacher_id), teacherCode: record.teacher_code, teacherName: record.teacher_name
      } : null
    };
  }

  if (recordType === "RECHARGE") {
    const rows = await executeSql(
      `SELECT r.id, r.recharge_code, r.recharge_type, r.store_id, t.id AS teacher_id,
              r.customer_id, r.product_id, r.unit_count, r.record_status,
              r.submitted_by_account_id, r.submitted_at, r.balance_before_count,
              r.balance_after_count, c.customer_code, c.customer_name,
              p.product_code, p.product_name,
              t.teacher_code, t.teacher_name
         FROM public.recharge_records r
         JOIN public.customers c ON c.id = r.customer_id
         JOIN public.products p ON p.id = r.product_id
         LEFT JOIN public.teachers t
           ON t.id = r.teacher_id
          AND ${teacherBusinessAttributionSourceCondition("r", "RECHARGE")}
        WHERE r.idempotency_key = ${sqlText(idempotencyKey)}
        LIMIT 1`
    );
    const record = rows[0];
    if (!record) return { ok: true, found: false, complete: false, recordType: "RECHARGE" };
    if (String(record.store_id) !== String(caller.storeId)
        || String(record.submitted_by_account_id) !== String(caller.staffId)) {
      fail("该防重复提交编号不属于当前账号和门店。", "FORBIDDEN");
    }
    const productGifts = await readRechargeProductGifts(record.id);
    return {
      ok: true,
      found: true,
      complete: true,
      recovered: true,
      recordType: "RECHARGE",
      rechargeId: String(record.id),
      rechargeCode: record.recharge_code,
      rechargeType: record.recharge_type,
      recordStatus: record.record_status,
      submittedAt: record.submitted_at,
      unitCount: Number(record.unit_count),
      balanceBeforeCount: record.balance_before_count === null || record.balance_before_count === undefined ? null : Number(record.balance_before_count),
      balanceAfterCount: record.balance_after_count === null || record.balance_after_count === undefined ? null : Number(record.balance_after_count),
      customer: { customerCode: record.customer_code, customerName: record.customer_name },
      product: { productId: String(record.product_id), productCode: record.product_code, productName: record.product_name },
      teacher: record.teacher_id ? {
        teacherId: String(record.teacher_id),
        teacherCode: record.teacher_code,
        teacherName: record.teacher_name
      } : null,
      productGifts
    };
  }

  const rows = await executeSql(
    `SELECT v.id, v.verification_code, v.verification_type, v.store_id,
            t.id AS teacher_id, v.customer_id, v.product_id, v.unit_count,
            v.record_status, v.submitted_by_account_id, v.submitted_at,
            c.customer_code, c.customer_name, p.product_code, p.product_name,
            t.teacher_code, t.teacher_name,
            signal.id AS signal_id, signal.signal_type, signal.signal_status,
            signal.created_at AS signal_created_at,
            usage.verification_id AS quota_usage_id, usage.available_before_count,
            usage.available_after_count
       FROM public.verification_records v
       JOIN public.customers c ON c.id = v.customer_id
       JOIN public.products p ON p.id = v.product_id
       LEFT JOIN public.teachers t
         ON t.id = v.teacher_id
        AND ${teacherBusinessAttributionSourceCondition("v", "VERIFICATION")}
       LEFT JOIN LATERAL (
         SELECT d.id, d.signal_type, d.signal_status, d.created_at
           FROM public.device_signal_outbox d
          WHERE d.verification_id = v.id
          ORDER BY d.id
          LIMIT 1
       ) signal ON TRUE
       LEFT JOIN public.teacher_experience_quota_usages usage
         ON usage.verification_id = v.id
      WHERE v.idempotency_key = ${sqlText(idempotencyKey)}
      LIMIT 1`
  );
  const record = rows[0];
  if (!record) return { ok: true, found: false, complete: false, recordType };
  if (String(record.store_id) !== String(caller.storeId)
      || String(record.submitted_by_account_id) !== String(caller.staffId)) {
    fail("该防重复提交编号不属于当前账号和门店。", "FORBIDDEN");
  }
  const experience = record.verification_type === "EXPERIENCE";
  const supplement = record.verification_type === "SUPPLEMENT";
  if ((recordType === "SUPPLEMENT") !== supplement) {
    fail("该防重复提交编号属于另一种核销流程。", "IDEMPOTENCY_CONFLICT");
  }
  const complete = supplement || (Boolean(record.signal_id) && (!experience || Boolean(record.quota_usage_id)));
  return {
    ok: true,
    found: true,
    complete,
    recovered: true,
    recordType,
    verificationId: String(record.id),
    verificationCode: record.verification_code,
    verificationType: record.verification_type,
    recordStatus: record.record_status,
    submittedAt: record.submitted_at,
    unitCount: Number(record.unit_count),
    customer: { customerCode: record.customer_code, customerName: record.customer_name },
    product: { productId: String(record.product_id), productCode: record.product_code, productName: record.product_name },
    teacher: record.teacher_id ? {
      teacherId: String(record.teacher_id), teacherCode: record.teacher_code, teacherName: record.teacher_name
    } : null,
    experienceQuota: experience && record.quota_usage_id ? {
      availableBeforeCount: Number(record.available_before_count || 0),
      availableAfterCount: Number(record.available_after_count || 0)
    } : null,
    deviceSignal: record.signal_id ? {
      id: String(record.signal_id),
      port: "VIRTUAL_DEVICE_START",
      type: record.signal_type,
      status: record.signal_status,
      unitCount: Number(record.unit_count),
      queuedAt: record.signal_created_at
    } : null
  };
}

async function getCustomerProductBalances(event) {
  const caller = await activeBusinessCaller(event);
  const customerCode = String(event.customerCode || "").trim();
  if (!customerCode || customerCode.length > 96) fail("必须提供已选择客户的有效编号。", "CUSTOMER_REQUIRED");

  const customers = await executeSql(
    `SELECT id, customer_code
       FROM public.customers
      WHERE customer_code = ${sqlText(customerCode)}
        AND created_store_id = ${caller.storeId}
        AND customer_status = 'ACTIVE'
      LIMIT 1`
  );
  const customer = customers[0];
  if (!customer) fail("未找到本门店已选择的活跃客户。", "CUSTOMER_NOT_FOUND");

  const rows = await executeSql(
    `SELECT p.id AS product_id, p.product_code, p.product_name,
            b.total_recharge_count, b.total_verification_count, b.remaining_count,
            b.updated_at
       FROM public.customer_product_balances b
       JOIN public.products p ON p.id = b.product_id
      WHERE b.customer_id = ${sqlText(customer.id)}::bigint
        AND p.product_status = 'ACTIVE'
      ORDER BY p.product_name, p.product_code`
  );

  return {
    ok: true,
    customerCode: customer.customer_code,
    balances: rows.map((row) => ({
      productId: String(row.product_id),
      productCode: row.product_code,
      productName: row.product_name,
      purchasedCount: Number(row.total_recharge_count || 0),
      effectiveVerificationCount: Number(row.total_verification_count || 0),
      remainingCount: Number(row.remaining_count || 0),
      updatedAt: row.updated_at
    }))
  };
}

const TEACHER_WORKSPACE_TYPES = Object.freeze(["VERIFICATION", "RECHARGE", "EXPERIENCE", "REFUND"]);
const TEACHER_WORKSPACE_TYPE_CONFIG = Object.freeze({
  VERIFICATION: Object.freeze({
    baseRecordType: "VERIFICATION", table: "verification_records", alias: "v",
    codeColumn: "verification_code", typeColumn: "verification_type",
    categoryClause: "v.verification_type IN ('NORMAL', 'SUPPLEMENT')"
  }),
  RECHARGE: Object.freeze({
    baseRecordType: "RECHARGE", table: "recharge_records", alias: "r",
    codeColumn: "recharge_code", typeColumn: "recharge_type",
    categoryClause: "r.recharge_type = 'NEW'"
  }),
  EXPERIENCE: Object.freeze({
    baseRecordType: "VERIFICATION", table: "verification_records", alias: "v",
    codeColumn: "verification_code", typeColumn: "verification_type",
    categoryClause: "v.verification_type = 'EXPERIENCE'"
  }),
  REFUND: Object.freeze({
    baseRecordType: "RECHARGE", table: "recharge_records", alias: "r",
    codeColumn: "recharge_code", typeColumn: "recharge_type",
    categoryClause: "r.recharge_type = 'REFUND'"
  })
});

function teacherWorkspaceOptions(event = {}) {
  const recordType = String(event.recordType || "").trim().toUpperCase();
  if (recordType && !TEACHER_WORKSPACE_TYPES.includes(recordType)) {
    fail("老师业务类型无效。", "BAD_REQUEST");
  }
  const requestedLimit = Number(event.limit);
  const limit = Number.isFinite(requestedLimit)
    ? Math.min(Math.max(Math.trunc(requestedLimit), 1), 100)
    : 50;
  const numberedPage = Object.prototype.hasOwnProperty.call(event, "page")
    || Object.prototype.hasOwnProperty.call(event, "pageSize");
  const requestedPage = Number(event.page || 1);
  const requestedPageSize = Number(event.pageSize || 10);
  if (numberedPage && (!Number.isInteger(requestedPage) || requestedPage < 1)) fail("老师业务明细页码必须是正整数。", "BAD_REQUEST");
  if (numberedPage && (!Number.isInteger(requestedPageSize) || requestedPageSize < 1 || requestedPageSize > 100)) {
    fail("老师业务明细每页数量必须是 1 至 100。", "BAD_REQUEST");
  }
  const cursorSubmittedAt = scopedQueryCursorTimestamp(event.cursorSubmittedAt, "老师工单游标时间");
  const cursorIdText = String(event.cursorId || "").trim();
  if (Boolean(cursorSubmittedAt) !== Boolean(cursorIdText)) fail("老师工单游标不完整。", "BAD_REQUEST");
  if (cursorSubmittedAt && !recordType) fail("老师工单游标必须指定记录类型。", "BAD_REQUEST");
  if (numberedPage && cursorSubmittedAt) fail("老师业务明细页码不能同时提交游标。", "BAD_REQUEST");
  const recordIdText = String(event.recordId || "").trim();
  const startDate = optionalBusinessQueryDate(event.startDate, "开始日期");
  const endDate = optionalBusinessQueryDate(event.endDate, "结束日期");
  if (Boolean(startDate) !== Boolean(endDate)) fail("开始日期和结束日期必须同时提供。", "BAD_REQUEST");
  if (startDate && startDate > endDate) fail("开始日期不能晚于结束日期。", "BAD_REQUEST");
  return {
    recordType,
    limit,
    numberedPage,
    page: numberedPage ? requestedPage : 1,
    pageSize: numberedPage ? requestedPageSize : limit,
    cursorSubmittedAt,
    cursorId: cursorIdText ? businessQueryDatabaseId(cursorIdText, "老师工单游标编号") : "",
    recordId: recordIdText ? businessQueryDatabaseId(recordIdText, "老师工单编号") : "",
    startDate,
    endDate,
    includeOverview: event.includeOverview === true || String(event.includeOverview || "").toLowerCase() === "true"
  };
}

function teacherWorkspaceDateClauses(alias, options) {
  const clauses = [];
  if (options.startDate) {
    clauses.push(`${alias}.submitted_at >= (${sqlText(options.startDate)}::date::timestamp AT TIME ZONE 'Asia/Shanghai')`);
    clauses.push(`${alias}.submitted_at < ((${sqlText(options.endDate)}::date + 1)::timestamp AT TIME ZONE 'Asia/Shanghai')`);
  }
  return clauses;
}

function teacherOrderRows(rows, recordType) {
  return rows.map((row) => ({
    id: String(row.id),
    recordType,
    recordCode: String(row.record_code || ""),
    originalType: String(row.original_type || ""),
    unitCount: Number(row.unit_count || (recordType === "VERIFICATION" ? 1 : 0)),
    balanceBeforeCount: row.balance_before_count === null || row.balance_before_count === undefined ? null : Number(row.balance_before_count),
    balanceAfterCount: row.balance_after_count === null || row.balance_after_count === undefined ? null : Number(row.balance_after_count),
    recordStatus: String(row.record_status || ""),
    voidRequestStatus: String(row.void_request_status || "NONE"),
    submittedAt: row.submitted_at,
    reviewedAt: row.reviewed_at,
    message: String(row.message || ""),
    supplementNote: String(row.supplement_note || ""),
    reviewNote: String(row.review_note || ""),
    hasFaceRequest: Boolean(row.face_request_id),
    teacherId: String(row.teacher_id || ""),
    teacherCode: String(row.teacher_code || ""),
    teacherName: String(row.teacher_name || ""),
    storeId: String(row.store_id || ""),
    storeCode: String(row.store_code || ""),
    storeName: String(row.store_name || ""),
    storeProvince: String(row.store_province || ""),
    storeCity: String(row.store_city || ""),
    storeDistrict: String(row.store_district || ""),
    storeAddressDetail: String(row.store_address_detail || ""),
    customerCode: String(row.customer_code || ""),
    customerName: String(row.customer_name || ""),
    productCode: String(row.product_code || ""),
    productName: String(row.product_name || ""),
    productGifts: parsedProductGiftRows(row.product_gifts)
  }));
}

function teacherOrderPage(rows, recordType, limit) {
  const hasMore = rows.length > limit;
  const visible = rows.slice(0, limit);
  const last = visible[visible.length - 1];
  return {
    records: teacherOrderRows(visible, recordType),
    page: {
      hasMore,
      nextCursor: hasMore && last
        ? { submittedAt: String(last.cursor_submitted_at || ""), id: String(last.id) }
        : null
    }
  };
}

function teacherNumberedOrderPage(rows, recordType, total, page, pageSize) {
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  return {
    records: teacherOrderRows(rows, recordType),
    page: {
      total,
      page,
      pageSize,
      totalPages,
      hasMore: page < totalPages,
      nextCursor: null
    }
  };
}

function teacherBusinessCustomerPage(value, label) {
  const requested = Number(value || 1);
  if (!Number.isInteger(requested) || requested < 1) fail(`${label}分页必须是正整数。`, "BAD_REQUEST");
  return Math.min(requested, 100000);
}

async function getTeacherBusinessCustomers(event = {}) {
  const caller = await activeTeacherCaller();
  const teacherId = positiveDatabaseId(caller.teacherId, "老师");
  const pageSize = customerListPageSize(event);
  const activePage = teacherBusinessCustomerPage(event.activePage, "活跃客户");
  const archivedPage = teacherBusinessCustomerPage(event.archivedPage, "封存客户");
  const eventCte = `teacher_customer_events AS (
    SELECT c.id AS customer_id, NULL::bigint AS product_id,
           c.created_store_id AS store_id, 'CREATED'::text AS event_type,
           0::bigint AS unit_count, c.created_at AS effective_at
      FROM public.customers c
     WHERE c.created_by_account_id = ${sqlText(caller.staffId)}::bigint
    UNION ALL
    SELECT v.customer_id, v.product_id, v.store_id,
           v.verification_type::text AS event_type,
           v.unit_count::bigint AS unit_count,
           COALESCE(v.reviewed_at, v.submitted_at) AS effective_at
      FROM public.verification_records v
     WHERE ${teacherBusinessAttributionCondition(caller, "v", "VERIFICATION")}
       AND v.record_status = 'APPROVED'
       AND v.verification_type IN ('NORMAL', 'SUPPLEMENT', 'EXPERIENCE')
    UNION ALL
    SELECT r.customer_id, r.product_id, r.store_id,
           r.recharge_type::text AS event_type,
           r.unit_count::bigint AS unit_count,
           COALESCE(r.reviewed_at, r.submitted_at) AS effective_at
      FROM public.recharge_records r
     WHERE ${teacherBusinessAttributionCondition(caller, "r", "RECHARGE")}
       AND r.record_status = 'APPROVED'
       AND r.recharge_type IN ('NEW', 'REFUND')
  ), teacher_customer_store AS (
    SELECT DISTINCT ON (event.customer_id)
           event.customer_id, event.store_id
      FROM teacher_customer_events event
     ORDER BY event.customer_id, event.effective_at DESC, event.store_id DESC
  ), teacher_customer_totals AS (
    SELECT event.customer_id,
           COUNT(DISTINCT event.product_id)::bigint AS product_count,
           COALESCE(SUM(event.unit_count) FILTER (WHERE event.event_type IN ('NORMAL', 'SUPPLEMENT')), 0)::bigint AS verification_count,
           COALESCE(SUM(event.unit_count) FILTER (WHERE event.event_type = 'EXPERIENCE'), 0)::bigint AS experience_count,
           COALESCE(SUM(event.unit_count) FILTER (WHERE event.event_type = 'NEW'), 0)::bigint AS recharge_count,
           COALESCE(SUM(event.unit_count), 0)::bigint AS total_count,
           MAX(event.effective_at) AS last_verification_at
      FROM teacher_customer_events event
     GROUP BY event.customer_id
  )`;
  const rowsForStatus = (status, page) => executeSql(
    `WITH ${eventCte}
     SELECT c.id AS customer_id, c.customer_code, c.customer_name, c.birth_date,
            c.customer_status, totals.product_count, totals.verification_count,
            totals.experience_count, totals.total_count, totals.last_verification_at,
            totals.recharge_count,
            s.store_code, s.store_name
       FROM teacher_customer_totals totals
       JOIN public.customers c ON c.id = totals.customer_id
       JOIN teacher_customer_store customer_store ON customer_store.customer_id = totals.customer_id
       JOIN public.stores s ON s.id = customer_store.store_id
      WHERE c.customer_status = ${sqlText(status)}
      ORDER BY totals.last_verification_at DESC, c.id DESC
      LIMIT ${pageSize} OFFSET ${(page - 1) * pageSize}`
  );
  const [countRows, activeRows, archivedRows] = await Promise.all([
    executeSql(
      `WITH ${eventCte}
       SELECT COUNT(*) FILTER (WHERE c.customer_status = 'ACTIVE') AS active_total,
              COUNT(*) FILTER (WHERE c.customer_status = 'ARCHIVED') AS archived_total
         FROM teacher_customer_totals totals
         JOIN public.customers c ON c.id = totals.customer_id`
    ),
    rowsForStatus("ACTIVE", activePage),
    rowsForStatus("ARCHIVED", archivedPage)
  ]);
  const activeTotal = Number(countRows?.[0]?.active_total || 0);
  const archivedTotal = Number(countRows?.[0]?.archived_total || 0);
  const effectiveActivePage = Math.min(activePage, Math.max(1, Math.ceil(activeTotal / pageSize)));
  const effectiveArchivedPage = Math.min(archivedPage, Math.max(1, Math.ceil(archivedTotal / pageSize)));
  const [visibleActiveRows, visibleArchivedRows] = await Promise.all([
    effectiveActivePage === activePage ? Promise.resolve(activeRows) : rowsForStatus("ACTIVE", effectiveActivePage),
    effectiveArchivedPage === archivedPage ? Promise.resolve(archivedRows) : rowsForStatus("ARCHIVED", effectiveArchivedPage)
  ]);
  const mapRows = (rows) => rows.map((row) => ({
    customerId: String(row.customer_id || ""),
    customerCode: String(row.customer_code || ""),
    customerName: String(row.customer_name || ""),
    birthDate: row.birth_date,
    customerStatus: String(row.customer_status || ""),
    productCount: Number(row.product_count || 0),
    verificationCount: Number(row.verification_count || 0),
    experienceCount: Number(row.experience_count || 0),
    rechargeCount: Number(row.recharge_count || 0),
    totalCount: Number(row.total_count || 0),
    storeCode: String(row.store_code || ""),
    storeName: String(row.store_name || ""),
    lastVerificationAt: row.last_verification_at
  }));
  return {
    ok: true,
    active: { records: mapRows(visibleActiveRows), total: activeTotal, page: effectiveActivePage, pageSize },
    archived: { records: mapRows(visibleArchivedRows), total: archivedTotal, page: effectiveArchivedPage, pageSize }
  };
}

async function getTeacherWorkspace(event = {}, hqTarget = null) {
  // hqTarget is a trusted read-only target from independently authenticated HQ/team actions.
  // The public teacher action never accepts a target identity from event.
  const caller = hqTarget || await activeTeacherCaller();
  const options = teacherWorkspaceOptions(event);
  const lookup = parseTeacherLookup(event, caller.role, fail);
  if (lookup && (!options.recordId || hqTarget)) fail("请从客户工单进入详情。", "FORBIDDEN");
  const leaderRows = await executeSql(`SELECT public.teacher_team_leader_name_v93(${positiveDatabaseId(caller.teacherId, "老师")}::bigint) AS assigned_leader_name
    WHERE ${caller.teamReadScopeSql || "TRUE"}`);
  const profile = {
    teacherId: caller.teacherId,
    teacherCode: caller.teacherCode,
    teacherName: caller.teacherName,
    teacherPhone: caller.teacherPhone,
    assignedLeaderName: String(leaderRows?.[0]?.assigned_leader_name || "")
  };
  const query = async (recordType, { detailMode = false, legacyCombined = false } = {}) => {
    const config = TEACHER_WORKSPACE_TYPE_CONFIG[recordType];
    const { alias, table, codeColumn, typeColumn } = config;
    const baseRecordType = config.baseRecordType;
    const clauses = [];
    if (caller.teamReadScopeSql) clauses.push(caller.teamReadScopeSql);
    if (detailMode) {
      clauses.push(`${alias}.id = ${options.recordId}::bigint`);
      if (lookup) clauses.push(`EXISTS (SELECT 1 FROM public.customers lookup_customer WHERE lookup_customer.id = ${alias}.customer_id AND ${lookupCustomerCondition(lookup, "lookup_customer", sqlText)})`);
      clauses.push(`(
        ${teacherBusinessOwnershipCondition(caller, alias)}
        OR (
          ${alias}.record_status = 'APPROVED'
          AND ${teacherBusinessAttributionCondition(caller, alias, baseRecordType)}
        )
        OR EXISTS (
          SELECT 1
            FROM public.customers permitted_customer
           WHERE permitted_customer.id = ${alias}.customer_id
             AND ${teacherCustomerAccessCondition(caller, "permitted_customer")}
        )
        ${lookup ? `OR EXISTS (SELECT 1 FROM public.customers lookup_customer WHERE lookup_customer.id = ${alias}.customer_id AND ${lookupCustomerCondition(lookup, "lookup_customer", sqlText)})` : ""}
      )`);
    } else if (legacyCombined) {
      clauses.push(`(
        ${teacherBusinessOwnershipCondition(caller, alias)}
        OR (
          ${alias}.record_status = 'APPROVED'
          AND ${teacherBusinessAttributionCondition(caller, alias, baseRecordType)}
        )
      )`);
    } else {
      clauses.push(teacherBusinessAttributionCondition(caller, alias, baseRecordType));
    }
    if (!detailMode && !legacyCombined) {
      clauses.push(`${alias}.record_status = 'APPROVED'`, config.categoryClause);
      clauses.push(...teacherWorkspaceDateClauses(alias, options));
      if (options.cursorSubmittedAt && options.recordType === recordType) {
        clauses.push(`(${alias}.submitted_at, ${alias}.id) < (${sqlText(options.cursorSubmittedAt)}::timestamptz, ${options.cursorId}::bigint)`);
      }
    }
    const listLimit = detailMode ? 1
      : legacyCombined ? options.limit + 1
        : options.numberedPage ? options.pageSize : options.limit + 1;
    const giftSelect = baseRecordType === "RECHARGE" && detailMode && await rechargeProductGiftSchemaAvailable()
      ? `(SELECT COALESCE(JSONB_AGG(JSONB_BUILD_OBJECT(
             'id', gift.id,
             'retailProductId', gift.retail_product_id,
             'productCode', gift.product_code_snapshot,
             'productName', gift.product_name_snapshot,
             'unitCount', gift.unit_count,
             'displayOrder', gift.display_order
           ) ORDER BY gift.display_order, gift.id), '[]'::jsonb)
            FROM public.recharge_product_gifts gift
           WHERE gift.recharge_id = ${alias}.id) AS product_gifts`
      : `'[]'::jsonb AS product_gifts`;
    const listSql = (numberedPage = options.page) => `SELECT ${alias}.id, ${alias}.${codeColumn} AS record_code,
              ${alias}.${typeColumn} AS original_type, ${alias}.unit_count,
              ${baseRecordType === "RECHARGE" ? `${alias}.balance_before_count, ${alias}.balance_after_count` : "NULL::integer AS balance_before_count, NULL::integer AS balance_after_count"},
              ${alias}.record_status, ${alias}.void_request_status,
              ${alias}.submitted_at, ${alias}.reviewed_at,
              ${alias}.message,
              ${baseRecordType === "VERIFICATION" ? `${alias}.supplement_note` : "NULL::text AS supplement_note"},
              ${alias}.review_note,
              ${baseRecordType === "VERIFICATION" ? `${alias}.face_request_id` : "NULL::text AS face_request_id"},
              TO_CHAR(${alias}.submitted_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS cursor_submitted_at,
              s.id AS store_id, s.store_code, s.store_name,
              s.province AS store_province, s.city AS store_city,
              s.district AS store_district, s.address_detail AS store_address_detail,
              c.customer_code, c.customer_name,
              p.product_code, p.product_name,
              business_teacher.id AS teacher_id,
              business_teacher.teacher_code, business_teacher.teacher_name,
              ${giftSelect}
         FROM public.${table} ${alias}
         JOIN public.stores s ON s.id = ${alias}.store_id
         JOIN public.customers c ON c.id = ${alias}.customer_id
         JOIN public.products p ON p.id = ${alias}.product_id
    LEFT JOIN public.teachers business_teacher
           ON business_teacher.id = ${alias}.teacher_id
          AND ${teacherBusinessAttributionSourceCondition(alias, baseRecordType)}
        WHERE ${clauses.join(" AND ")}
        ORDER BY ${alias}.submitted_at DESC, ${alias}.id DESC
        LIMIT ${listLimit}
        ${!detailMode && !legacyCombined && options.numberedPage ? `OFFSET ${(numberedPage - 1) * options.pageSize}` : ""}`;
    if (detailMode || legacyCombined || !options.numberedPage) return executeSql(listSql());
    const countClauses = clauses.filter((clause) => !clause.startsWith(`(${alias}.submitted_at, ${alias}.id) <`));
    const countRows = await executeSql(`SELECT COUNT(*) AS total FROM public.${table} ${alias} WHERE ${countClauses.join(" AND ")}`);
    const total = Number(countRows?.[0]?.total || 0);
    const effectivePage = Math.min(options.page, Math.max(1, Math.ceil(total / options.pageSize)));
    const rows = await executeSql(listSql(effectivePage));
    return { rows, total, page: effectivePage };
  };

  const loadOverview = async () => {
    await requireTeacherExperienceQuotaLifecycleSchema();
    const teacherId = positiveDatabaseId(caller.teacherId, "老师");
    if (!hqTarget) await executeSql(
      `SELECT public.reset_teacher_experience_quota(q.id)
         FROM public.teacher_product_experience_quotas q
        WHERE q.teacher_id = ${sqlText(teacherId)}::bigint
          AND q.quota_status = 'ACTIVE'
          AND q.quota_month < public.teacher_experience_quota_month()`
    );
    const rechargeDateClauses = teacherWorkspaceDateClauses("r", options);
    const verificationDateClauses = teacherWorkspaceDateClauses("v", options);
    const eventCte = `business_events AS (
      SELECT CASE WHEN r.recharge_type = 'REFUND' THEN 'refund' ELSE 'recharge' END AS metric,
             r.product_id, r.unit_count::bigint AS amount
        FROM public.recharge_records r
       WHERE ${teacherBusinessAttributionCondition(caller, "r", "RECHARGE")}
         AND r.record_status = 'APPROVED'
         AND r.recharge_type IN ('NEW', 'REFUND')
         AND ${caller.teamReadScopeSql || 'TRUE'}
         ${rechargeDateClauses.length ? `AND ${rechargeDateClauses.join(" AND ")}` : ""}
      UNION ALL
      SELECT CASE WHEN v.verification_type = 'EXPERIENCE' THEN 'experience' ELSE 'verification' END AS metric,
             v.product_id, v.unit_count::bigint AS amount
        FROM public.verification_records v
       WHERE ${teacherBusinessAttributionCondition(caller, "v", "VERIFICATION")}
         AND v.record_status = 'APPROVED'
         AND v.verification_type IN ('NORMAL', 'SUPPLEMENT', 'EXPERIENCE')
         AND ${caller.teamReadScopeSql || 'TRUE'}
         ${verificationDateClauses.length ? `AND ${verificationDateClauses.join(" AND ")}` : ""}
    )`;
    const [summaryRows, balanceRows] = await Promise.all([
      executeSql(
        `WITH ${eventCte}, product_members AS (
           SELECT event.product_id FROM business_events event
           UNION
           SELECT quota.product_id
             FROM public.teacher_product_experience_quotas quota
            WHERE quota.teacher_id = ${sqlText(teacherId)}::bigint
              AND quota.quota_status = 'ACTIVE'
              AND ${caller.teamReadScopeSql || 'TRUE'}
         )
         SELECT p.id AS product_id, p.product_code, p.product_name,
                COALESCE(SUM(event.amount) FILTER (WHERE event.metric = 'verification'), 0) AS verification_count,
                COALESCE(SUM(event.amount) FILTER (WHERE event.metric = 'recharge'), 0) AS recharge_count,
                COALESCE(SUM(event.amount) FILTER (WHERE event.metric = 'experience'), 0) AS experience_count,
                COALESCE(SUM(event.amount) FILTER (WHERE event.metric = 'refund'), 0) AS refund_count
           FROM product_members member
           JOIN public.products p ON p.id = member.product_id
           LEFT JOIN business_events event ON event.product_id = p.id
          WHERE ${caller.teamReadScopeSql || 'TRUE'}
          GROUP BY p.id, p.product_code, p.product_name
          ORDER BY p.product_name, p.product_code`
      ),
      hqTarget ? Promise.resolve([]) : executeSql(
        `SELECT q.id, q.product_id, q.monthly_allowance, q.quota_month,
                q.available_count, q.used_count, q.manual_recharge_count, q.monthly_reset_at,
                p.product_code, p.product_name
           FROM public.teacher_product_experience_quotas q
           JOIN public.products p ON p.id = q.product_id
          WHERE q.teacher_id = ${sqlText(teacherId)}::bigint
            AND q.quota_status = 'ACTIVE'
            AND p.product_status = 'ACTIVE'
          ORDER BY p.product_name, p.product_code, q.id`
      )
    ]);
    const products = summaryRows.map((row) => ({
      productId: String(row.product_id),
      productCode: String(row.product_code || ""),
      productName: String(row.product_name || ""),
      verification: Number(row.verification_count || 0),
      recharge: Number(row.recharge_count || 0),
      experience: Number(row.experience_count || 0),
      refund: Number(row.refund_count || 0)
    }));
    const totals = products.reduce((result, product) => {
      for (const metric of ["verification", "recharge", "experience", "refund"]) result[metric] += product[metric];
      return result;
    }, { verification: 0, recharge: 0, experience: 0, refund: 0 });
    return {
      range: { startDate: options.startDate, endDate: options.endDate },
      summary: { products, totals },
      experienceBalances: balanceRows.map((row) => ({
        id: String(row.id),
        productId: String(row.product_id),
        productCode: String(row.product_code || ""),
        productName: String(row.product_name || ""),
        monthlyAllowance: Number(row.monthly_allowance || 0),
        availableCount: Number(row.available_count || 0),
        usedCount: Number(row.used_count || 0),
        manualRechargeCount: Number(row.manual_recharge_count || 0),
        quotaMonth: row.quota_month,
        monthlyResetAt: row.monthly_reset_at
      }))
    };
  };

  if (options.recordId) {
    if (!options.recordType) fail("读取老师工单详情时必须指定工单类型。", "BAD_REQUEST");
    const rows = await query(options.recordType, { detailMode: true });
    const order = teacherOrderRows(rows, TEACHER_WORKSPACE_TYPE_CONFIG[options.recordType].baseRecordType)[0];
    if (!order) fail("未找到当前老师有权查看的工单。", "ORDER_NOT_FOUND");
    return { ok: true, profile, record: order };
  }
  if (options.recordType) {
    const queryResult = await query(options.recordType);
    const page = options.numberedPage
      ? teacherNumberedOrderPage(queryResult.rows, options.recordType, queryResult.total, queryResult.page, options.pageSize)
      : teacherOrderPage(queryResult, options.recordType, options.limit);
    const overview = options.includeOverview ? await loadOverview() : {};
    return { ok: true, profile, page: { records: page.records, ...page.page }, ...overview };
  }
  // Compatibility for the previous two-tab static page during a rolling
  // deployment. The new page always requests one of the four explicit types.
  const [rechargeRows, verificationRows] = await Promise.all([
    query("RECHARGE", { legacyCombined: true }),
    query("VERIFICATION", { legacyCombined: true })
  ]);
  const rechargePage = teacherOrderPage(rechargeRows, "RECHARGE", options.limit);
  const verificationPage = teacherOrderPage(verificationRows, "VERIFICATION", options.limit);
  return {
    ok: true,
    profile,
    recharges: { records: rechargePage.records, ...rechargePage.page },
    verifications: { records: verificationPage.records, ...verificationPage.page }
  };
}

async function getHqTeacherWorkspace(event = {}) {
  const viewer = await activeScopedQueryCaller();
  if (viewer.role !== "hq") fail("只有总部可以查看指定老师主页。", "FORBIDDEN");
  const teacherId = positiveDatabaseId(event.teacherId, "老师");
  // This action is a read-only overview/list, not a new order-detail/write route.
  if (event.recordId) fail("请从工单入口读取业务详情。", "BAD_REQUEST");
  const rows = await executeSql(
    `SELECT t.id AS teacher_id, t.teacher_code, t.teacher_name,
            a.id AS staff_id, a.phone, a.role_code
       FROM public.teachers t
       LEFT JOIN public.staff_accounts a ON a.id = t.staff_account_id
      WHERE t.id = ${sqlText(teacherId)}::bigint
      LIMIT 1`
  );
  const target = rows[0];
  if (!target || (target.staff_id && target.role_code !== "teacher")) fail("未找到该老师资料。", "TEACHER_NOT_FOUND");
  return getTeacherWorkspace({ ...event, recordType: event.recordType || "VERIFICATION" }, Object.freeze({
    role: "hq", teacherId: String(target.teacher_id), teacherCode: String(target.teacher_code || ""),
    teacherName: String(target.teacher_name || ""), teacherPhone: String(target.phone || ""),
    staffId: Number(target.staff_id || 0)
  }));
}

async function getTeamTeacherWorkspace(event = {}) {
  const membership = await teacherTeamReads().member(event.teacherId);
  if (event.recordId) fail("请从本人原有工单入口读取详情。", "FORBIDDEN");
  const rows = await executeSql(`SELECT t.id AS teacher_id, t.teacher_code, t.teacher_name,
    a.id AS staff_id, a.phone FROM public.teachers t
    JOIN public.staff_accounts a ON a.id = t.staff_account_id AND a.role_code = 'teacher'
    WHERE t.id = ${sqlText(membership.teacherId)}::bigint
      AND ${teacherTeamReads().scope(membership.caller.uid, 't.id')} LIMIT 1`);
  const target = rows[0];
  if (!target) fail("该老师不在你当前的管理名单中。", "FORBIDDEN");
  return getTeacherWorkspace({ ...event, recordType: event.recordType || "VERIFICATION" }, Object.freeze({
    role: "teacher", teacherId: String(target.teacher_id), teacherCode: String(target.teacher_code || ""),
    teacherName: String(target.teacher_name || ""), teacherPhone: String(target.phone || ""),
    staffId: Number(target.staff_id), teamReadScopeSql: membership.predicate
  }));
}

async function deleteFacePerson(api, groupId, personId) {
  if (!personId) return;
  try { await api.DeletePerson({ GroupId: groupId, PersonId: personId }); } catch (error) { console.warn("Face person cleanup failed", error?.message || error); }
}

async function findCustomerByFacePerson(storeId, personId) {
  const rows = await executeSql(
    `SELECT id, customer_code, profile_photo_file_id, face_person_id,
            customer_status, customer_process_status, created_by_account_id,
            total_recharge_count, total_verification_count, total_experience_count, created_at
       FROM public.customers
      WHERE created_store_id = ${storeId}
        AND face_person_id = ${sqlText(personId)}
      LIMIT 1`
  );
  return rows[0] || null;
}

async function findCustomerByCode(customerCodeValue) {
  const rows = await executeSql(
    `SELECT id, customer_code, customer_name, birth_date, notes,
            profile_photo_file_id, face_person_id, created_store_id, created_by_account_id,
            customer_status, customer_process_status,
            total_recharge_count, total_verification_count, total_experience_count, created_at
       FROM public.customers
      WHERE customer_code = ${sqlText(customerCodeValue)}
      LIMIT 1`
  );
  return rows[0] || null;
}

async function deleteCustomerRecord(storeId, personId) {
  if (!personId) return;
  try {
    await executeSql(
      `DELETE FROM public.customers
        WHERE created_store_id = ${storeId}
          AND face_person_id = ${sqlText(personId)}`
    );
  } catch (error) {
    console.warn("Customer database cleanup failed", error?.message || error);
  }
}

async function registerCustomer(event) {
  const caller = await activeCustomerCreationCaller(event);
  const name = String(event.customerName || "").trim();
  const birthDate = validDate(event.birthDate);
  const notes = String(event.notes || "").trim();
  const clientRequestId = optionalClientRequestId(event.clientRequestId);
  const consent = event.consent === true;
  if (!name || name.length > 64) fail("Customer name is required and must not exceed 64 characters.");
  if (!consent) fail("Explicit customer consent is required before collecting a face photo.", "CONSENT_REQUIRED");
  if (notes.length > 500) fail("Notes must not exceed 500 characters.");

  let personId = customerCode(caller.storeId, clientRequestId);
  if (clientRequestId) {
    const existing = await findCustomerByCode(personId);
    if (existing) {
      const sameRequestData = String(existing.created_store_id) === String(caller.storeId)
        && String(existing.created_by_account_id) === String(caller.staffId)
        && String(existing.customer_name) === name
        && String(existing.birth_date || "").slice(0, 10) === birthDate
        && String(existing.notes || "") === notes;
      if (!sameRequestData) fail("同一个 clientRequestId 已用于另一份客户资料，请重新发起建档。", "IDEMPOTENCY_CONFLICT");
      return {
        ok: true,
        idempotentReplay: true,
        customer: {
          id: String(existing.id),
          customerCode: existing.customer_code,
          customerName: existing.customer_name,
          birthDate: String(existing.birth_date || "").slice(0, 10),
          notes: existing.notes || "",
          photoFileId: existing.profile_photo_file_id,
          facePersonId: existing.face_person_id,
          faceId: "",
          customerStatus: existing.customer_status,
          customerProcessStatus: existing.customer_process_status,
          totalRechargeCount: Number(existing.total_recharge_count || 0),
          totalVerificationCount: Number(existing.total_verification_count || 0),
          totalExperienceCount: Number(existing.total_experience_count || 0),
          storeId: String(existing.created_store_id),
          captureQuality: null,
          liveness: null,
          createdAt: existing.created_at
        }
      };
    }
  }

  const { base64, buffer } = cleanImage(event.imageBase64);
  const groupId = required("FACE_GROUP_ID");
  const api = faceClient();
  let storedPhoto = null;
  let personCreated = false;
  try {
    const quality = await inspectFaceImage(api, base64);
    const liveness = await inspectLiveness(api, base64);
    const faceResult = await api.CreatePerson({
      GroupId: groupId,
      PersonId: personId,
      PersonName: name,
      Image: base64,
      // One natural person may intentionally own multiple independent customer
      // profiles. Each profile gets its own customer code and PersonId. The
      // selected profile is verified later with a 1:1 face comparison, so a
      // group-wide duplicate-face rejection must not be used here.
      UniquePersonControl: 0,
      QualityControl: 3,
      NeedRotateDetection: 0
    });
    personCreated = true;
    if (!faceResult?.FaceId) fail("人脸服务没有返回有效 FaceId，客户档案未创建。", "FACE_ENROLLMENT_INCOMPLETE");
    storedPhoto = await uploadCustomerPhoto(caller.storeId, personId, buffer);
    const fileID = storedPhoto.reference;
    const saved = await executeSql(
      `INSERT INTO public.customers
        (customer_code, customer_name, birth_date, notes, profile_photo_file_id,
         face_person_id, customer_status, customer_process_status,
         total_recharge_count, total_verification_count, total_experience_count,
         created_store_id, created_by_account_id)
       VALUES
        (${sqlText(personId)}, ${sqlText(name)}, ${sqlText(birthDate)}::date, ${sqlText(notes)}, ${sqlText(fileID)},
         ${sqlText(personId)}, 'ACTIVE', 'INFORMATION_ONLY', 0, 0, 0,
         ${caller.storeId}, ${caller.staffId})
       RETURNING id, customer_code, profile_photo_file_id, face_person_id,
                 customer_status, customer_process_status, created_by_account_id,
                 total_recharge_count, total_verification_count, total_experience_count, created_at`
    );
    // CloudBase can successfully execute a writable statement without exposing
    // the rows produced by RETURNING. Read the persisted row back before
    // treating an empty write result as a failure.
    const customer = saved[0] || await findCustomerByFacePerson(caller.storeId, personId);
    if (!customer) fail("Customer record was not returned after creation.", "DATABASE_ERROR");
    return {
      ok: true,
      customer: {
        id: String(customer.id),
        customerCode: customer.customer_code,
        customerName: name,
        birthDate,
        notes,
        photoFileId: customer.profile_photo_file_id,
        facePersonId: customer.face_person_id,
        faceId: faceResult.FaceId || "",
        customerStatus: customer.customer_status,
        customerProcessStatus: customer.customer_process_status,
        totalRechargeCount: Number(customer.total_recharge_count || 0),
        totalVerificationCount: Number(customer.total_verification_count || 0),
        totalExperienceCount: Number(customer.total_experience_count || 0),
        storeId: String(caller.storeId),
        captureQuality: quality,
        liveness,
        createdAt: customer.created_at
      }
    };
  } catch (error) {
    await deleteCustomerRecord(caller.storeId, personId);
    await deleteUploadedFile(storedPhoto);
    if (personCreated) await deleteFacePerson(api, groupId, personId);
    throw error;
  }
}

async function validateCapture(event) {
  await activeCustomerCreationCaller(event);
  const { base64 } = cleanImage(event.imageBase64);
  const api = faceClient();
  const quality = await inspectFaceImage(api, base64);
  const liveness = await inspectLiveness(api, base64);
  return { ok: true, accepted: true, quality, liveness };
}

let teacherAttendanceSchemaReady = null;

async function requireTeacherAttendanceSchema() {
  if (teacherAttendanceSchemaReady === true) return;
  const rows = await executeSql(
    `SELECT TO_REGCLASS('public.teacher_attendance_face_profiles') IS NOT NULL AS profile_table,
            TO_REGCLASS('public.teacher_attendance_records') IS NOT NULL AS attendance_table,
            EXISTS (
              SELECT 1 FROM pg_trigger
               WHERE tgrelid = TO_REGCLASS('public.teacher_attendance_records')
                 AND tgname = 'trg_teacher_attendance_insert_v78'
                 AND NOT tgisinternal
            ) AS attendance_trigger,
            EXISTS (
              SELECT 1 FROM information_schema.columns
               WHERE table_schema = 'public'
                 AND table_name = 'teacher_attendance_records'
                 AND column_name = 'attendance_type'
            ) AS attendance_type_ready,
            EXISTS (
              SELECT 1 FROM information_schema.columns
               WHERE table_schema = 'public'
                 AND table_name = 'teacher_attendance_records'
                 AND column_name = 'photo_object_ref'
                 AND EXISTS (SELECT 1 FROM pg_trigger
                              WHERE tgrelid = TO_REGCLASS('public.teacher_attendance_records')
                                AND tgname = 'trg_z_teacher_attendance_photo_v88' AND NOT tgisinternal)
                 AND EXISTS (SELECT 1 FROM pg_constraint
                              WHERE conrelid = TO_REGCLASS('public.teacher_attendance_records')
                                AND conname = 'teacher_attendance_photo_check_v89' AND convalidated)
            ) AS attendance_address_ready`
  );
  const row = rows?.[0] || {};
  if (!databaseBoolean(row.profile_table) || !databaseBoolean(row.attendance_table)
      || !databaseBoolean(row.attendance_trigger) || !databaseBoolean(row.attendance_type_ready)
      || !databaseBoolean(row.attendance_address_ready)) {
    fail("老师考勤高清照片数据库结构尚未启用，请先执行并验收迁移 089。", "ATTENDANCE_SCHEMA_MISSING");
  }
  teacherAttendanceSchemaReady = true;
}

let teacherPhotoAttendanceSchemaReady = false;
async function requireTeacherPhotoAttendanceSchema() {
  if (teacherPhotoAttendanceSchemaReady) return;
  const [row] = await executeSql(`SELECT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = TO_REGCLASS('public.teacher_attendance_records')
      AND conname = 'teacher_attendance_method_check_v90' AND convalidated
  ) AS photo_attendance_ready`);
  if (!databaseBoolean(row?.photo_attendance_ready)) {
    fail("照片打卡数据库结构尚未启用，请先执行并验收迁移 090。", "ATTENDANCE_PHOTO_SCHEMA_MISSING");
  }
  teacherPhotoAttendanceSchemaReady = true;
}

function attendanceCoordinate(value, label, minimum, maximum) {
  const number = Number(value);
  if (!Number.isFinite(number) || number < minimum || number > maximum) {
    fail(`${label}无效，请重新获取当前位置。`, "LOCATION_INVALID");
  }
  return number;
}

function attendancePlatform(value) {
  const platform = String(value || "UNKNOWN").trim().toUpperCase();
  return ["IOS", "ANDROID", "IPAD", "OTHER", "UNKNOWN"].includes(platform) ? platform : "OTHER";
}

function attendanceRequestId(value) {
  const requestId = String(value || "").trim();
  if (!/^[A-Za-z0-9_-]{8,96}$/.test(requestId)) fail("打卡请求编号无效。", "BAD_REQUEST");
  return requestId;
}

function attendanceType(value) {
  const type = String(value || "CLOCK_IN").trim().toUpperCase();
  if (!['CLOCK_IN', 'CLOCK_OUT'].includes(type)) fail("打卡类型无效。", "BAD_REQUEST");
  return type;
}

function attendanceCoordinateType(value) {
  const type = String(value || "GCJ02").trim().toUpperCase();
  return ["GCJ02", "WGS84"].includes(type) ? type : "GCJ02";
}

function attendanceAddressText(value, maximum) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, maximum);
}

function mainlandChinaCoordinate(latitude, longitude) {
  return latitude >= 18.0 && latitude <= 53.6 && longitude >= 73.5 && longitude <= 135.1;
}

function getJson(url, timeoutMs = 2800) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const request = https.get(url, { headers: { Accept: "application/json", "User-Agent": "lusizhuoer-attendance/1.0" } }, (response) => {
      const chunks = [];
      let bytes = 0;
      response.on("data", (chunk) => {
        bytes += chunk.length;
        if (bytes > 512 * 1024) {
          response.destroy(new Error("reverse geocode response is too large"));
          return;
        }
        chunks.push(chunk);
      });
      response.on("end", () => {
        if (settled) return;
        settled = true;
        if (response.statusCode < 200 || response.statusCode >= 300) {
          reject(new Error(`reverse geocode HTTP ${response.statusCode}`));
          return;
        }
        try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf8"))); }
        catch (_) { reject(new Error("reverse geocode returned invalid JSON")); }
      });
    });
    request.setTimeout(timeoutMs, () => request.destroy(new Error("reverse geocode timed out")));
    request.on("error", (error) => {
      if (settled) return;
      settled = true;
      reject(error);
    });
  });
}

async function tencentAttendanceAddress(latitude, longitude) {
  const key = String(process.env.TENCENT_MAP_KEY || "").trim();
  if (!key) return null;
  const query = new URLSearchParams({
    location: `${latitude},${longitude}`,
    key,
    output: "json",
    get_poi: "1",
    poi_options: "policy=1;radius=1000;page_size=5;page_index=1"
  });
  const payload = await getJson(`https://apis.map.qq.com/ws/geocoder/v1/?${query.toString()}`);
  if (Number(payload?.status) !== 0 || !payload?.result) throw new Error(`Tencent reverse geocode failed: ${payload?.status || "unknown"}`);
  const result = payload.result;
  const poi = Array.isArray(result.pois) ? result.pois[0] : null;
  const reference = result.address_reference || {};
  const component = result.address_component || {};
  const formatted = result.formatted_addresses || {};
  const placeName = [
    poi?.title,
    reference.landmark_l2?.title,
    reference.landmark_l1?.title,
    formatted.recommend,
    component.street_number,
    component.street
  ].map((item) => attendanceAddressText(item, 160)).find(Boolean) || "";
  const formattedAddress = attendanceAddressText(
    result.address || poi?.address || formatted.recommend || formatted.rough || placeName,
    500
  );
  if (!placeName && !formattedAddress) throw new Error("Tencent reverse geocode returned no address");
  return { placeName, formattedAddress, provider: "TENCENT" };
}

async function hereAttendanceAddress(latitude, longitude) {
  const key = String(process.env.HERE_GEOCODING_API_KEY || "").trim();
  if (!key) return null;
  const query = new URLSearchParams({
    at: `${latitude},${longitude}`,
    lang: "zh-CN",
    limit: "5",
    apiKey: key
  });
  const payload = await getJson(`https://revgeocode.search.hereapi.com/v1/revgeocode?${query.toString()}`);
  const item = Array.isArray(payload?.items) ? payload.items[0] : null;
  if (!item) throw new Error("HERE reverse geocode returned no address");
  const address = item.address || {};
  const placeName = [
    item.title,
    address.houseNumber && address.street ? `${address.street} ${address.houseNumber}` : "",
    address.street,
    address.district,
    address.city
  ].map((value) => attendanceAddressText(value, 160)).find(Boolean) || "";
  const formattedAddress = attendanceAddressText(address.label || item.title || placeName, 500);
  return { placeName, formattedAddress, provider: "HERE" };
}

async function resolveAttendanceAddress(latitude, longitude) {
  const china = mainlandChinaCoordinate(latitude, longitude);
  const providers = china
    ? [tencentAttendanceAddress, hereAttendanceAddress]
    : [hereAttendanceAddress, tencentAttendanceAddress];
  let configured = false;
  for (const provider of providers) {
    const isTencent = provider === tencentAttendanceAddress;
    if (isTencent ? process.env.TENCENT_MAP_KEY : process.env.HERE_GEOCODING_API_KEY) configured = true;
    try {
      const result = await provider(latitude, longitude);
      if (result) return { ...result, resolved: true, warning: "" };
    } catch (error) {
      console.warn("Attendance reverse geocode provider failed", isTencent ? "TENCENT" : "HERE", error?.message || error);
    }
  }
  return {
    placeName: "",
    formattedAddress: "",
    provider: "",
    resolved: false,
    warning: configured ? "附近地点暂时未能匹配，经纬度和地图位置仍会正常保存。" : "地址服务尚未配置，经纬度和地图位置仍会正常保存。"
  };
}

function attendanceLocationSigningKey() {
  return crypto.createHash("sha256")
    .update("lusizhuoer-attendance-location-v1\0")
    .update(cloudbaseServiceRoleKey())
    .digest();
}

function base64UrlEncode(value) {
  return Buffer.from(value).toString("base64").replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function base64UrlDecode(value) {
  const text = String(value || "").replace(/-/g, "+").replace(/_/g, "/");
  return Buffer.from(text + "=".repeat((4 - text.length % 4) % 4), "base64").toString("utf8");
}

function signAttendanceLocation(payload) {
  const body = base64UrlEncode(JSON.stringify(payload));
  const signature = crypto.createHmac("sha256", attendanceLocationSigningKey()).update(body).digest("base64")
    .replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  return `${body}.${signature}`;
}

function verifiedAttendanceAddressToken(token, staffId, latitude, longitude) {
  const value = String(token || "").trim();
  if (!value) return null;
  const [body, signature, extra] = value.split(".");
  if (!body || !signature || extra) fail("打卡地址确认已失效，请重新获取当前位置。", "ATTENDANCE_LOCATION_TOKEN_INVALID");
  const expected = crypto.createHmac("sha256", attendanceLocationSigningKey()).update(body).digest("base64")
    .replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  const left = Buffer.from(signature), right = Buffer.from(expected);
  if (left.length !== right.length || !crypto.timingSafeEqual(left, right)) {
    fail("打卡地址确认已失效，请重新获取当前位置。", "ATTENDANCE_LOCATION_TOKEN_INVALID");
  }
  let payload;
  try { payload = JSON.parse(base64UrlDecode(body)); }
  catch (_) { fail("打卡地址确认已失效，请重新获取当前位置。", "ATTENDANCE_LOCATION_TOKEN_INVALID"); }
  if (Number(payload.v) !== 1 || Number(payload.s) !== Number(staffId) || Number(payload.exp) < Date.now()
      || Math.abs(Number(payload.lat) - latitude) > 0.0001
      || Math.abs(Number(payload.lng) - longitude) > 0.0001) {
    fail("打卡地址确认已超过有效期或位置已变化，请重新获取。", "ATTENDANCE_LOCATION_TOKEN_EXPIRED");
  }
  return {
    placeName: attendanceAddressText(payload.pn, 160),
    formattedAddress: attendanceAddressText(payload.fa, 500),
    provider: attendanceAddressText(payload.pr, 24),
    resolved: Boolean(payload.pn || payload.fa)
  };
}

async function resolveTeacherAttendanceLocation(event) {
  const caller = await activeTeacherCaller();
  await requireTeacherAttendanceSchema();
  const latitude = attendanceCoordinate(event.latitude, "纬度", -90, 90);
  const longitude = attendanceCoordinate(event.longitude, "经度", -180, 180);
  const accuracy = attendanceCoordinate(event.accuracy, "定位精度", 0.01, 500);
  const coordinateType = attendanceCoordinateType(event.coordinateType);
  const address = await resolveAttendanceAddress(latitude, longitude);
  const issuedAt = Date.now();
  const locationToken = signAttendanceLocation({
    v: 1,
    s: Number(caller.staffId),
    lat: Number(latitude.toFixed(6)),
    lng: Number(longitude.toFixed(6)),
    a: Number(accuracy.toFixed(2)),
    ct: coordinateType,
    pn: address.placeName,
    fa: address.formattedAddress,
    pr: address.provider,
    iat: issuedAt,
    exp: issuedAt + 5 * 60 * 1000
  });
  return { ok: true, ...address, locationToken, expiresAt: issuedAt + 5 * 60 * 1000 };
}

function attendanceRecord(row = {}) {
  if (!row.id) return null;
  return {
    id: String(row.id),
    attendanceDate: String(row.attendance_date || "").slice(0, 10),
    attendanceType: String(row.attendance_type || "CLOCK_IN"),
    checkedInAt: row.checked_in_at || null,
    latitude: Number(row.latitude),
    longitude: Number(row.longitude),
    accuracy: Number(row.accuracy_m),
    attendanceMethod: String(row.attendance_method || "FACE"),
    faceScore: row.face_score == null ? null : Number(row.face_score),
    faceRequestId: row.face_request_id == null ? null : String(row.face_request_id),
    devicePlatform: String(row.device_platform || "UNKNOWN"),
    placeName: String(row.place_name || ""),
    formattedAddress: String(row.formatted_address || ""),
    addressProvider: String(row.address_provider || "")
  };
}

async function clockInTeacherAttendance(event) {
  const caller = await activeTeacherCaller();
  await requireTeacherAttendanceSchema();
  await requireTeacherPhotoAttendanceSchema();
  const staffId = Number(caller.staffId);
  const teacherId = Number(caller.teacherId);
  const type = attendanceType(event.attendanceType);
  const clientRequestId = attendanceRequestId(event.clientRequestId);
  const existingRows = await executeSql(
    `SELECT * FROM public.teacher_attendance_records
      WHERE staff_account_id = ${staffId}::bigint
        AND attendance_date = (CLOCK_TIMESTAMP() AT TIME ZONE 'Asia/Shanghai')::date
        AND attendance_type = ${sqlText(type)}
      LIMIT 1`
  );
  if (existingRows[0]) return { ok: true, idempotentReplay: true, attendance: attendanceRecord(existingRows[0]) };
  if (event.photoEvidenceConsent !== true) fail("请更新客户端并同意保存本次打卡照片。", "ATTENDANCE_PHOTO_CONSENT_REQUIRED");

  if (type === "CLOCK_OUT") {
    const clockInRows = await executeSql(
      `SELECT id FROM public.teacher_attendance_records
        WHERE teacher_id = ${teacherId}::bigint
          AND staff_account_id = ${staffId}::bigint
          AND attendance_date = (CLOCK_TIMESTAMP() AT TIME ZONE 'Asia/Shanghai')::date
          AND attendance_type = 'CLOCK_IN'
        LIMIT 1`
    );
    if (!clockInRows[0]) fail("请先完成今天的上班打卡，再进行下班打卡。", "ATTENDANCE_CLOCK_IN_REQUIRED");
  }

  const latitude = attendanceCoordinate(event.latitude, "纬度", -90, 90);
  const longitude = attendanceCoordinate(event.longitude, "经度", -180, 180);
  const accuracy = attendanceCoordinate(event.accuracy, "定位精度", 0.01, 500);
  const platform = attendancePlatform(event.devicePlatform);
  const address = verifiedAttendanceAddressToken(event.locationToken, staffId, latitude, longitude)
    || await resolveAttendanceAddress(latitude, longitude);
  const { base64 } = cleanImage(event.imageBase64);
  if (Buffer.byteLength(base64, "base64") > MAX_VERIFICATION_IMAGE_BYTES) {
    fail("现场照片不得超过 3MB，请重新拍摄。", "PHOTO_TOO_LARGE");
  }
  // Photo-only attendance: decode/validate the submitted capture, not a face.
  // Never call IAI here or require an enrollment; customer verification is separate.
  // DB time is shared by the baked-in stamp and the immutable punch timestamp.
  const [clock] = await executeSql("SELECT CLOCK_TIMESTAMP() AS photo_taken_at");
  if (!clock?.photo_taken_at) fail("无法确认打卡时间，请稍后重试。", "ATTENDANCE_TIME_UNAVAILABLE");
  const { prepareAttendancePhoto } = require("./attendance-photo");
  let photo;
  try { photo = await prepareAttendancePhoto(Buffer.from(base64, "base64"), clock.photo_taken_at, type); }
  catch (error) {
    if (error?.code === "ATTENDANCE_HD_PHOTO_TOO_LARGE") fail("高清打卡照片超过 3MB，请减少复杂背景后重新拍摄；未自动降低清晰度。", "ATTENDANCE_HD_PHOTO_TOO_LARGE");
    fail("打卡照片处理失败，请重新拍照。", "ATTENDANCE_PHOTO_PROCESSING_FAILED");
  }
  const digest = crypto.createHash("sha256").update(photo.buffer).digest("hex");
  const uploaded = await uploadVerificationPhotoObject(`attendance/${crypto.randomBytes(24).toString("hex")}.jpg`, photo.buffer);
  const stored = await downloadVerificationPhotoAuthenticated(uploaded.reference, MAX_VERIFICATION_IMAGE_BYTES, { allowAttendance: true });
  if (stored.length !== photo.buffer.length || crypto.createHash("sha256").update(stored).digest("hex") !== digest) {
    fail("打卡照片保存校验失败，尚未完成打卡。", "ATTENDANCE_PHOTO_INCOMPLETE");
  }

  const rows = await executeSql(
    `WITH inserted AS (
       INSERT INTO public.teacher_attendance_records
         (teacher_id, staff_account_id, attendance_date, attendance_type, attendance_method, latitude, longitude,
          accuracy_m, face_score, face_request_id, quality_score, liveness_score,
          client_request_id, device_platform, place_name, formatted_address, address_provider,
          photo_object_ref, photo_bytes, photo_sha256, photo_width, photo_height, photo_taken_at)
       VALUES
         (${teacherId}::bigint, ${staffId}::bigint,
          (CLOCK_TIMESTAMP() AT TIME ZONE 'Asia/Shanghai')::date,
          ${sqlText(type)}, 'PHOTO',
          ${latitude}::numeric, ${longitude}::numeric, ${accuracy}::numeric,
          NULL, NULL, NULL, NULL,
          ${sqlText(clientRequestId)}, ${sqlText(platform)},
          ${address.placeName ? sqlText(address.placeName) : "NULL"},
          ${address.formattedAddress ? sqlText(address.formattedAddress) : "NULL"},
          ${address.provider ? sqlText(address.provider) : "NULL"},
          ${sqlText(uploaded.reference)}, ${photo.buffer.length}, ${sqlText(digest)},
          ${photo.width}, ${photo.height}, ${sqlText(clock.photo_taken_at)}::timestamptz)
       ON CONFLICT (staff_account_id, attendance_date, attendance_type) DO NOTHING
       RETURNING *
     )
     SELECT * FROM inserted
     UNION ALL
     SELECT * FROM public.teacher_attendance_records
      WHERE staff_account_id = ${staffId}::bigint
        AND attendance_date = (CLOCK_TIMESTAMP() AT TIME ZONE 'Asia/Shanghai')::date
        AND attendance_type = ${sqlText(type)}
        AND NOT EXISTS (SELECT 1 FROM inserted)
     LIMIT 1`
  );
  // A committed CloudBase write can return no RETURNING rows. Never delete
  // an uploaded object on an uncertain result, or overwrite a concurrent winner.
  const confirmed = rows[0] || (await executeSql(
    `SELECT * FROM public.teacher_attendance_records
      WHERE staff_account_id = ${staffId}::bigint
        AND client_request_id = ${sqlText(clientRequestId)} LIMIT 1`
  ))[0];
  if (!confirmed) fail("打卡结果未能回读，请勿重复拍照并联系管理员检查。", "ATTENDANCE_RESULT_UNCONFIRMED");
  if (confirmed.photo_object_ref !== uploaded.reference) await deleteVerificationPhotoObject(uploaded.reference, { allowAttendance: true });
  return { ok: true, idempotentReplay: confirmed.client_request_id !== clientRequestId, attendance: attendanceRecord(confirmed) };
}

async function getAttendancePhoto(event) {
  const { uid } = app().auth().getUserInfo();
  if (!uid) fail("请先登录。", "UNAUTHENTICATED");
  const id = String(event.attendanceId || "");
  if (!/^[1-9]\d{0,17}$/.test(id)) fail("打卡记录无效。", "BAD_REQUEST");
  await requireTeacherAttendanceSchema();
  // Preserve the original self/HQ fast path. Only an otherwise denied
  // request attempts the separately scoped group read, including during rollout.
  const readPhoto = (groupPhotoScope = "") => executeSql(
    `SELECT attendance.id, attendance.checked_in_at, attendance.photo_object_ref,
            attendance.photo_bytes, attendance.photo_sha256, attendance.photo_width, attendance.photo_height
       FROM public.teacher_attendance_records AS attendance
       JOIN public.staff_accounts AS actor ON actor.auth_uid = ${sqlText(uid)}
       JOIN public.teachers AS teacher ON teacher.id = attendance.teacher_id
      WHERE attendance.id = ${id}::bigint AND actor.account_status = 'ACTIVE'
        AND (actor.role_code = 'hq' OR
             (actor.role_code = 'teacher' AND actor.id = attendance.staff_account_id
              AND teacher.staff_account_id = actor.id AND teacher.teacher_status = 'ACTIVE') ${groupPhotoScope})
      LIMIT 1`
  );
  let rows = await readPhoto();
  if (!rows[0]) {
    rows = await teacherTeamReads().safeRead(async () => await teacherTeamReads().available()
      ? readPhoto(`OR (actor.role_code = 'teacher' AND ${teacherTeamReads().scope(uid, 'attendance.teacher_id')})`) : []);
  }
  const row = rows[0];
  if (!row) fail("无权查看该次打卡照片。", "FORBIDDEN");
  if (!row.photo_object_ref) return { ok: true, attendanceId: id, photo: null };
  const reference = verificationPhotoReference(row.photo_object_ref);
  if (!/^attendance\/[a-f0-9]{48}\.jpg$/.test(reference.objectName)) fail("打卡照片引用异常。", "ATTENDANCE_PHOTO_INVALID");
  if (event.readBytes === true) {
    const buffer = await downloadVerificationPhotoAuthenticated(row.photo_object_ref, MAX_VERIFICATION_IMAGE_BYTES, { allowAttendance: true });
    if (buffer.length !== Number(row.photo_bytes) || crypto.createHash("sha256").update(buffer).digest("hex") !== row.photo_sha256) {
      fail("打卡照片读取不完整，请重新读取。", "ATTENDANCE_PHOTO_INCOMPLETE");
    }
    return { ok: true, attendanceId: id, photo: { imageBase64: buffer.toString("base64"), bytes: buffer.length } };
  }
  if (event.authorizeOnly === true) return { ok: true, attendanceId: id, photo: { bytes: Number(row.photo_bytes) } };
  const signed = await signVerificationPhoto(row.photo_object_ref, 120, { allowAttendance: true, thumbnailTransform: false });
  return { ok: true, attendanceId: id, photo: { url: signed.url, expiresIn: signed.expiresIn,
    checkedInAt: row.checked_in_at, bytes: Number(row.photo_bytes), width: Number(row.photo_width), height: Number(row.photo_height) } };
}

// Normal and teacher-gift EXPERIENCE verification share this customer-face
// evidence writer. The logged-in teacher is the quota owner, never the face
// subject; both workflows persist the selected customer's 1:1 evidence.
async function persistVerifiedFaceEvidence({
  caller,
  customerId,
  faceRequestId,
  original,
  thumbnail,
  dimensions
}) {
  const faceEvidenceToken = crypto.randomBytes(24).toString("hex");
  const objectPrefix = `face-evidence/${caller.storeId}/${caller.staffId}/${faceEvidenceToken}`;
  let uploadedOriginal = null;
  let uploadedThumbnail = null;
  try {
    const uploadResults = await Promise.allSettled([
      uploadVerificationPhotoObject(`${objectPrefix}/original.jpg`, original.buffer),
      uploadVerificationPhotoObject(`${objectPrefix}/thumbnail.jpg`, thumbnail.buffer)
    ]);
    if (uploadResults[0].status === "fulfilled") uploadedOriginal = uploadResults[0].value;
    if (uploadResults[1].status === "fulfilled") uploadedThumbnail = uploadResults[1].value;
    const uploadFailure = uploadResults.find((item) => item.status === "rejected");
    if (uploadFailure) throw uploadFailure.reason;
    const evidenceTtlMinutes = Math.trunc(numberSetting("VERIFICATION_FACE_EVIDENCE_TTL_MINUTES", 30, 5, 120));
    await executeSql(
      `INSERT INTO public.verification_photo_drafts
        (evidence_token, store_id, customer_id, submitted_by_account_id,
         face_subject_type, face_subject_teacher_id,
         face_request_id, original_object_ref, thumbnail_object_ref,
         original_bytes, thumbnail_bytes, image_width, image_height,
         sha256, expires_at)
       VALUES
         (${sqlText(faceEvidenceToken)}, ${caller.storeId}, ${sqlText(customerId)}::bigint,
         ${caller.staffId}, 'CUSTOMER', NULL, ${sqlText(faceRequestId)},
         ${sqlText(uploadedOriginal.reference)}, ${sqlText(uploadedThumbnail.reference)},
         ${original.buffer.length}, ${thumbnail.buffer.length},
         ${dimensions.width}, ${dimensions.height},
         ${sqlText(crypto.createHash("sha256").update(original.buffer).digest("hex"))},
         NOW() + (${evidenceTtlMinutes} * INTERVAL '1 minute'))`
    );
    return faceEvidenceToken;
  } catch (error) {
    await Promise.all([
      deleteVerificationPhotoObject(uploadedOriginal?.reference),
      deleteVerificationPhotoObject(uploadedThumbnail?.reference)
    ]);
    throw error;
  }
}

async function verifyCustomerFace(event) {
  const caller = await activeBusinessCaller(event);
  await requireVerificationSubmissionSchema();
  await requireVerificationFaceSubjectSchema();
  const customerCode = String(event.customerCode || "").trim();
  if (!customerCode || customerCode.length > 96) fail("必须提供已选择客户的有效编号。", "CUSTOMER_REQUIRED");

  // 客户编号只能用于定位本门店已经确认的客户。真正送给腾讯云的 PersonId
  // 始终由服务端从数据库读取，不能信任浏览器传入的人脸 ID。
  const rows = await executeSql(
    `SELECT id, customer_code, customer_name, face_person_id, profile_photo_file_id
       FROM public.customers
      WHERE customer_code = ${sqlText(customerCode)}
        AND created_store_id = ${caller.storeId}
        AND customer_status = 'ACTIVE'
      LIMIT 1`
  );
  const customer = rows[0];
  if (!customer) fail("未找到本门店已选择的活跃客户。", "CUSTOMER_NOT_FOUND");
  if (!customer.face_person_id || !customer.profile_photo_file_id) {
    fail("该客户缺少有效建档照片或人脸档案，暂时不能进行核销。", "FACE_PROFILE_MISSING");
  }

  const original = cleanVerificationJpeg(event.imageBase64, "现场人脸照片", MAX_VERIFICATION_IMAGE_BYTES);
  const thumbnail = cleanVerificationJpeg(event.thumbnailBase64, "现场人脸缩略图", MAX_THUMBNAIL_BYTES);
  const dimensions = verificationPhotoDimensions(event);
  const { base64 } = original;
  const api = faceClient();
  const quality = await inspectFaceImage(api, base64);
  const liveness = await inspectLiveness(api, base64);
  const settings = faceSettings();
  const result = await api.VerifyFace({
    PersonId: String(customer.face_person_id),
    Image: base64,
    QualityControl: 3,
    NeedRotateDetection: 0
  });
  const score = Number(result?.Score || 0);
  const matched = result?.IsMatch === true && score >= settings.verifyThreshold;

  let faceEvidenceToken = "";
  if (matched) {
    faceEvidenceToken = await persistVerifiedFaceEvidence({
      caller,
      customerId: customer.id,
      faceRequestId: result?.RequestId || "",
      original,
      thumbnail,
      dimensions
    });
  }

  return {
    ok: true,
    matched,
    customerCode: customer.customer_code,
    customerName: customer.customer_name,
    score: rounded(score),
    threshold: settings.verifyThreshold,
    quality,
    liveness,
    requestId: result?.RequestId || "",
    faceEvidenceToken,
    message: matched
      ? "所选客户的 1:1 人脸验证已通过。"
      : "现场人脸与所选客户的建档人脸不一致，请核对客户或重新拍照。"
  };
}

async function getVerificationPhotos(event) {
  const context = await verificationPhotoContext(event, { allowTeacherLookupRead: true });
  const rows = await executeSql(
    `SELECT photo_slot, photo_kind, thumbnail_object_ref, original_object_ref,
            face_subject_type, face_subject_teacher_id,
            original_bytes, thumbnail_bytes, image_width, image_height,
            created_at, updated_at
       FROM public.verification_photos
      WHERE verification_id = ${context.verificationId}::bigint
      ORDER BY photo_slot`
  );
  const expiresIn = verificationPhotoUrlTtlSeconds();
  // The grid needs at most five thumbnails. Sign those five in one bounded
  // wave instead of three two-item waves; the lower reliability layer still
  // caps total signing concurrency at six and retries transient failures.
  // Full-size URLs remain strictly on demand after a user opens or exports.
  const photos = await mapWithConcurrency(rows, 5, async (row) => {
    let thumbnailUrl = "";
    let thumbnailUrlExpiresIn = 0;
    let thumbnailError = "";
    const retainedProfile = String(row.photo_kind || "") === "PROFILE";
    const generatedExtraThumbnail = String(row.photo_kind || "") === "EXTRA"
      && String(row.thumbnail_object_ref || "") === String(row.original_object_ref || "");
    const [thumbnailResult] = await Promise.allSettled([
      signVerificationPhoto(row.thumbnail_object_ref, expiresIn, {
        allowRetainedProfile: retainedProfile,
        thumbnailTransform: retainedProfile || generatedExtraThumbnail
      })
    ]);
    if (thumbnailResult.status === "fulfilled") {
      thumbnailUrl = thumbnailResult.value.url;
      thumbnailUrlExpiresIn = thumbnailResult.value.expiresIn;
    }
    else thumbnailError = String(thumbnailResult.reason?.code || "PHOTO_THUMBNAIL_UNAVAILABLE");
    return {
      slot: Number(row.photo_slot),
      kind: String(row.photo_kind || ""),
      faceSubjectType: String(row.face_subject_type || context.record.face_subject_type || "CUSTOMER"),
      faceSubjectTeacherId: row.face_subject_teacher_id
        ? String(row.face_subject_teacher_id)
        : "",
      thumbnailUrl,
      thumbnailUrlExpiresIn,
      thumbnailError,
      originalUrl: "",
      originalUrlExpiresIn: 0,
      originalError: "",
      originalBytes: Number(row.original_bytes || 0),
      thumbnailBytes: Number(row.thumbnail_bytes || 0),
      width: Number(row.image_width || 0),
      height: Number(row.image_height || 0),
      uploadedAt: row.updated_at || row.created_at
    };
  });
  return {
    ok: true,
    recordId: String(context.record.id),
    recordCode: String(context.record.verification_code || ""),
    submittedAt: context.record.submitted_at,
    editableUntil: context.record.editable_until,
    isSubmitter: String(context.record.submitted_by_account_id) === String(context.caller.staffId),
    canEdit: context.canEdit,
    faceSubjectType: String(context.record.face_subject_type || "CUSTOMER"),
    faceSubjectTeacherId: context.record.face_subject_teacher_id
      ? String(context.record.face_subject_teacher_id)
      : "",
    faceSubject: String(context.record.face_subject_type || "CUSTOMER") === "TEACHER"
      ? {
          type: "TEACHER",
          teacherId: String(context.record.face_subject_teacher_id || ""),
          teacherCode: String(context.record.face_subject_teacher_code || ""),
          teacherName: String(context.record.face_subject_teacher_name || "")
        }
      : {
          type: "CUSTOMER",
          customerId: String(context.record.customer_id || ""),
          customerCode: String(context.record.customer_code || ""),
          customerName: String(context.record.customer_name || "")
        },
    maxPhotos: 5,
    expiresIn,
    photos
  };
}

async function verificationPhotoOriginalContext(event) {
  const context = await verificationPhotoContext(event, { allowTeacherLookupRead: true });
  const slot = Number(event.slot);
  if (!Number.isInteger(slot) || slot < 0 || slot > 4) fail("核销照片位置无效。", "PHOTO_SLOT_INVALID");
  const rows = await executeSql(
    `SELECT photo_kind, original_object_ref, original_bytes, image_width, image_height
       FROM public.verification_photos
      WHERE verification_id = ${context.verificationId}::bigint
        AND photo_slot = ${slot}
      LIMIT 1`
  );
  const photo = rows[0];
  if (!photo) fail("该照片位置尚未上传。", "PHOTO_NOT_FOUND");
  await executeSql(
    `INSERT INTO public.verification_photo_events
      (verification_id, photo_slot, event_type, actor_account_id)
     VALUES
      (${context.verificationId}::bigint, ${slot}::smallint,
       'VIEW_ORIGINAL', ${context.caller.staffId}::bigint)`
  );
  return { context, slot, photo };
}

async function getVerificationPhotoOriginalUrl(event) {
  const { slot, photo } = await verificationPhotoOriginalContext(event);
  const expiresIn = verificationPhotoUrlTtlSeconds();
  const signedPhoto = await signVerificationPhoto(photo.original_object_ref, expiresIn, {
    allowRetainedProfile: String(photo.photo_kind || "") === "PROFILE"
  });
  return {
    ok: true,
    slot,
    photoUrl: signedPhoto.url,
    originalBytes: Number(photo.original_bytes || 0),
    width: Number(photo.image_width || 0),
    height: Number(photo.image_height || 0),
    expiresIn: signedPhoto.expiresIn
  };
}

async function getVerificationPhotoExportData(event) {
  // Export uses the same live authorization and VIEW_ORIGINAL audit as an
  // interactive view, but reads the private object through the authenticated
  // storage API. It therefore remains reliable when temporary URL signing is
  // degraded and never makes the evidence bucket public.
  const { slot, photo } = await verificationPhotoOriginalContext(event);
  if (Number(photo.original_bytes || 0) > MAX_IMAGE_BYTES) {
    fail("核销照片原图超过安全导出大小。", "PHOTO_EXPORT_TOO_LARGE");
  }
  let buffer;
  try {
    buffer = await downloadVerificationPhotoAuthenticated(photo.original_object_ref, MAX_IMAGE_BYTES, {
      allowRetainedProfile: String(photo.photo_kind || "") === "PROFILE"
    });
  } catch (error) {
    if (String(error?.code || "") === "PHOTO_UPLOAD_INCOMPLETE") {
      fail("核销照片存储文件未找到。", "PHOTO_NOT_FOUND");
    }
    throw error;
  }
  if (Number(photo.original_bytes || 0) > 0 && buffer.length !== Number(photo.original_bytes)) {
    fail("核销照片存储内容与数据库记录不一致。", "PHOTO_EXPORT_INVALID");
  }
  const dimensions = jpegDimensions(buffer);
  return {
    ok: true,
    slot,
    imageBase64: `data:image/jpeg;base64,${buffer.toString("base64")}`,
    bytes: buffer.length,
    width: dimensions.width,
    height: dimensions.height
  };
}

async function requireVerificationPhotoUploadSchema() {
  if (verificationPhotoUploadSchemaReady === true) return;
  const rows = await executeSql(
    `SELECT
       TO_REGCLASS('public.verification_photo_upload_requests') IS NOT NULL AS has_table,
       TO_REGPROCEDURE(
         'public.begin_verification_photo_upload(character varying,bigint,smallint,bigint,character varying,character varying,integer,integer)'
       ) IS NOT NULL AS has_begin,
       TO_REGPROCEDURE(
         'public.commit_verification_photo_upload(character varying,bigint,bigint,integer,integer,integer,character)'
       ) IS NOT NULL AS has_commit,
       TO_REGPROCEDURE(
         'public.cancel_verification_photo_upload(character varying,bigint,bigint)'
       ) IS NOT NULL AS has_cancel`
  );
  const schema = rows[0] || {};
  if (![schema.has_table, schema.has_begin, schema.has_commit, schema.has_cancel].every(databaseBoolean)) {
    fail("核销照片直传数据库尚未升级，请先执行迁移 039。", "DATABASE_SCHEMA_MISSING");
  }
  verificationPhotoUploadSchemaReady = true;
}

async function verificationPhotoUploadSchemaHealth() {
  try {
    const rows = await executeSql(
      `SELECT
         TO_REGCLASS('public.verification_photo_upload_requests') IS NOT NULL AS has_table,
         TO_REGPROCEDURE(
           'public.begin_verification_photo_upload(character varying,bigint,smallint,bigint,character varying,character varying,integer,integer)'
         ) IS NOT NULL AS has_begin,
         TO_REGPROCEDURE(
           'public.commit_verification_photo_upload(character varying,bigint,bigint,integer,integer,integer,character)'
         ) IS NOT NULL AS has_commit,
         TO_REGPROCEDURE(
           'public.cancel_verification_photo_upload(character varying,bigint,bigint)'
         ) IS NOT NULL AS has_cancel`
    );
    const schema = rows[0] || {};
    return {
      ready: [schema.has_table, schema.has_begin, schema.has_commit, schema.has_cancel].every(databaseBoolean),
      error: ""
    };
  } catch (error) {
    return { ready: false, error: String(error?.code || "DATABASE_CHECK_FAILED") };
  }
}

function requireVerificationPhotoUploadOwner(context, options = {}) {
  const isOwner = ["hq", "store", "teacher"].includes(context.caller.role)
    && String(context.record.submitted_by_account_id) === String(context.caller.staffId);
  if (!isOwner) fail("只有提交该核销单的账号可以管理补充照片。", "PHOTO_SUBMITTER_ONLY");
  if (options.requireWindow === true && !context.canEdit) {
    fail("该核销单已超过提交后的 24 小时，不能再上传或替换照片。", "PHOTO_WINDOW_EXPIRED");
  }
}

function verificationPhotoUploadSlot(event = {}) {
  const slot = Number(event.slot);
  if (!Number.isInteger(slot) || slot < 2 || slot > 4) {
    fail("只能上传补充照片 1 至 3。", "PHOTO_SLOT_INVALID");
  }
  return slot;
}

function verificationPhotoUploadState(row) {
  return {
    requestId: String(row.request_id || ""),
    status: String(row.request_status || row.status || ""),
    slot: Number(row.photo_slot),
    expectedBytes: Number(row.expected_original_bytes || 0),
    expiresAt: row.expires_at || null,
    committedAt: row.committed_at || null,
    cancelledAt: row.cancelled_at || null
  };
}

function verificationPhotoUploadConflict(row) {
  return {
    ok: false,
    code: "PHOTO_UPLOAD_ALREADY_ACTIVE",
    message: "该核销单已有一张照片正在上传，请先等待完成或取消当前上传。",
    activeRequest: verificationPhotoUploadState(row)
  };
}

async function availableVerificationPhotoUploadStorage(requiredBytes) {
  const candidates = verificationPhotoStorageCandidates();
  if (!candidates.length) fail("未配置核销照片私有存储桶。", "PHOTO_BUCKET_NOT_CONFIGURED");
  const rows = await executeSql(
    `SELECT id, name, public, file_size_limit, allowed_mime_types
       FROM storage.buckets
      WHERE id IN (${candidates.map((candidate) => sqlText(candidate.bucketId)).join(",")})`
  );
  const metadata = new Map(rows.map((row) => [String(row.id || ""), row]));
  const storage = candidates.find((candidate) => verificationPhotoBucketReady(metadata.get(candidate.bucketId), requiredBytes));
  if (!storage) {
    fail(
      `当前 PostgreSQL 环境中找不到配置合格的私有照片桶 ${candidates.map((candidate) => candidate.bucketId).join(" / ")}；请确认桶存在、保持私有、允许 image/jpeg，且单文件上限不少于照片大小。`,
      metadata.size ? "PHOTO_BUCKET_CONFIGURATION_INVALID" : "PHOTO_BUCKET_NOT_FOUND"
    );
  }
  return storage;
}

async function verificationPhotoStorageHealth() {
  const configuredBucketIds = [...new Set([
    String(process.env.VERIFICATION_PHOTO_BUCKET_ID || "verification-photos").trim(),
    String(process.env.CUSTOMER_PHOTO_BUCKET_ID || "customer-photos").trim()
  ].filter(Boolean))];
  try {
    const rows = configuredBucketIds.length ? await executeSql(
      `SELECT id, name, public, file_size_limit, allowed_mime_types
         FROM storage.buckets
        WHERE id IN (${configuredBucketIds.map(sqlText).join(",")})
        ORDER BY id`
    ) : [];
    const availableBucketIds = rows.map((row) => String(row.id || "")).filter(Boolean);
    const readyBucketIds = rows.filter((row) => verificationPhotoBucketReady(row))
      .map((row) => String(row.id || "")).filter(Boolean);
    const serviceRoleKeyConfigured = cloudbaseServiceRoleKeyConfigured();
    let serviceRoleStorageReady = false;
    let serviceRoleStorageError = "";
    let serviceRoleStorageRequestId = "";
    if (!availableBucketIds.length) {
      serviceRoleStorageError = "PHOTO_BUCKET_NOT_FOUND";
    } else if (!readyBucketIds.length) {
      serviceRoleStorageError = "PHOTO_BUCKET_CONFIGURATION_INVALID";
    } else if (!serviceRoleKeyConfigured) {
      serviceRoleStorageError = "SERVICE_ROLE_KEY_MISSING";
    } else {
      const storage = verificationPhotoStorageCandidates()
        .find((candidate) => readyBucketIds.includes(candidate.bucketId));
      if (!storage) {
        serviceRoleStorageError = "PHOTO_BUCKET_CONFIG_MISMATCH";
      } else {
        try {
          await manager().storage.listObjects({
            bucketId: storage.bucketId,
            limit: 1,
            withDelimiter: false,
            accessToken: storage.accessToken,
            envId: storage.envId
          });
          serviceRoleStorageReady = true;
        } catch (error) {
          serviceRoleStorageError = String(error?.code || "PHOTO_STORAGE_ACCESS_FAILED");
          serviceRoleStorageRequestId = String(error?.requestId || error?.RequestId || "");
        }
      }
    }
    return {
      configuredBucketIds,
      availableBucketIds,
      readyBucketIds,
      bucketMetadataReady: readyBucketIds.length > 0,
      bucketCheckError: "",
      serviceRoleStorageReady,
      serviceRoleStorageError,
      serviceRoleStorageRequestId
    };
  } catch (error) {
    return {
      configuredBucketIds,
      availableBucketIds: [],
      readyBucketIds: [],
      bucketMetadataReady: false,
      bucketCheckError: String(error?.code || "DATABASE_CHECK_FAILED"),
      serviceRoleStorageReady: false,
      serviceRoleStorageError: "DATABASE_CHECK_FAILED",
      serviceRoleStorageRequestId: ""
    };
  }
}

async function beginVerificationPhotoUpload(event) {
  await requireVerificationPhotoUploadSchema();
  const context = await verificationPhotoContext(event);
  requireVerificationPhotoUploadOwner(context);
  const requestId = verificationPhotoUploadRequestId(event);
  const slot = verificationPhotoUploadSlot(event);
  const originalBytes = verificationPhotoUploadBytes(event);
  const existingRows = await executeSql(
    `SELECT request_id, status AS request_status, photo_slot, bucket_id,
            original_object_ref, expected_original_bytes, expires_at,
            committed_at, cancelled_at
       FROM public.verification_photo_upload_requests
      WHERE verification_id = ${context.verificationId}::bigint
        AND actor_account_id = ${context.caller.staffId}::bigint
        AND (request_id = ${sqlText(requestId)}
             OR (status = 'UPLOADING' AND expires_at > CLOCK_TIMESTAMP()))
      ORDER BY (request_id = ${sqlText(requestId)}) DESC, created_at
      LIMIT 1`
  );
  const existing = existingRows[0];
  if (existing && String(existing.request_id) === requestId
      && String(existing.request_status) === "COMMITTED") {
    if (Number(existing.photo_slot) !== slot
        || Number(existing.expected_original_bytes) !== originalBytes) {
      fail("同一上传请求编号不能对应不同照片或照片位。", "PHOTO_UPLOAD_REQUEST_MISMATCH");
    }
    return {
      ok: true,
      ...verificationPhotoUploadState(existing),
      editableUntil: context.record.editable_until,
      alreadyCommitted: true
    };
  }
  if (existing && String(existing.request_id) !== requestId
      && String(existing.request_status) === "UPLOADING") {
    return verificationPhotoUploadConflict(existing);
  }
  requireVerificationPhotoUploadOwner(context, { requireWindow: true });

  let uploadMode = "DIRECT";
  let signedUploadFailure = null;
  let objectReference = String(existing?.original_object_ref || "");
  let bucketId = String(existing?.bucket_id || "");
  if (!objectReference) {
    const storage = await availableVerificationPhotoUploadStorage(originalBytes);
    const nonce = crypto.randomBytes(24).toString("hex");
    const objectName = `records/${context.verificationId}/slot-${slot}/direct-${Date.now()}-${nonce}.jpg`;
    bucketId = storage.bucketId;
    objectReference = `pg://${bucketId}/${objectName}`;
  }

  let rows;
  try {
    rows = await executeSql(
      `SELECT *
         FROM public.begin_verification_photo_upload(
           ${sqlText(requestId)}::varchar,
           ${context.verificationId}::bigint,
           ${slot}::smallint,
           ${context.caller.staffId}::bigint,
           ${sqlText(bucketId)}::varchar,
           ${sqlText(objectReference)}::varchar,
           ${originalBytes}::integer,
           ${verificationPhotoUploadTtlSeconds()}::integer
         )`
    );
  } catch (error) {
    if (String(error?.message || "").includes("PHOTO_UPLOAD_RATE_LIMITED")) {
      fail("该核销单短时间内发起的照片上传过多，请一小时后再试。", "PHOTO_UPLOAD_RATE_LIMITED");
    }
    throw error;
  }
  const request = rows[0];
  if (!request) fail("照片上传请求未能建立。", "PHOTO_UPLOAD_BEGIN_FAILED");
  if (!databaseBoolean(request.request_matches)) return verificationPhotoUploadConflict(request);
  const state = verificationPhotoUploadState(request);
  if (state.status === "COMMITTED") {
    return { ok: true, ...state, editableUntil: context.record.editable_until, alreadyCommitted: true };
  }
  if (state.status !== "UPLOADING") {
    return {
      ok: false,
      code: "PHOTO_UPLOAD_REQUEST_CLOSED",
      message: "该照片上传请求已经取消或过期，请重新选择照片。",
      ...state
    };
  }
  const storedReference = String(request.original_object_ref || objectReference);
  let upload = null;
  try {
    upload = await signVerificationPhotoUploadReference(storedReference);
  } catch (error) {
    if (PHOTO_ONLY_FUNCTION) {
      try {
        await executeSql(
          `SELECT *
             FROM public.cancel_verification_photo_upload(
               ${sqlText(requestId)}::varchar,
               ${context.verificationId}::bigint,
               ${context.caller.staffId}::bigint
             )`
        );
      } catch (cancelError) {
        console.error("Failed to cancel verification-photo intent after signed upload failure", {
          verificationId: context.verificationId,
          slot,
          code: String(cancelError?.code || "PHOTO_UPLOAD_CANCEL_FAILED"),
          requestId: cancelError?.requestId || cancelError?.RequestId || ""
        });
      }
      const unavailable = new Error("补充照片签名直传地址生成失败，请稍后重试。");
      unavailable.code = "PHOTO_UPLOAD_SIGN_FAILED";
      unavailable.requestId = error?.requestId || error?.RequestId || "";
      throw unavailable;
    }
    if (!signedUploadFunctionFallbackAllowed(error)) throw error;
    if (originalBytes > MAX_VERIFICATION_FUNCTION_FALLBACK_BYTES) {
      const unavailable = new Error("该照片超过云函数兼容通道上限，请稍后重试签名直传。");
      unavailable.code = "PHOTO_UPLOAD_SIGN_FAILED";
      unavailable.requestId = error?.requestId || error?.RequestId || "";
      throw unavailable;
    }
    await requireVerificationPhotoFunctionFallbackStorage(storedReference);
    uploadMode = "FUNCTION";
    signedUploadFailure = error;
  }
  if (uploadMode === "FUNCTION" && signedUploadFailure) {
    console.warn("Signed verification-photo upload unavailable; using the authenticated cloud-function fallback", {
      verificationId: context.verificationId,
      slot,
      bucketId,
      code: String(signedUploadFailure?.code || "PHOTO_UPLOAD_SIGN_FAILED"),
      requestId: signedUploadFailure?.requestId || signedUploadFailure?.RequestId || ""
    });
  }
  return {
    ok: true,
    ...state,
    editableUntil: context.record.editable_until,
    uploadMode,
    functionUploadProof: uploadMode === "FUNCTION"
      ? verificationPhotoFunctionUploadProof(context, request)
      : undefined,
    originalUpload: upload ? { ...upload, expectedBytes: state.expectedBytes } : null,
    thumbnailUpload: null
  };
}

async function getVerificationPhotoUploadStatus(event) {
  await requireVerificationPhotoUploadSchema();
  const context = await verificationPhotoContext(event);
  requireVerificationPhotoUploadOwner(context);
  const requestId = verificationPhotoUploadRequestId(event);
  await executeSql(
    `UPDATE public.verification_photo_upload_requests
        SET status = 'EXPIRED', updated_at = NOW()
      WHERE request_id = ${sqlText(requestId)}
        AND verification_id = ${context.verificationId}::bigint
        AND actor_account_id = ${context.caller.staffId}::bigint
        AND status = 'UPLOADING'
        AND expires_at <= CLOCK_TIMESTAMP()`
  );
  const rows = await executeSql(
    `SELECT request_id, status AS request_status, photo_slot,
            original_object_ref, expected_original_bytes, expires_at,
            committed_at, cancelled_at
       FROM public.verification_photo_upload_requests
      WHERE request_id = ${sqlText(requestId)}
        AND verification_id = ${context.verificationId}::bigint
        AND actor_account_id = ${context.caller.staffId}::bigint
      LIMIT 1`
  );
  const request = rows[0];
  if (!request) fail("未找到照片上传请求。", "PHOTO_UPLOAD_REQUEST_NOT_FOUND");
  let objectUploaded = false;
  let uploadedBytes = 0;
  if (String(request.request_status) === "UPLOADING") {
    try {
      const reference = verificationPhotoReference(request.original_object_ref);
      const storage = verificationPhotoStorageForEvidence(reference);
      if (!storage) fail("核销照片不属于允许的私有存储桶。", "PHOTO_BUCKET_MISMATCH");
      const response = await manager().storage.getObjectInfoAuthenticated({
        bucketId: reference.bucketId,
        objectName: reference.objectName,
        method: "GET",
        accessToken: storage.accessToken,
        envId: storage.envId
      });
      const info = verificationPhotoObjectInfoBody(response);
      uploadedBytes = Number(info?.size || 0);
      objectUploaded = uploadedBytes > 0;
    } catch (error) {
      if (!storageObjectMissing(error)) throw error;
    }
  }
  return {
    ok: true,
    ...verificationPhotoUploadState(request),
    editableUntil: context.record.editable_until,
    objectUploaded,
    uploadedBytes
  };
}

async function cancelVerificationPhotoUpload(event) {
  await requireVerificationPhotoUploadSchema();
  const context = await verificationPhotoContext(event);
  requireVerificationPhotoUploadOwner(context);
  const requestId = verificationPhotoUploadRequestId(event);
  const rows = await executeSql(
    `SELECT *
       FROM public.cancel_verification_photo_upload(
         ${sqlText(requestId)}::varchar,
         ${context.verificationId}::bigint,
         ${context.caller.staffId}::bigint
       )`
  );
  const request = rows[0];
  if (!request) fail("未找到照片上传请求。", "PHOTO_UPLOAD_REQUEST_NOT_FOUND");
  const state = verificationPhotoUploadState(request);
  if (state.status === "COMMITTED") {
    return {
      ok: false,
      code: "PHOTO_UPLOAD_ALREADY_COMMITTED",
      message: "照片已经保存，不能再取消本次上传。",
      ...state
    };
  }
  return {
    ok: true,
    ...state,
    cancelledNow: databaseBoolean(request.cancelled_now),
    cleanupPending: true
  };
}

async function commitVerificationPhotoUpload(event) {
  await requireVerificationPhotoUploadSchema();
  const context = await verificationPhotoContext(event);
  requireVerificationPhotoUploadOwner(context);
  const requestId = verificationPhotoUploadRequestId(event);
  const requestRows = await executeSql(
    `SELECT request_id, status AS request_status, photo_slot,
            original_object_ref, expected_original_bytes, expires_at,
            committed_at, cancelled_at
       FROM public.verification_photo_upload_requests
      WHERE request_id = ${sqlText(requestId)}
        AND verification_id = ${context.verificationId}::bigint
        AND actor_account_id = ${context.caller.staffId}::bigint
      LIMIT 1`
  );
  const request = requestRows[0];
  if (!request) fail("未找到照片上传请求。", "PHOTO_UPLOAD_REQUEST_NOT_FOUND");
  const initialState = verificationPhotoUploadState(request);
  if (initialState.status === "CANCELLED" || initialState.status === "EXPIRED") {
    return {
      ok: false,
      code: "PHOTO_UPLOAD_REQUEST_CLOSED",
      message: "该照片上传请求已经取消或过期，请重新选择照片。",
      ...initialState
    };
  }
  if (initialState.status === "COMMITTED") {
    return { ok: true, ...initialState, alreadyCommitted: true };
  }
  requireVerificationPhotoUploadOwner(context, { requireWindow: true });
  if (PHOTO_ONLY_FUNCTION && event.imageBase64) {
    fail("独立核销照片服务只接受签名直传后的无字节提交。", "PHOTO_DIRECT_UPLOAD_REQUIRED");
  }
  let inspected;
  if (event.imageBase64) {
    requireVerificationPhotoFunctionUploadProof(event, context, request);
    const fallbackPhoto = cleanVerificationJpeg(
      event.imageBase64,
      "补充照片",
      MAX_VERIFICATION_FUNCTION_FALLBACK_BYTES
    );
    if (fallbackPhoto.buffer.length !== Number(request.expected_original_bytes)) {
      fail("补充照片大小与上传请求不一致，请取消后重试。", "PHOTO_UPLOAD_SIZE_MISMATCH");
    }
    await uploadVerificationPhotoReference(request.original_object_ref, fallbackPhoto.buffer);
    // The cloud function supplied these exact bytes to the private storage
    // API. Validate the JPEG once in memory and avoid immediately downloading
    // the same object again. uploadVerificationPhotoReference already performs
    // an authenticated byte-for-byte comparison when a retry finds an object
    // at the request-bound immutable path, so lost-response idempotency remains
    // fail-closed without adding two storage round trips to every upload.
    inspected = verificationPhotoBufferMetadata(fallbackPhoto.buffer);
  } else {
    inspected = await inspectVerificationPhotoObject(
      request.original_object_ref,
      Number(request.expected_original_bytes)
    );
  }
  const rows = await executeSql(
    `SELECT *
       FROM public.commit_verification_photo_upload(
         ${sqlText(requestId)}::varchar,
         ${context.verificationId}::bigint,
         ${context.caller.staffId}::bigint,
         ${inspected.bytes}::integer,
         ${inspected.width}::integer,
         ${inspected.height}::integer,
         ${sqlText(inspected.sha256)}::char(64)
       )`
  );
  const committed = rows[0];
  if (!committed) fail("照片保存事务没有返回结果。", "PHOTO_UPLOAD_COMMIT_FAILED");
  const status = String(committed.request_status || "");
  if (status !== "COMMITTED") {
    return {
      ok: false,
      code: "PHOTO_UPLOAD_REQUEST_CLOSED",
      message: "照片上传请求已在其他页面取消或过期，请重新选择照片。",
      requestId,
      status
    };
  }
  const staleReferences = [...new Set([
    committed.old_original_object_ref,
    committed.old_thumbnail_object_ref
  ].filter((value) => value && value !== request.original_object_ref))];
  await Promise.all(staleReferences.map((reference) => deleteVerificationPhotoObject(reference)));
  const expiresIn = verificationPhotoUrlTtlSeconds();
  let thumbnailUrl = "";
  let thumbnailError = "";
  try {
    const signedThumbnail = await signVerificationPhoto(request.original_object_ref, expiresIn, {
      thumbnailTransform: true
    });
    thumbnailUrl = signedThumbnail.url;
  } catch (error) {
    thumbnailError = String(error?.code || "PHOTO_THUMBNAIL_UNAVAILABLE");
  }
  return {
    ok: true,
    requestId,
    status,
    committedNow: databaseBoolean(committed.committed_now),
    recordId: String(context.record.id),
    editableUntil: context.record.editable_until,
    canEdit: true,
    photo: {
      slot: Number(committed.photo_slot),
      kind: "EXTRA",
      thumbnailUrl,
      thumbnailError,
      originalBytes: Number(committed.original_bytes || 0),
      thumbnailBytes: 0,
      width: Number(committed.image_width || 0),
      height: Number(committed.image_height || 0),
      uploadedAt: committed.uploaded_at || committed.committed_at || new Date().toISOString()
    }
  };
}

async function uploadVerificationExtraPhoto(event) {
  // Migration 039 makes direct-upload intents the only write path. Keeping the
  // implementation below lets v51 remain deployable before the migration, but
  // once the intent table exists an old page or manual API call cannot bypass
  // the single-active-upload lock with a legacy Base64 request.
  const directUploadRows = await executeSql(
    `SELECT TO_REGCLASS('public.verification_photo_upload_requests') IS NOT NULL AS direct_upload_ready`
  );
  if (databaseBoolean(directUploadRows[0]?.direct_upload_ready)) {
    fail("当前版本必须使用可取消的照片直传流程，请刷新页面后重试。", "PHOTO_UPLOAD_DIRECT_REQUIRED");
  }
  const context = await verificationPhotoContext(event);
  if (!context.canEdit) {
    if (String(context.record.submitted_by_account_id) !== String(context.caller.staffId)) {
      fail("只有提交该核销单的账号可以上传或替换照片。", "PHOTO_SUBMITTER_ONLY");
    }
    fail("该核销单已超过提交后的 24 小时，不能再上传或替换照片。", "PHOTO_WINDOW_EXPIRED");
  }
  const slot = Number(event.slot);
  if (!Number.isInteger(slot) || slot < 2 || slot > 4) fail("只能上传补充照片 1 至 3。", "PHOTO_SLOT_INVALID");
  const original = cleanVerificationJpeg(event.imageBase64, "补充照片", MAX_EXTRA_VERIFICATION_IMAGE_BYTES);
  const thumbnail = cleanVerificationJpeg(event.thumbnailBase64, "补充照片缩略图", MAX_THUMBNAIL_BYTES);
  const dimensions = verificationPhotoDimensions(event);
  const nonce = crypto.randomBytes(12).toString("hex");
  const objectPrefix = `records/${context.verificationId}/slot-${slot}/${Date.now()}-${nonce}`;
  let uploadedOriginal = null;
  let uploadedThumbnail = null;
  let databaseSaved = false;
  try {
    const uploadResults = await Promise.allSettled([
      uploadVerificationPhotoObject(`${objectPrefix}-original.jpg`, original.buffer),
      uploadVerificationPhotoObject(`${objectPrefix}-thumbnail.jpg`, thumbnail.buffer)
    ]);
    if (uploadResults[0].status === "fulfilled") uploadedOriginal = uploadResults[0].value;
    if (uploadResults[1].status === "fulfilled") uploadedThumbnail = uploadResults[1].value;
    const uploadFailure = uploadResults.find((item) => item.status === "rejected");
    if (uploadFailure) throw uploadFailure.reason;
    const savedRows = await executeSql(
      `SELECT *
         FROM public.upsert_verification_extra_photo(
           ${context.verificationId}::bigint,
           ${slot}::smallint,
           ${context.caller.staffId}::bigint,
           ${sqlText(uploadedOriginal.reference)}::varchar,
           ${sqlText(uploadedThumbnail.reference)}::varchar,
           ${original.buffer.length}, ${thumbnail.buffer.length},
           ${dimensions.width}, ${dimensions.height},
           ${sqlText(crypto.createHash("sha256").update(original.buffer).digest("hex"))}::char(64)
         )`
    );
    databaseSaved = true;
    const saved = savedRows[0];
    await Promise.all([
      saved?.old_original_object_ref && saved.old_original_object_ref !== uploadedOriginal.reference
        ? deleteVerificationPhotoObject(saved.old_original_object_ref) : Promise.resolve(),
      saved?.old_thumbnail_object_ref && saved.old_thumbnail_object_ref !== uploadedThumbnail.reference
        ? deleteVerificationPhotoObject(saved.old_thumbnail_object_ref) : Promise.resolve()
    ]);
    const expiresIn = verificationPhotoUrlTtlSeconds();
    let thumbnailUrl = "";
    let thumbnailError = "";
    try {
      const signedThumbnail = await signVerificationPhoto(uploadedThumbnail.reference, expiresIn);
      thumbnailUrl = signedThumbnail.url;
    } catch (error) {
      // The immutable object references and database row are already saved.
      // A temporary preview-signing problem must not report the upload itself
      // as failed; the normal gallery refresh will retry signing separately.
      thumbnailError = String(error?.code || "PHOTO_THUMBNAIL_UNAVAILABLE");
      console.warn("Supplemental photo saved but immediate thumbnail signing failed", {
        verificationId: context.verificationId,
        slot,
        code: thumbnailError
      });
    }
    return {
      ok: true,
      recordId: String(context.record.id),
      editableUntil: context.record.editable_until,
      canEdit: true,
      photo: {
        slot,
        kind: "EXTRA",
        thumbnailUrl,
        thumbnailError,
        originalBytes: original.buffer.length,
        thumbnailBytes: thumbnail.buffer.length,
        width: dimensions.width,
        height: dimensions.height,
        uploadedAt: saved?.uploaded_at || new Date().toISOString()
      }
    };
  } catch (error) {
    if (!databaseSaved) {
      await Promise.all([
        deleteVerificationPhotoObject(uploadedOriginal?.reference),
        deleteVerificationPhotoObject(uploadedThumbnail?.reference)
      ]);
    }
    throw error;
  }
}

function requireVerificationPhotoCleanupToken(event) {
  requireCleanupControlPlaneCaller();
  const expectedToken = required("VERIFICATION_PHOTO_CLEANUP_TOKEN");
  if (expectedToken.length < 32) {
    fail("核销照片清理凭证配置无效，必须至少包含 32 个字符。", "CLEANUP_CONFIGURATION_INVALID");
  }
  const suppliedToken = String(event.cleanupToken || "");
  const expectedBuffer = Buffer.from(expectedToken);
  const suppliedBuffer = Buffer.from(suppliedToken);
  if (expectedBuffer.length !== suppliedBuffer.length || !crypto.timingSafeEqual(expectedBuffer, suppliedBuffer)) {
    fail("核销照片草稿清理凭证无效。", "FORBIDDEN");
  }
}

function verificationPhotoCleanupTokenConfigured() {
  return String(process.env.VERIFICATION_PHOTO_CLEANUP_TOKEN || "").trim().length >= 32;
}

function requireCleanupControlPlaneCaller() {
  let caller;
  try {
    caller = app().auth().getUserInfo();
  } catch (_) {
    fail("无法验证核销照片清理调用来源。", "CLEANUP_CALLER_UNVERIFIED");
  }
  if (String(caller?.uid || "").trim()) {
    fail("普通客户端不能执行核销照片清理。", "FORBIDDEN");
  }
}

function trustedCleanupTimerKind(event = {}, context = {}) {
  const eventType = String(event?.Type || "").trim();
  // A warm SCF instance may retain process environment state between calls.
  // Only the platform Timer event shape opts into this branch; once inside,
  // the reserved runtime source marker is mandatory as the trust boundary.
  if (eventType !== "Timer") return "";

  // TRIGGER_SRC and SCF_FUNCTIONNAME are reserved SCF runtime values. Unlike
  // event fields, an ordinary callFunction caller cannot manufacture them.
  const triggerSource = String(process.env.TRIGGER_SRC || "").trim();
  if (triggerSource !== "timer") {
    fail("核销照片定时清理调用来源无效。", "UNTRUSTED_TIMER_EVENT");
  }
  if (String(event?.TriggerName || "").trim() !== CLEANUP_TIMER_TRIGGER_NAME) {
    fail("核销照片定时清理触发器名称无效。", "UNTRUSTED_TIMER_EVENT");
  }
  const environmentFunctionName = String(process.env.SCF_FUNCTIONNAME || "").trim();
  const contextFunctionName = String(context?.function_name || "").trim();
  if (environmentFunctionName !== EXPECTED_FUNCTION_NAME
      || (contextFunctionName && contextFunctionName !== EXPECTED_FUNCTION_NAME)) {
    fail("核销照片定时清理函数身份无效。", "UNTRUSTED_TIMER_EVENT");
  }
  if (!Number.isFinite(Date.parse(String(event?.Time || "")))) {
    fail("核销照片定时清理时间无效。", "UNTRUSTED_TIMER_EVENT");
  }
  requireCleanupControlPlaneCaller();
  return PHOTO_ONLY_FUNCTION ? "UPLOADS" : "DRAFTS";
}

async function cleanupVerificationPhotoUploadRequests() {
  let uploadRequestsCleaned = 0;
  let uploadRequestBatchSize = 0;
  const schemaRows = await executeSql(
    `SELECT TO_REGCLASS('public.verification_photo_upload_requests') IS NOT NULL AS has_upload_requests`
  );
  if (!databaseBoolean(schemaRows[0]?.has_upload_requests)) {
    return { uploadRequestsCleaned, uploadRequestBatchSize };
  }
  await executeSql(
    `UPDATE public.verification_photo_upload_requests
        SET status = 'EXPIRED', updated_at = NOW()
      WHERE status = 'UPLOADING'
        AND expires_at <= CLOCK_TIMESTAMP()`
  );
  const uploadRows = await executeSql(
    `SELECT upload.request_id, upload.original_object_ref, upload.thumbnail_object_ref
       FROM public.verification_photo_upload_requests upload
      WHERE upload.status IN ('CANCELLED', 'EXPIRED')
        AND upload.cleanup_after <= CLOCK_TIMESTAMP()
        AND upload.objects_cleaned_at IS NULL
        AND NOT EXISTS (
          SELECT 1
            FROM public.verification_photos photo
           WHERE photo.verification_id = upload.verification_id
             AND (photo.original_object_ref = upload.original_object_ref
                  OR photo.thumbnail_object_ref = upload.original_object_ref
                  OR (upload.thumbnail_object_ref IS NOT NULL
                      AND (photo.original_object_ref = upload.thumbnail_object_ref
                           OR photo.thumbnail_object_ref = upload.thumbnail_object_ref)))
        )
      ORDER BY upload.cleanup_after, upload.request_id
      LIMIT 100`
  );
  uploadRequestBatchSize = uploadRows.length;
  for (const row of uploadRows) {
    const references = [...new Set([
      row.original_object_ref,
      row.thumbnail_object_ref
    ].filter(Boolean))];
    const deletionResults = await Promise.all(references.map((reference) => deleteVerificationPhotoObject(reference)));
    if (!deletionResults.every(Boolean)) continue;
    const updated = await executeSql(
      `UPDATE public.verification_photo_upload_requests
          SET objects_cleaned_at = NOW(), updated_at = NOW()
        WHERE request_id = ${sqlText(row.request_id)}
          AND status IN ('CANCELLED', 'EXPIRED')
          AND objects_cleaned_at IS NULL
      RETURNING request_id`
    );
    if (updated.length) uploadRequestsCleaned += 1;
  }
  await executeSql(
    `DELETE FROM public.verification_photo_upload_requests
      WHERE status IN ('CANCELLED', 'EXPIRED')
        AND objects_cleaned_at IS NOT NULL
        AND updated_at < NOW() - INTERVAL '7 days'`
  );
  await executeSql(
    `DELETE FROM public.verification_photo_upload_requests
      WHERE status = 'COMMITTED'
        AND committed_at < NOW() - INTERVAL '7 days'`
  );
  return { uploadRequestsCleaned, uploadRequestBatchSize };
}

async function runVerificationPhotoUploadsCleanup() {
  const uploadCleanup = await cleanupVerificationPhotoUploadRequests();
  return {
    ok: true,
    uploadRequestsCleaned: uploadCleanup.uploadRequestsCleaned,
    remainingBatchPossible: uploadCleanup.uploadRequestBatchSize === 100
  };
}

async function cleanupVerificationPhotoUploads(event) {
  requireVerificationPhotoCleanupToken(event);
  return runVerificationPhotoUploadsCleanup();
}

async function runVerificationPhotoDraftsCleanup() {
  // Claim candidates with a no-op UPDATE before touching storage. SKIP LOCKED
  // excludes a still-running order-creation transaction; the new row version
  // also forces any waiter to recheck the now-expired predicate. The grace
  // period and evidence anti-join are repeated again before final deletion.
  const rows = await executeSql(
    `WITH candidates AS (
       SELECT draft.evidence_token
         FROM public.verification_photo_drafts AS draft
        WHERE draft.consumed_at IS NULL
          AND draft.expires_at <= CLOCK_TIMESTAMP() - INTERVAL '10 minutes'
          AND NOT EXISTS (
            SELECT 1
              FROM public.verification_photos AS photo
             WHERE photo.source_evidence_token = draft.evidence_token
                OR photo.original_object_ref = draft.original_object_ref
                OR photo.thumbnail_object_ref = draft.original_object_ref
                OR photo.original_object_ref = draft.thumbnail_object_ref
                OR photo.thumbnail_object_ref = draft.thumbnail_object_ref
          )
        ORDER BY draft.expires_at, draft.evidence_token
        LIMIT 100
          FOR UPDATE OF draft SKIP LOCKED
     )
     UPDATE public.verification_photo_drafts AS draft
        SET expires_at = draft.expires_at
       FROM candidates
      WHERE draft.evidence_token = candidates.evidence_token
        AND draft.consumed_at IS NULL
        AND draft.expires_at <= CLOCK_TIMESTAMP() - INTERVAL '10 minutes'
        AND NOT EXISTS (
          SELECT 1
            FROM public.verification_photos AS photo
           WHERE photo.source_evidence_token = draft.evidence_token
              OR photo.original_object_ref = draft.original_object_ref
              OR photo.thumbnail_object_ref = draft.original_object_ref
              OR photo.original_object_ref = draft.thumbnail_object_ref
              OR photo.thumbnail_object_ref = draft.thumbnail_object_ref
        )
    RETURNING draft.evidence_token, draft.original_object_ref, draft.thumbnail_object_ref`
  );
  let cleaned = 0;
  for (const row of rows) {
    const deletionResults = await Promise.all([
      deleteVerificationPhotoObject(row.original_object_ref),
      deleteVerificationPhotoObject(row.thumbnail_object_ref)
    ]);
    if (!deletionResults.every(Boolean)) continue;
    const deleted = await executeSql(
      `DELETE FROM public.verification_photo_drafts
        WHERE evidence_token = ${sqlText(row.evidence_token)}
          AND consumed_at IS NULL
          AND expires_at <= CLOCK_TIMESTAMP() - INTERVAL '10 minutes'
          AND NOT EXISTS (
            SELECT 1
              FROM public.verification_photos AS photo
             WHERE photo.source_evidence_token = verification_photo_drafts.evidence_token
                OR photo.original_object_ref = verification_photo_drafts.original_object_ref
                OR photo.thumbnail_object_ref = verification_photo_drafts.original_object_ref
                OR photo.original_object_ref = verification_photo_drafts.thumbnail_object_ref
                OR photo.thumbnail_object_ref = verification_photo_drafts.thumbnail_object_ref
          )
      RETURNING evidence_token`
    );
    if (deleted.length) cleaned += 1;
  }
  return {
    ok: true,
    cleaned,
    remainingBatchPossible: rows.length === 100
  };
}

async function cleanupVerificationPhotoDrafts(event) {
  requireVerificationPhotoCleanupToken(event);
  return runVerificationPhotoDraftsCleanup();
}

async function handleTrustedCleanupTimer(event, context) {
  const kind = trustedCleanupTimerKind(event, context);
  if (!kind) return null;
  if (kind === "UPLOADS") return runVerificationPhotoUploadsCleanup();
  return runVerificationPhotoDraftsCleanup();
}

exports.main = async (event = {}, context = {}) => {
  try {
    const scheduledCleanup = await handleTrustedCleanupTimer(event, context);
    if (scheduledCleanup) return scheduledCleanup;
    const action = event.action || "health";
    if (action === "health") {
      const storageHealth = await verificationPhotoStorageHealth();
      if (PHOTO_ONLY_FUNCTION) {
        const schemaHealth = await verificationPhotoUploadSchemaHealth();
        const ready = schemaHealth.ready
          && storageHealth.bucketMetadataReady
          && storageHealth.serviceRoleStorageReady;
        return {
          ok: true,
          ready,
          version: FUNCTION_VERSION,
          service: "verificationPhoto",
          uploadMode: "DIRECT",
          photoBucketId: String(process.env.CUSTOMER_PHOTO_BUCKET_ID || "customer-photos").trim(),
          verificationPhotoBucketId: String(process.env.VERIFICATION_PHOTO_BUCKET_ID || "verification-photos").trim(),
          verificationPhotoFallbackBucketId: String(process.env.CUSTOMER_PHOTO_BUCKET_ID || "customer-photos").trim(),
          verificationPhotoUrlTtlSeconds: verificationPhotoUrlTtlSeconds(),
          verificationPhotoUploadTtlSeconds: verificationPhotoUploadTtlSeconds(),
          verificationPhotoCleanupConfigured: verificationPhotoCleanupTokenConfigured(),
          verificationPhotoServiceRoleKeyConfigured: cloudbaseServiceRoleKeyConfigured(),
          verificationPhotoCleanupTimerTriggerName: CLEANUP_TIMER_TRIGGER_NAME,
          verificationPhotoConfiguredBucketIds: storageHealth.configuredBucketIds,
          verificationPhotoAvailableBucketIds: storageHealth.availableBucketIds,
          verificationPhotoReadyBucketIds: storageHealth.readyBucketIds,
          verificationPhotoBucketMetadataReady: storageHealth.bucketMetadataReady,
          verificationPhotoBucketCheckError: storageHealth.bucketCheckError || undefined,
          verificationPhotoServiceRoleStorageReady: storageHealth.serviceRoleStorageReady,
          verificationPhotoServiceRoleStorageError: storageHealth.serviceRoleStorageError || undefined,
          verificationPhotoServiceRoleStorageRequestId: storageHealth.serviceRoleStorageRequestId || undefined,
          verificationPhotoUploadSchemaReady: schemaHealth.ready,
          verificationPhotoUploadSchemaError: schemaHealth.error || undefined,
          message: ready
            ? "Private verification photo service is ready."
            : "Verification photo service is reachable but its database or private storage configuration is incomplete."
        };
      }
      return {
        ok: true,
        version: FUNCTION_VERSION,
        groupId: required("FACE_GROUP_ID"),
        photoBucketId: String(process.env.CUSTOMER_PHOTO_BUCKET_ID || "customer-photos").trim(),
        verificationPhotoBucketId: String(process.env.VERIFICATION_PHOTO_BUCKET_ID || "verification-photos").trim(),
        verificationPhotoFallbackBucketId: String(process.env.CUSTOMER_PHOTO_BUCKET_ID || "customer-photos").trim(),
        verificationPhotoUrlTtlSeconds: verificationPhotoUrlTtlSeconds(),
        verificationPhotoUploadTtlSeconds: verificationPhotoUploadTtlSeconds(),
        verificationPhotoCleanupConfigured: verificationPhotoCleanupTokenConfigured(),
        verificationPhotoServiceRoleKeyConfigured: cloudbaseServiceRoleKeyConfigured(),
        verificationPhotoCleanupTimerTriggerName: CLEANUP_TIMER_TRIGGER_NAME,
        verificationPhotoConfiguredBucketIds: storageHealth.configuredBucketIds,
        verificationPhotoAvailableBucketIds: storageHealth.availableBucketIds,
        verificationPhotoReadyBucketIds: storageHealth.readyBucketIds,
        verificationPhotoBucketMetadataReady: storageHealth.bucketMetadataReady,
        verificationPhotoBucketCheckError: storageHealth.bucketCheckError || undefined,
        verificationPhotoServiceRoleStorageReady: storageHealth.serviceRoleStorageReady,
        verificationPhotoServiceRoleStorageError: storageHealth.serviceRoleStorageError || undefined,
        verificationPhotoServiceRoleStorageRequestId: storageHealth.serviceRoleStorageRequestId || undefined,
        attendanceTencentGeocoderConfigured: Boolean(String(process.env.TENCENT_MAP_KEY || "").trim()),
        attendanceHereGeocoderConfigured: Boolean(String(process.env.HERE_GEOCODING_API_KEY || "").trim()),
        attendancePhotoRuntime: event.attendancePhotoProbe === true
          ? await require("./attendance-photo").probeAttendancePhotoRuntime() : undefined,
        livenessEnabled: faceSettings().livenessEnabled,
        message: "Face customer enrollment and private verification photos are ready."
      };
    }
    if (PHOTO_ONLY_FUNCTION) {
      if (action === "getVerificationPhotos") return await getVerificationPhotos(event);
      if (action === "getVerificationPhotoOriginalUrl") return await getVerificationPhotoOriginalUrl(event);
      if (action === "getVerificationPhotoExportData") return await getVerificationPhotoExportData(event);
      if (action === "beginVerificationPhotoUpload") return await beginVerificationPhotoUpload(event);
      if (action === "getVerificationPhotoUploadStatus") return await getVerificationPhotoUploadStatus(event);
      if (action === "cancelVerificationPhotoUpload") return await cancelVerificationPhotoUpload(event);
      if (action === "commitVerificationPhotoUpload") return await commitVerificationPhotoUpload(event);
      if (action === "cleanupVerificationPhotoUploads") return await cleanupVerificationPhotoUploads(event);
      fail("Unsupported verification photo action.", "ACTION_NOT_FOUND");
    }
    if (action === "validateCapture") return await validateCapture(event);
    if (action === "resolveTeacherAttendanceLocation") return await resolveTeacherAttendanceLocation(event);
    if (action === "clockInTeacherAttendance") return await clockInTeacherAttendance(event);
    if (action === "getAttendancePhoto") return await getAttendancePhoto(event);
    if (action === "registerCustomer") return await registerCustomer(event);
    if (action === "listActiveStoreCustomers") return await listActiveStoreCustomers(event);
    if (action === "queryTeamInactiveVerificationCustomers") return await teacherTeamReads().safeRead(async () => queryInactiveVerificationCustomers(event, await teacherTeamReads().context(event)));
    if (action === "queryTeamLowBalanceCustomers") return await teacherTeamReads().safeRead(async () => queryLowBalanceCustomers(event, await teacherTeamReads().context(event)));
    if (action === "getTeamTeacherWorkspace") return await teacherTeamReads().safeRead(() => getTeamTeacherWorkspace(event));
    if (action === "queryStoreCustomers") return await queryStoreCustomers(event);
    if (action === "queryInactiveVerificationCustomers") return await queryInactiveVerificationCustomers(event);
    if (action === "queryLowBalanceCustomers") return await queryLowBalanceCustomers(event);
    if (action === "queryStoreBusinessRecords") return await queryStoreBusinessRecords(event);
    if (action === "getStoreDashboard") return await getStoreDashboard(event);
    if (action === "getStoreBusinessAnalytics") return await getStoreBusinessAnalytics(event);
    if (action === "getHqBusinessContext") return await getHqBusinessContext();
    if (action === "getTeacherBusinessContext") return await getTeacherBusinessContext();
    if (action === "queryTeacherCustomers") return await queryTeacherCustomers(event);
    if (action === "getTeacherLookupProductPurchase") return await getTeacherLookupProductPurchase(event);
    if (action === "getTeacherWorkspace") return await getTeacherWorkspace(event);
    if (action === "getHqTeacherWorkspace") return await getHqTeacherWorkspace(event);
    if (action === "getTeacherBusinessCustomers") return await getTeacherBusinessCustomers(event);
    if (action === "listActiveTeachers") return await listActiveTeachers(event);
    if (action === "listActiveProducts") return await listActiveProducts(event);
    if (action === "listActiveRetailProducts") return await listActiveRetailProducts(event);
    if (action === "getTeacherExperienceEntitlements") return await getTeacherExperienceEntitlements(event);
    if (action === "createRechargeApplication") return await createRechargeApplication(event);
    if (action === "createRetailProductPurchaseApplication") return await createRetailProductPurchaseApplication(event);
    if (action === "createSupplementVerificationApplication") return await createSupplementVerificationApplication(event);
    if (action === "createVerificationBleQualification") return await createVerificationBleQualification(event);
    if (action === "recoverVerificationBleQualification") return await recoverVerificationBleQualification(event);
    if (action === "issueVerificationBleAuthorization") return await issueVerificationBleAuthorization(event);
    if (action === "confirmVerificationBleWorkStarted") return await confirmVerificationBleWorkStarted(event);
    if (action === "createVerificationApplication") {
      fail("核销必须在人脸通过后连接 BLE 设备，旧直写入口已经关闭。", "BLE_REQUIRED");
    }
    if (action === "recoverBusinessSubmission") return await recoverBusinessSubmission(event);
    if (action === "getActiveStoreCustomerDetail") return await getActiveStoreCustomerDetail(event);
    if (action === "getCustomerPhotoUrl") return await getCustomerPhotoUrl(event);
    if (action === "getCustomerProductBalances") return await getCustomerProductBalances(event);
    if (action === "getCustomerStatus") return await getCustomerStatus(event);
    if (action === "getCustomerProfile") return await getCustomerProfile(event);
    if (action === "updateCustomerStatus") return await updateCustomerStatus(event);
    if (action === "updateCustomerNotes") return await updateCustomerNotes(event);
    if (action === "listCustomerMessages") return await listCustomerMessages(event);
    if (action === "addCustomerMessage") return await addCustomerMessage(event);
    if (action === "verifyCustomerFace") return await verifyCustomerFace(event);
    if (action === "getVerificationPhotos") return await getVerificationPhotos(event);
    if (action === "getVerificationPhotoOriginalUrl") return await getVerificationPhotoOriginalUrl(event);
    if (action === "getVerificationPhotoExportData") return await getVerificationPhotoExportData(event);
    if (action === "beginVerificationPhotoUpload") return await beginVerificationPhotoUpload(event);
    if (action === "getVerificationPhotoUploadStatus") return await getVerificationPhotoUploadStatus(event);
    if (action === "cancelVerificationPhotoUpload") return await cancelVerificationPhotoUpload(event);
    if (action === "commitVerificationPhotoUpload") return await commitVerificationPhotoUpload(event);
    if (action === "uploadVerificationExtraPhoto") return await uploadVerificationExtraPhoto(event);
    if (action === "cleanupVerificationPhotoDrafts") return await cleanupVerificationPhotoDrafts(event);
    fail("Unsupported action.");
  } catch (error) {
    console.error("faceRecognition failed", {
      action: event?.action || (event?.Type === "Timer" ? `Timer:${event?.TriggerName || "unknown"}` : "health"),
      code: error?.code || "FUNCTION_ERROR",
      message: error?.message || String(error)
    });
    return {
      ok: false,
      code: error?.code || "FUNCTION_ERROR",
      requestId: String(error?.RequestId || error?.requestId || "") || undefined,
      cleanupPending: error?.cleanupPending || undefined,
      message: error?.message || "Customer enrollment failed."
    };
  }
};
