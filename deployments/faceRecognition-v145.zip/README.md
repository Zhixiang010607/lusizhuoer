# faceRecognition 云函数

2026-11-09 三项目 HC-08 配置：`v145` 仅为海洋之蕴／海洋之韵新增 `haiyangzhiyun`、为露思康辰新增 `lusikangcheng` 固定类型，复用魔法柔肤现有 `LASER-BLE` 交互。三者采用相同 LA 编号／LA- 广播名、FFE0／FFE1、精简 q=1/2/3、20 字节分片与凯撒算法；原魔法柔肤配置、授权次数预留、30 秒授权、状态 2 后落单和防重实现不变。没有新 SQL，不重建函数、不改环境变量。先部署并核验 `faceRecognition-v145.zip`，再更新小程序；其他四个函数没有可部署代码变化，不重复上传。设备端两份独立 PDF 见 `docs/ble/2026-11-09-three-project-hc08.md`。

本次 2026-11-09 客户查询联动：老师以一个在职门店＋准确完整姓名查询（无默认客户、每页10条），通过既有客户主页只读查看非本人客户、其原有工单和照片。服务端每次按当前在职账号及实际客户校验门店／姓名／客户编号；仅只读 action 采用查询上下文。原创建／有效业务关系仍独立决定备注与留言写权，照片提交人、24小时截止、审核、扣次、BLE、评价签发均不扩权。无需新 SQL。部署顺序 faceRecognition v145、verificationPhoto v14、customerRating v10，然后上传小程序；staffAccount v107 无代码更新且短信开关不变。ZIP 根必须包含 teacher-customer-lookup.js（照片包还包含由 faceRecognition/index.js 生成的 service.js）。

该函数仅在 CloudBase 后端运行，用于门店与老师共享的客户建档、照片质量检测、私有照片留存、人脸人员库录入、1:1 核验和业务数据接口。总部只保留查询、审核、管理与已有记录读取，不能新建客户或业务工单。客户不需要提供身份证。核销单照片的列表、原图、导出及三个补充照片位上传已拆到独立的 `verificationPhoto v14`；当前静态前端不再把这些照片动作发给本函数。

当前版本：`v145`

本版只读导出：客户、充值／退费、核销查询支持 exportAll=true；保持原登录身份、门店条件、状态和时间筛选，一条 SQL 最多读取1001条，超过1000条拒绝导出，不分页拼接。无 SQL、无工单写入或审核状态机变更。

`v142` 在本人及总部／组长已授权的老师主页概要中增加当前所属组长姓名；无有效归属时返回空字符串，只显示文字，不增加组长主页链接或跨组权限。需先执行并验收迁移093，再部署 staffAccount v107 与本函数、更新客户端；本源码包不代表已部署。


`v141` 修正数据展示的一致性：客户查询、门店主页的活跃／封存客户列表及照片接口的客户概要中，充值显示审核通过的 `NEW` 历史总数，不再误用已扣退费的净开卡缓存；客户主页及照片概要的累计核销只显示已通过 `NORMAL`＋`SUPPLEMENT`，与单列体验分开。数据库净开卡、可退额度、余额、工单写入／审核、BLE、权限和组长范围均不变。客户业务阶段按用户最新决定改为历史已通过充值／正常核销，需先按完整备份门禁执行并验收 [迁移 092](../../database/cloudbase-console/092-README.md)；仅回填阶段列，不重算或修改工单与余额。总部／老师统计原来已经采用独立四类事件，本次不改其口径。客户主页五类业务记录另增 `historyPage`／`historyPageSize=10` 编号分页，每一类的计数、页码夹取和本页由一条 SQL 返回同一快照；保留旧客户端游标协议，先部署本函数再更新客户端，不修改历史业务记录。本源码包不代表已部署或已执行 SQL。

`v140` 增加老师组长专用只读接口：`getTeamTeacherWorkspace`、`queryTeamInactiveVerificationCustomers`、`queryTeamLowBalanceCustomers`，并允许有效组长读取当前成员的打卡照片。范围从当前 UID、迁移 091 的有效组长与当前成员关系派生，不能用客户端身份、老师编号或门店筛选扩大。活跃度、余次与 customerRating v10 的评价分析共用“当前组员＋组长本人”的可信关联客户范围；活跃度在授权客户内沿用原算法读取真实服务记录；余次只读这些客户的真实余额，不拆分、修改或扣次。成员主页不接受工单详情请求，不执行月度额度重置，也不扩展其他客户／工单／照片写入权限。普通老师、门店及原总部入口保留原权限。先完整备份并执行、验收 091，再联动部署 faceRecognition v145 与 staffAccount v107，最后更新客户端。本源码包不代表已经部署。


`v138` 修复提交结果恢复的只读 SQL：体验额度使用记录以真实主键 `verification_id` 关联，不再读取不存在的 `usage.id`。补录恢复继续按原账号、门店、幂等编号及 SUPPLEMENT 类型核对原单，待审／驳回／通过状态均只回读，不再次提交、不清除不确定锁；正常核销仍须设备信号完整，体验核销还须真实额度使用记录。无 SQL 迁移，不改创建、审核、扣次、人脸或 BLE。实际部署与验收状态以仓库独立发布回执为准。

`v137` 将老师日常考勤改为定位确认＋前置摄像头现场拍照，不调用 DetectFace、DetectLiveFaceAccurate、VerifyFace，不要求人脸档案。迁移 090 与 faceRecognition v137／staffAccount v98 已在 2026-11-01 部署验收；新记录由服务端固定标为 PHOTO，四项人脸审计为 NULL。保留原图、水印、私有上传／回读、同日上下班顺序、幂等和历史记录。客户建档、正常／体验核销、BLE、扣次、审核以及老师创建／重新录入不变。历史首次升级顺序见 `database/cloudbase-console/090-README.md`。

`v136` 只修正两处已通过补录的只读统计分类：老师客户列表的核销次数同时累加 NORMAL 与 SUPPLEMENT，活跃／封存分页共用同一口径；未核销天数预警把 SUPPLEMENT 起点公开归为 NORMAL，使正常起点人数、中文标签及导出一致。保留原提交时间起点、优先级、角色／老师归属、分页和单 SQL 快照，不执行数据回填或迁移。补录创建、审核状态机、余额、扣次、人脸、BLE、照片及评价均不改变。此版本只更新 faceRecognition；先核验运行时及下载代码，再确认客户端读数。部署包为 `faceRecognition-v136.zip`。

`v135` 新增总部专用只读 `getHqTeacherWorkspace`：先按当前认证 UID 复核总部身份，再从老师主档解析目标；复用老师本人的有效业务归属、四类统计和分页读取，不切换为老师会话、不新增写入权限，也不执行额度月度重置。老师原 `getTeacherWorkspace` 路由仍只按本人身份读取，忽略客户端指定的老师身份。新接口不接受工单详情编号，工单链接继续走既有总部详情入口。小程序老师详情新增“老师主页”页签，先部署并核验本函数，再上传依赖新 action 的客户端。无 SQL、运行时或环境变量变更；不改核销创建、人脸、BLE、照片、扣次或审核决策。

当前联动部署矩阵：`faceRecognition v145`、`verificationPhoto v14`、
`staffAccount v107`、`teacherCreate v9`、`customerRating v10`。迁移 075—086
验收通过后再部署这些当前版本；下文出现的旧版本号只用于历史发布记录，不能作为
本次上传包名称或运行时验收依据。当前照片打卡还必须先验收 088、089、090；完整顺序以 090-README 为准。

`v134` 仅为两个只读客户列表增加可选的 `customerPageSize`（1—100，旧客户端缺省仍为 20），当前客户端显式请求每页 10 条；不改变客户归属、计数、排序、权限或任何核销写入、人脸、BLE、照片与审核动作。从已验收 v133 升级只更新代码，无 SQL、运行时或环境变量变更。先部署并核验本函数，再上传依赖十条客户分页的新客户端。

`v133` 只把照片里的“上班打卡／下班打卡”改为原始标签字号的两倍，日期时间保持 v132 的三倍，“北京时间”保持原字号并与打卡类型同一基线。完整水印继续做边界保护；不改采集、编码、字节上限、原图读取、人脸、核销或 BLE。现网 v132 及迁移 089 已完成验收，从 v132 升级本版本只更新云函数代码，不重跑 SQL、不重新上传小程序、不改运行时或环境变量。旧照片不可变，不回填、不覆盖。

`v132` 取代未部署的 v131 草案，已在生产验收。取消考勤独有的 1280px／512 KiB 降清循环：复用核销的前置摄像头原图采集及 3 MiB 原图边界，保留拍摄像素，只在服务器按同一验证通过的图添加权威时间水印并一次高清 JPEG 编码（质量 92、4:4:4）；超过上限明确拒绝重拍，不静默缩小或循环降低质量。右下角日期时间为原始字号的三倍并适度加粗，小尺寸照片只在完整日期会越界时限制字号。v132 当时未放大打卡类型，该字号现由 v133 的两倍规则取代；北京时间标签不变。保留一张私有水印原图，不新增独立缩略图文件；考勤首屏签名固定读取存储原图，不加 480px 变换、不等待点击才切原图。客户端保留授权与完整字节缓存校验。旧 v131“两倍时间／480px 首屏”设计明确退役；既有核销照片缩略图不受影响。初次从旧版升级高清管线时先更新兼容客户端、完整备份并验收 089，再更新函数；当前从 v132 升级不重复该迁移。

`v130` 显式安装 Linux x64 sharp 0.34.5 二进制和 libvips，不上传 Mac node_modules。现网 Nodejs18.15 的合成探针及真实照片已验证可用；2026-10-15 用户决定暂不重建、不停服，原“必须先重建为 Nodejs20.19”的部署前置要求退役。依赖声明仍要求 Node >=20.19.0，其与现网版本的长期兼容性另行评估，不把实测成功误称为满足声明支持。部署后调用 `health` 并带 `attendancePhotoProbe: true`，核实实际版本、Linux x64 和 `attendancePhotoRuntime.ready: true`；该自检不写数据库、存储、人脸或真实打卡。共享核销照片模式不加载该探针；不得为本次时间水印调整重建或删除函数。

`v130` 新增迁移 088 的打卡照片留存。原图通过既有质量／活体／老师本人 1:1 检测后，独立 sharp 管线完整等比压缩到最长边 1280、最多 512 KiB，在右下角烘焙上班／下班类型及同一数据库时刻的北京时间。需明确留存同意；私有上传并回读校验字节／SHA-256 后才能绑定不可变打卡，空写入返回需独立回读，不确定时不得清理可能已绑定照片。getAttendancePhoto 按 UID 只准总部或在职本人读取，历史无照片返回 null；短时缩略图及单张原图／鉴权字节回退复用既有工单存储。核销照片专用函数、客户人脸、BLE 与扣次不变。先备份并依次执行 088 两个控制台 SQL，再部署当前 ZIP，由平台为 Linux Node.js 20 安装 sharp 0.34.5 及 optional dependencies，禁止打包 Mac node_modules。旧客户端缺留存同意时拒绝新打卡并提示更新。

`v128` 配合迁移 083，把核销完成后的三个补充照片位从单张 `3 MiB` 提升到
`5 MiB`。该上限只用于签名直传和服务端对象回读；现场人脸证据及旧版同步云函数
兼容通道继续保持 `3 MiB`，避免超过 6 MB 同步事件限制。数据库仍校验真实对象
字节、JPEG 文件头、尺寸和 SHA-256，正常／体验／补录核销、人脸、BLE、余额和
原子扣次均不改变。

`v127` 为业务老师列表和老师本人工作台补充来自员工账号的登录手机号。客户端继续提交不可变 `teacherId`，新增手机号只用于把可见身份从容易误认的老师短编号改成“姓名＋电话”，不参与权限、老师归属、正常／体验／补录核销、余额或 BLE 判断。`v126` 为老师考勤增加服务端逆地址解析。老师取得经纬度后先由服务端自动匹配
附近真实 POI／建筑／门店或道路，并签发只绑定当前老师和坐标、五分钟有效的短时
位置令牌；打卡入库只接受该签名地址，客户端不能篡改文字。中国大陆优先读取
`TENCENT_MAP_KEY` 对应的腾讯位置服务，境外优先读取
`HERE_GEOCODING_API_KEY` 对应的 HERE 服务，单一服务失败会尝试已配置的另一项。
地点文字只用于展示，真实经纬度、定位精度和地图仍是权威依据；地址服务未配置或
暂时失败不得阻断打卡。部署前必须执行并验收迁移 081。

`v125` 恢复门店／老师补录核销申请。它只通过迁移 079 的专用数据库函数创建
`SUPPLEMENT/PENDING` 工单，不读取客户现场人脸、不创建核销照片、不建立 BLE
资格、不签发设备授权，也不写设备信号；总部审核通过时继续由数据库原子余额
约束重新锁定客户并按正常核销扣次。查询、统计和老师归属把已通过补录并入正常
核销，但正常／体验核销既有的人脸、90 秒资格、设备工作态和最终写入路径不变。

`v124` 将老师考勤升级为同一上海业务日各一笔上班和下班打卡。客户端明确传入
`CLOCK_IN`／`CLOCK_OUT`，服务端按“账号＋日期＋类型”分别幂等；下班打卡在
照片处理前和数据库写入时都会再次确认同日上班记录已经存在。两类打卡都继续执行
照片质量、活体和考勤档案 1:1 验证，只保存服务端时间、位置与审计分数，不保存
现场照片。部署前必须执行并验收迁移 078；既有记录由迁移保留为上班打卡。

`v123` 新增老师考勤打卡。只允许当前活跃老师账号调用
`clockInTeacherAttendance`；服务端读取迁移 075 中总部预先录入的考勤专用
人脸档案，对当次前置摄像头照片执行质量检查、按环境配置执行活体检测并进行
1:1 `VerifyFace`。验证通过后仅保存服务端时间、上海日期、经纬度、定位精度、
设备平台和人脸审计分数；当次打卡照片不上传、不写数据库。每天每位老师最多
一条不可变记录，重复请求回读同一条结果。该考勤面容与登录、客户业务、正常
核销、体验核销完全隔离。部署本版本前必须先执行并验收迁移 075。

`v122` 增加迁移 072 的 BLE 授权前次数预留。每次生成签名、授权令牌和 `auth` 指令之前，数据库按正常核销的“客户+项目”或体验核销的“老师+项目”加事务锁，扣除其他仍有效资格已预留的次数并重新核对实时余额／额度；不足时直接拒绝签发。同一资格重复扫描同一设备复用同一份预留，不会重复占用；两笔并发资格不能共同超出余额。设备返回工作状态 `2` 后仍调用原有数据库原子写入函数完成第二次校验和真实扣次。必须先执行并验收迁移 072，再部署本版本。

`v121` 修复同一页面快速触发两次授权时的并发竞争。对已有授权的同设备重签改为按旧 `authorization_token` 做原子比较后更新，只有一个请求可以成功旋转 token；首次签发遇到资格唯一键冲突时直接返回 `BLE_AUTHORIZATION_RACE`，不再递归重新进入签发流程。配套小程序在第一次异步资格检查前同步上锁，并把 BLE 下行恢复为固定 20 字节顺序分片；`auth` 写入失败不会切换写入方式重发。本版本不需要数据库迁移。

`v120` 允许同一张仍有效的 90 秒人脸资格反复关闭并重新打开扫码窗口。同一资格再次扫描同一个二维码和同一台设备、且设备本轮实时返回待机 `status=1` 时，服务端依据本轮 nonce 在同一授权审计行中生成新 authorization token、到期时间和凯撒签名，旧 token 立即失效。二维码、设备编号、设备类型或次数任一不一致都拒绝，当前账号存在另一份未结束授权时也拒绝新设备；`DEVICE_WORKING` 只能恢复原工单，不能重签。设备状态 `2` 仍只允许生成一张工单和一次原子扣次。本版本不需要数据库迁移。

`v119` 曾要求活跃 `ISSUED` 授权只能向原设备返回完全相同的 token、nonce、到期时间和签名。该限制已由 v120 的“同设备实时待机可覆盖重签、旧 token 立即失效”规则取代；禁止换设备和只完成一张工单的边界不变。

`v118` 按设备端确认的凯撒规则生成 `auth.signature`：把 32 位十六进制 `nonce` 统一为小写；对从 0 开始的字符位置 `index` 使用偏移量 `(4 × (index + 1)) mod 7`；数字在 `0—9` 内循环，小写字母在 `a—z` 内循环。固定验收样例 `00112233445566778899aabbccddeeff` 必须得到 `41638537597196183052aecgeigdifkh`。本版本不再读取 `BLE_AUTH_SIGNING_KEY`。迁移 071 同时取消 `device_id + nonce` 的跨核销全局唯一约束，允许简单设备在不同资格中重复同一个随机码；每个资格、授权令牌、最终工单和扣次事务仍保持唯一／幂等。设备固件、迁移 071 与 v118 必须协调切换。

`v117` 把一张核销工单最多五张缩略图的私有地址签名从 2 路、最多 3 轮改为 5 路单轮并发；底层照片可靠性层仍把全局签名并发限制为 6，并保留瞬时存储错误的有界重试。原图仍只在用户点击、保存或导出时按权限签发，不会为了首屏速度提前读取高清照片。该版本当时继续使用 `v116` 的固定生产 Key BLE 协议；该协议已被 v118 明确取代。

`v116` 曾把 `auth.signature` 设为云函数环境变量 `BLE_AUTH_SIGNING_KEY` 的原值。该固定 Key 协议仅用于 v116—v117，已由 v118 的 nonce 凯撒签名规则取代，不得继续作为当前设备实现依据。

`v115` 修复 BLE 设备进入工作态后的服务端确认查询：不再把 PostgreSQL 保留关键字 `authorization` 用作表别名，避免 `SQLSTATE 42601` 使已进入工作态的授权无法继续完成原子核销。资格、一次性授权、随机数、次数和设备协议均未改变，也不需要新增数据库迁移。

`v114` 接入魔法柔肤厂家确认的设备身份格式：项目固定映射为 `device_type=LASER-BLE`，二维码和实时设备信息接受 `device_id=LA` 加 12 位大写十六进制，BLE 广播名固定为 `LA-` 加设备编号末 6 位。服务端签名使用项目映射后的规范类型；旧 `NCM` 编号和其他项目原有拼音类型继续兼容。生产数据库必须先执行迁移 069。

`v113` 把活跃预警、余次预警各自的汇总与两类首屏合并为一条 PostgreSQL 语句，避免并发充值、核销时跨请求出现重复、漏项或分类冲突；最多 1000 条的完整 PDF／Excel 导出也由一次 `exportAll` 查询返回同一快照，不再由客户端跨页拼接。旧客户端的 `ALL`／`ZERO`／`NONZERO` 分页接口继续兼容，当前客户端首屏使用 `BOTH`。

`v112` 将运营预警的结果口径固化为两组。活跃预警仍以客户为唯一结果对象，在固定的正常核销 → 体验核销 → 客户建档阶梯和手填间隔之外，再按权威项目余额区分“全部项目为 0”与“任意项目非 0”；没有余额行视同全部项目为 0。余次预警仍以真实客户×项目卡项为结果对象，在严格低于阈值的已开卡余额中区分“项目余次为 0”与“非 0 且低于阈值”。两项查询均只统计 `customer_status='ACTIVE'` 的未封存客户，分类各自稳定分页，并继续兼容未传分类的旧客户端全量查询。

`v111` 把独立照片服务的补充照片写入改为数据库任务绑定的一次性签名 PUT：照片字节由网页／小程序直达私有存储，函数提交阶段只读取同一对象、校验真实字节与 JPEG 元数据并原子绑定。独立服务不再接受 Base64 照片事件；签名失败会精确取消本次任务，不遗留进行中锁。CloudBase Manager 5.6.4 返回的相对上传路由只会在服务端补全为当前环境的 `api.tcloudbasegateway.com` HTTPS 地址，并同时校验精确桶和对象路径，不能被改写到其他主机或对象。主函数暂时保留旧客户端的窄范围兼容回退，但当前生产照片服务和客户端固定使用 `DIRECT`。

`v110` 为总部与门店增加两个只读客户提醒接口。`queryInactiveVerificationCustomers` 永久排除封存客户，按“任意正常核销优先 → 没有正常时才用体验核销 → 两类都没有时用客户建档”的固定阶梯和手填上海自然日查询；`queryLowBalanceCustomers` 直接读取 `customer_product_balances` 权威余额，只统计已经开卡的活跃项目，支持单个／全部项目和手填严格小于阈值。总部可以选择全部或指定门店，门店始终锁定本店，老师无权调用；两者均稳定游标分页且不需要新增数据库结构。

`v109` 修复门店全局视图加载失败：门店客户状态查询改为仅接受 `ACTIVE`／`ARCHIVED` 的白名单 SQL helper，移除对不存在的 `sqlLiteral` 的调用；其余业务接口、权限与统计口径保持不变。

`v108` 同时修复大数据量下的充值／退费查询：汇总和计数先在业务表上完成，只有姓名／生日精确查询才联接客户表；明细先按条件排序、分页，再只为当前页联接客户、门店、项目和老师。门店业务明细、活跃／封存客户、老师客户与工作台列表也统一先计数再取当前页，页码超出时自动夹取并重读最后有效页，避免重复提交、空白页和前端错乱。历史工单按工单自己的办理门店查询，不再错误要求它等于客户最初建档门店。压力数据环境必须先执行 067 的四个游标索引，再部署本版本。

v108 与 `verificationPhoto v14` 共享同一份经过权限校验的照片服务实现，但由启动模式限制可调用动作。`faceRecognition` 保留人脸 SDK 和人脸／业务动作；`verificationPhoto` 的部署包不安装腾讯人脸 SDK，也拒绝所有人脸、客户、充值和建单动作。部署和环境变量详见 `../verificationPhoto/README.md`。

v108 修正门店与老师核销时偶发无法选择客户的问题：活跃客户第一页读到后即可选择，后续分页只追加和去重，不得清空已经选中的客户；后续页失败时保留已读客户并允许重试。BLE 资格在设备授权真正签发前属于可放弃状态，允许重新选择门店和客户；只有仍有效的 `ISSUED` 或 `DEVICE_WORKING` 设备授权才锁定原客户和设备。失败、过期或仅完成人脸但尚未签发设备授权的记录不得隐藏客户选择器，90 秒有效期一律以数据库时间为准。

v108 在 PostgreSQL 查询结果离开云函数前统一规范化 `*_at`、`*_time` 与 `*_date` 字段，并把门店可办理的充值、退费、正常核销和独立产品购买统一为“业务老师可选”。门店留空时工单不归属老师；主动选择时，服务端必须验证老师主档和登录账号均为活跃后才写入归属。老师账号办理上述业务时仍由服务端强制绑定当前老师本人，不能改选其他老师；体验核销仍只允许老师本人办理，门店始终禁止。

v108 同时修正客户主页的历史统计口径：客户抬头和逐项目“累计充值”只汇总审核通过的 `NEW` 充值原始次数，审核通过的 `REFUND` 作为“累计退费”单独返回；退费不会倒减历史累计充值。逐项目“剩余”仍读取 `customer_product_balances.remaining_count` 的净余额，退费额度与余额风控也继续使用数据库净口径，不能用历史累计充值放宽可退额度。总部工作台原有充值／退费事件分列保持不变。

v108 修复 BLE 资格写入后直接读取空结果导致的 `verification_id` TypeError：服务端现在先按幂等键写入，再按同一幂等键回查资格；未读到完整资格时返回受控错误且不扣次。v120 延续 v118 的凯撒签名且不要求 `BLE_AUTH_SIGNING_KEY`；小程序仍只显示简短中文反馈，不显示底层 SQL、TypeError 或堆栈。

v108 最终取消设备注册表依赖。数据库只保留 `verification_ble_qualifications` 与 `verification_ble_authorizations` 两张短时资格／授权审计表；云函数不再查询设备主档、数据库设备白名单、预登记状态或配对码哈希。v118 起设备身份由二维码序列号、实时 BLE `get_info` 返回值、32 位 nonce、90／30 秒窗口和 nonce 凯撒签名共同校验；v120 允许在原90秒资格内对同一台待机设备覆盖重签，并使旧 token 失效。设备可以跨核销重复 nonce，但同一资格仍只能完成一张工单和一次扣次。更早版本的 HMAC-SHA256 与固定生产 Key 规则均已退役。

## 必需环境变量

- `FACE_SECRET_ID`
- `FACE_SECRET_KEY`
- `FACE_GROUP_ID=lusizhuoerdatabase`
- `CLOUDBASE_ENV_ID=rusizhuoer-d9gbcsgym07651694`：必须与 PostgreSQL 实例、PG 云存储桶和下面的 service role key 属于同一个 CloudBase 环境；运行平台已可靠注入同值 `TCB_ENV` 时可由它替代。
- `CLOUDBASE_APIKEY`：平台托管的 CloudBase PG 云存储 service-role API Key，只能保存在云函数环境变量中。代码仍兼容旧变量 `CLOUDBASE_SERVICE_ROLE_KEY`；两者同时存在时优先使用 `CLOUDBASE_APIKEY`。

v122 不需要 `BLE_AUTH_SIGNING_KEY`。部署前可从 `faceRecognition` 环境变量中删除该旧变量；保留它也不会被代码读取。二维码六位码只作现场会话字段，不参与凯撒签名。

不要把腾讯云密钥写入前端 JavaScript、README 或 GitHub。

`faceRecognition` 与 `verificationPhoto` 必须在各自函数的环境变量页面分开配置；每个变量名称和值各占一行／一个输入项。不要把整段 `KEY=value` 文本、其他变量名、引号或换行一起粘进某一个变量值。两个函数使用同一个安全随机、至少 32 位的 `VERIFICATION_PHOTO_CLEANUP_TOKEN`，但该值只存在环境变量中，不写进 triggers-only 配置。

## 老师与门店工作台（v108）

新建老师只调用独立的 `teacherCreate v9/createTeacher`，该函数同步创建账号、老师
主档和考勤专用人脸档案。`faceRecognition v145` 不接受老师创建，
补录、替换、回读、回滚或最终清理委托，也不读取迁移 051 的老师人脸操作租约。

v108 允许门店和老师办理正常核销，体验核销只允许老师账号。正常核销和体验核销都要求办理人员明确选择 1—999 次，次数进入幂等匹配；数据库按同一次数原子校验并扣减客户余额或老师体验额度，设备信号只读取数据库确认后的次数。两类核销都调用同一个 `verifyCustomerFace` 与 `persistVerifiedFaceEvidence`，现场只对所选客户的 `PersonId` 做 1:1 比对。门店充值、退费、正常核销和独立产品购买的业务老师全部可选；留空时不写老师归属，选择时必须是一位主档及登录账号均活跃的真实老师。老师账号的充值、退费、正常核销、体验核销和独立产品购买都由服务端自动绑定本人并拒绝改绑。有效 `teacher_id` 是老师统计、老师客户关系和历史业务老师显示的归属依据；门店提交时老师不必是提交账号，老师账号提交时则必须与该 `teacher_id` 为同一人，总部和退役角色的旧字段不构成归属。

v99 将门店和老师所有办理页共用的活跃客户精确查询统一为“姓名或生日至少一项”：只传姓名时按姓名精确匹配，只传生日时按生日精确匹配，两项都传时同时匹配。查询范围仍由当前 UID 和已确认门店锁定为活跃客户；匹配结果继续使用稳定游标分页，客户端必须读完并在多位结果中按客户编号明确选择。两项都不传仍表示全量活跃客户下拉框读取，不会扩大账号门店权限。

v99 的充值流程支持第三步可选产品赠予：只读取迁移 060 中当前为 `ACTIVE` 的独立产品，按“选择产品 → 1—999 数量 → 点＋加入”形成最多 20 种且不重复的清单；退费拒绝赠品。迁移 061 让充值主记录与赠品明细在同一条数据库语句中原子写入，明细固定绑定父单的门店、客户和业务老师，并固化产品编号、名称与数量。赠品写入后不可修改或删除，也不改变库存、客户项目余额、核销、体验额度或统计。

v108 延续迁移 062 的独立产品购买提交并应用迁移 065 的老师归属规则：门店账号自动锁定本店，业务老师可留空或选择一位真实活跃老师；老师账号在业务页选择活跃门店并自动绑定本人。两者都从激活 `retail_products` 选择产品、填写 1—999 件数量，不采集人脸。购买单以 `PRODUCT_PURCHASE` 独立防重恢复，总部不能调用提交动作。客户主页三列产品汇总只累计审核通过的购买件数和父充值已通过的赠品件数。

v99 的客户主页历史接口提供五个独立查询范围：`RECHARGE` 只返回 `recharge_type=NEW`，`REFUND` 只返回 `recharge_type=REFUND`，`VERIFICATION`、`EXPERIENCE` 与 `PRODUCT_PURCHASE` 分别返回正常核销、体验核销和产品购买工单；五类各自返回独立稳定游标。网页与小程序不能把不同业务混入同一批记录后只依赖前端改标签。

v99 的 `recoverBusinessSubmission` 仅允许原提交账号、原门店按同一 `clientRequestId`
恢复充值、退费、产品购买、正常核销或体验核销结果。网页在调用结果丢失时会持久化锁定该请求，先查询
数据库中的既有工单；未知状态下不会生成新编号或再次扣次。前端只持久化不含明文客户资料、留言或人脸令牌的请求指纹；成功锁要等对应详情页真实加载并核对同一请求编号后才清除。部署 v108 前必须先执行迁移 058、063、064、065、066 和 067，
恢复当前业务规则对应的状态机与不可变审计字段触发器。

老师工作台的 `getTeacherWorkspace` 提供四类有效业务视图（核销、充值、体验、退费）、上海业务日期范围、按项目汇总矩阵，以及当前老师所有活跃项目的体验剩余次数。`getTeacherBusinessCustomers` 按“本人账号创建，或本人被有效 `teacher_id` 归属的已通过 `NORMAL`／`SUPPLEMENT`／`EXPERIENCE`／`NEW`／`REFUND` 业务”建立客户关系，并分别分页返回活跃用户与封存用户；列表充值次数只累计 `NEW`，核销次数累计 `NORMAL` 与审核通过的 `SUPPLEMENT`。老师业务列表和统计按工单 `teacher_id` 归属，因此门店选择该老师办理的有效业务也计入；门店来源接受充值、退费、正常核销和审核通过的补录核销，老师来源接受提交账号本人办理的充值、退费、正常核销、审核通过的补录核销和体验核销。历史总部、已退役 `operation`、老师身份不匹配或门店体验不会进入老师统计、客户关系、直接照片读取或历史老师显示，但原工单仍保留在总量与审计历史中。迁移 057 为新客户保存实际 `created_by_account_id`；门店账号创建的客户记录门店账号，不会直接绑定老师。取得客户关系后，老师可以读取客户主页、私有建档照、备注、留言，以及该客户由任何老师或门店提交的充值、退费、正常核销、审核通过的补录核销和体验核销详情；`submitted_by_account_id` 仍是改单、补充照片、作废、撤销和提交恢复的唯一写权限依据，被选择为业务老师不获得他人提交工单的写权限。老师仍不能访问无关客户或修改客户状态。门店主页按客户 `created_store_id` 分别分页返回活跃与封存用户。老师与门店都把业务明细紧接在汇总下方，顶部日期按钮同时控制汇总和四类明细；明细使用服务端页码分页，响应包含 `total`、`page`、`pageSize` 和 `totalPages`，并保留上一页、下一页和直接跳页。`queryStoreBusinessRecords` 仍兼容旧查询页的游标方式，但页码与游标不能混用。门店业务办理区不显示体验入口，服务端也拒绝门店创建体验；老师在该门店完成的历史体验只作为审计数据保留在汇总与客户历史。门店业务区与老师业务区共用响应式版式，但不显示老师体验额度卡。门店全历史查询必须显式提交 `allTime=true`，避免缺省日期被误解为全历史；自定义范围仍最多 366 天。列表和汇总只统计 `APPROVED` 记录；账号身份、时间范围和分页参数均由服务端校验。迁移 055 同时移除订单触发器和核销主体锁中的旧老师人脸门禁；迁移 056 消除体验额度列歧义；迁移 057 增加可空的客户创建账号外键和索引，历史客户不猜测回填。正常核销和体验核销仍要求有效客户档案照及现场 1:1 人脸验证；迁移 079 的补录申请不读取现场人脸或照片。

老师不再采集人脸。新体验单固定保存客户建档照和客户现场照；历史老师人脸体验单
继续按真实 `face_subject_type=TEACHER` 只读展示，不会伪改照片主体。

迁移 054 建立老师账号赠送、客户人脸验证的体验核销原子入口；迁移 059 首次固化老师归属矩阵，迁移 065 最终取代其中“门店正常核销老师必选”的旧规则，统一门店充值、退费、正常核销和独立产品购买老师可选，同时继续保留门店体验拒绝及老师账号只能绑定本人的边界。体验事务消费当前登录老师的体验额度、绑定客户两张人脸照片并写入设备开启信号，不读取或扣减客户购买余额。

体验办理页面只允许老师账号使用 `getTeacherExperienceEntitlements({ teacherId, storeId })`；服务端只返回当前登录老师本人额度并拒绝改绑。调用者、门店、老师、产品及产品额度配置都必须活跃；每项还返回不受月初重置影响的 `totalExperienceCount`，该累计值只统计来源可信、已通过且由该老师本人提交的体验核销。历史异常用量仍保留在实际额度余额和不可变用量流水中供审计，但不计入业务累计。封存主档或已删除的额度配置不能出现在新业务选择中，但历史工单和统计仍按事件保留。

## 推荐环境变量

- `FACE_QUALITY_THRESHOLD=70`：建档照片质量最低分。
- `FACE_VERIFY_THRESHOLD=60`：已选客户 1:1 核销最低相似度；同时要求腾讯云 `IsMatch=true`。
- `FACE_MAX_YAW=20`
- `FACE_MAX_PITCH=20`
- `FACE_MAX_ROLL=15`
- `FACE_LIVENESS_ENABLED=false`：未开通高精度静态活体服务前保持 `false`；开通后改为 `true`。
- `FACE_LIVENESS_THRESHOLD=40`：腾讯云高精度静态活体推荐阈值。
- `CUSTOMER_PHOTO_BUCKET_ID=customer-photos`
- `CUSTOMER_PHOTO_URL_TTL_SECONDS=120`：核销／充值选择客户时，私有照片临时地址的有效秒数；允许 30--600 秒。
- `VERIFICATION_PHOTO_BUCKET_ID=verification-photos`：可选的核销证据专用私有 PG 存储桶。也可以与 `CUSTOMER_PHOTO_BUCKET_ID` 一样都配置为现有的 `customer-photos`；v99 会去重候选桶，并在写入照片前查询当前 PostgreSQL 环境的 `storage.buckets`，只选择确实存在的桶 ID。两个云函数必须配置相同值。
- `VERIFICATION_PHOTO_URL_TTL_SECONDS=900`：核销缩略图和按需原图的签名地址有效秒数；允许 60--900 秒。默认 15 分钟以复用浏览器私有缓存，地址仍会过期且不会写入持久存储。
- `VERIFICATION_PHOTO_UPLOAD_TTL_SECONDS=600`：一次补充照片上传任务在业务层的有效秒数；允许 120--900 秒。到期后数据库拒绝提交并释放该核销单的单任务锁。取消／过期对象要等创建满安全等待期后再做最终清理。
- `VERIFICATION_FACE_EVIDENCE_TTL_MINUTES=30`：人脸比对通过后、正式提交核销单前的照片草稿有效分钟；允许 5--120 分钟。
- `VERIFICATION_PHOTO_CLEANUP_TOKEN`：至少 32 位随机清理凭证，只放云函数环境变量；仅供控制台／管理端手工补跑，不写入定时触发器配置。
- `TENCENT_MAP_KEY`：老师考勤在中国大陆坐标的服务端逆地址解析 Key；用于自动返回附近真实 POI／建筑／门店或道路。只放云函数环境变量，不得写入小程序。
- `HERE_GEOCODING_API_KEY`：老师考勤在堪培拉等境外坐标的服务端逆地址解析 Key；用于自动返回附近地点／道路和完整地址。只放云函数环境变量，不得写入小程序。两项地址服务都不可用时仍保存权威坐标并允许打卡。

## 拍摄和质量要求

- 核销人脸凭证保存为 JPEG 3:4 竖图，最长边优先保留到 1920 px、质量系数 0.92；仅在超过 3 MB 时逐级缩小。另生成最长边 480 px、最多 384 KB 的独立缩略图。原图和缩略图的 Base64 合计稳定低于云函数 6 MB 同步事件上限，详情页不会为了列表预览下载原图。
- 图片只能有一张人脸，人脸宽和高均至少 100 px。
- 不允许口罩、闭眼、明显低头、歪头或侧脸。
- 后端会再次执行质量检测，不能依赖前端结果。
- `CreatePerson` 使用算法模型 3.0、`QualityControl=3`、`UniquePersonControl=0`。
- 同一自然人可以建立多个独立客户档案；每次建档都会生成不同的客户编号和腾讯人脸 `PersonId`。系统不会按人脸、姓名或生日阻止重复建档。
- 页面为每次明确的新建档操作生成 `clientRequestId`；同一次提交因网络超时而重试时返回原客户档案，不会误建第二条。重新拍照或修改资料后再次提交会生成新的客户编号。
- 核销必须先选中具体客户编号，再使用该档案绑定的 `PersonId` 做 1:1 人脸验证，因此多个档案不会在核销时互相替代。
- 已经选择客户的核销只调用 `VerifyFace`，现场照片只与数据库中该客户的 `PersonId` 做 1:1 比对，不搜索其他客户。
- 人脸比对通过后，现场原图和缩略图立即写入私有核销照片桶并生成短时证据令牌；正式建单时数据库在同一个事务中消费令牌并把不可修改的人脸照片绑定到核销单。上传或绑定失败时不得建单。
- 系统不提供 `SearchPersons` 或其他 1:N 查人入口。必须先按业务编号选定客户或老师，再用该档案在数据库中绑定的 `PersonId` 调用 `VerifyFace` 做 1:1 比对。

## 云存储

- PG 存储桶：`customer-photos`
- 访问权限：私有
- 单文件限制：5 MB
- MIME 白名单：`image/jpeg`
- 对象路径：`<storeId>/<customerCode>/<timestamp>.jpg`

该桶不为 `anon` 或 `authenticated` 创建任何 RLS Policy，客户端访问默认拒绝；控制台因此显示“未配置 RLS、API 访问将被拒绝”属于预期状态。官方 `service_role` 具备 `BYPASSRLS`，只有配置同环境服务端 API Key 的云函数可以读写。不要为消除控制台提示把照片桶公开或给网页账号增加整桶权限。数据库保存 `pg://<bucketId>/<objectName>` 私有引用，不保存公开下载地址。

可以另建 PG 存储桶 `verification-photos` 以便分开管理和保留策略，但不是必需条件。v99 与 `verificationPhoto v14` 按 `VERIFICATION_PHOTO_BUCKET_ID`、`CUSTOMER_PHOTO_BUCKET_ID` 的顺序对候选桶去重，并在写入前用 `storage.buckets.id` 预检当前数据库环境中实际存在的桶；两个环境变量都填写 `customer-photos` 时只检查、使用这一个桶。如果候选桶都不存在，服务端直接返回 `PHOTO_BUCKET_NOT_FOUND`：

- 访问权限：私有；不要给 `anon` 或 `authenticated` 添加 SELECT/INSERT/UPDATE/DELETE Policy。
- 单文件限制：5 MB；MIME 白名单仅 `image/jpeg`。
- CORS：当前补充照片通过 `verificationPhoto` 云函数传输，不再要求浏览器 `PUT` CORS。保留正式静态站点所需的受限读取配置即可；不要使用 `*` 来源，也不要开放浏览器列桶、删除或覆盖权限。桶仍保持私有且不给 `anon`／`authenticated` 建 Policy。
- 对象路径：人脸凭证使用 `face-evidence/<store>/<staff>/<token>/...`，新版补充照片使用 `records/<verificationId>/slot-<n>/direct-<timestamp>-<server nonce>.jpg`；路径全部由云函数随机生成，浏览器输入不会进入路径，每次替换都使用新对象名且签名禁止覆盖。
- 每单固定展示 2 张人脸照片和 3 个补充照片位。迁移 054 后，正常核销与新体验核销的前两张都是客户登记照和客户现场照；迁移 049 至 053 期间生成的历史老师脸体验单继续标记为 `TEACHER` 并如实展示，不会把旧照片伪装成客户。补充照片只保存一份高清 JPEG，提交时服务端验证实际字节数、MIME、JPEG 文件头、真实尺寸和 SHA-256；缩略图由 CloudBase 图片处理按需生成。
- 当前网页和小程序固定调用独立的 `verificationPhoto v14`，其响应为 `uploadMode=DIRECT`：数据库先建立／复用上传请求并锁定“每单一个进行中任务”，再签发任务随机私有对象的一次性 PUT 地址。客户端直接发送 JPEG 字节，提交函数只接收工单和任务编号，并从对象存储回读校验后原子绑定。独立服务拒绝 Base64 图片事件。
- `faceRecognition v145` 暂时保留旧客户端的 `DIRECT`／精确 `FUNCTION` 回退实现；当前生产前端不调用这组兼容照片动作。两个函数均不会接受客户端指定的桶或对象路径，独立服务签名失败时会取消精确任务而不转入函数字节中转。
- 原图和缩略图设置私有长期缓存；数据库从不保存签名 URL。详情首屏仅以最多 2 路并发准备 5 张缩略图，不提前签发 5 张高清原图；点击时才重新校验权限、写查看审计并取得该照片的短时原图地址。页面先显示缩略图，再无闪烁替换为高清图；同页重复查看可复用仍有效的私有地址，并把已解码原图限制为最多 2 张。
- 在本函数配置名为 `cleanup-verification-photo-drafts-hourly` 的每小时 Timer，只清除过期且未建单的人脸照片草稿。触发器使用 CloudBase `triggers` 配置，不携带 `action` 或清理凭证；v99 会严格验证平台保留的 `TRIGGER_SRC=timer`、函数名、事件类型、触发器名、时间和无终端用户 UID。取消／过期的迁移 039 补充照片任务由 `verificationPhoto` 的另一个 Timer 清理；两个触发器名不要互换。

## 部署

上传包文件名必须为 `faceRecognition-v145.zip`。把本目录中的 `index.js`、`teacher-team.js`、`teacher-customer-lookup.js`、`package.json`、`README.md`、`attendance-photo.js`、`attendance-glyphs.json` 和 `attendance-glyphs-LICENSE.txt` 放在 ZIP 根目录；不要再套一层目录。函数入口为 `index.main`，部署时安装 `package.json` 依赖。交付前必须回读 ZIP 根目录的 README 与运行时代码，确认两者均为 `v145`。

在 `faceRecognition` 的触发器配置编辑器中填写以下完整配置。CloudBase 只接受顶层 `triggers` 数组；不要在这里填写业务事件、`action` 或 `cleanupToken`：

```json
{
  "triggers": [
    {
      "name": "cleanup-verification-photo-drafts-hourly",
      "type": "timer",
      "config": "0 0 * * * * *"
    }
  ]
}
```

该七段 Cron 每小时整点运行。需要从控制台手工补跑时，使用 `{ "action":"cleanupVerificationPhotoDrafts", "cleanupToken":"与环境变量完全一致的真实值" }`；手工入口仍要求至少 32 位凭证且调用中没有终端用户 UID，不能由普通网页账号调用。

首次上线迁移 039 时必须安排一个短暂停写窗口，并严格按下列顺序部署，避免旧页面绕过单任务锁：

1. 在完整 PostgreSQL migration 工具中执行 `database/migrations/039_direct_verification_photo_upload.sql`；腾讯云 SQL 编辑器则依次单独执行 `039-01`、`039-02`、`039-03`、`039-04`、`039-05`。
2. 执行 `database/migrations/040_fix_verification_photo_commit_ambiguity.sql`；腾讯云 SQL 编辑器只需执行一次 `040-01-fix-verification-photo-commit-ambiguity.sql`。已经完成 039 的生产库不要重跑 039。
3. 完成 046、总部封锁旧运营凭据、047 和 048 后，依次执行 `049-01` 至 `049-13`，再运行 `049-readonly-verify.sql`，全部必须为 `READY`。049 是向前迁移，不要修改或重跑生产已执行的 048。
4. 执行迁移 050 的 7 段控制台 SQL并确认只读验收全部 `READY`，再按 053 指引退役旧老师人脸 Saga。当前 `faceRecognition v145` 不依赖迁移 051／052，也不需要老师人脸操作恢复 Timer。
5. 完整执行迁移 054（CloudBase SQL 编辑器使用 `054-01-teacher-only-customer-face-experience.sql`），把新体验核销切换为老师账号赠送、客户人脸凭证。
6. 将 `faceRecognition` 执行超时设为 **90 秒**；当前联动包为 `faceRecognition v145`、`verificationPhoto v14`、`staffAccount v107` 和 `teacherCreate v9`。`teacherCreate` 建议设为 **90 秒、至少 256 MB**，并配置与老师建档一致的人脸和私有照片桶变量。
7. 完整执行迁移 055 并确认 3 行全部 `READY`，移除充值、退费、核销和体验核销中的旧老师人脸门禁；再执行 `056-01-experience-quota-column-ambiguity.sql`，确认返回 `READY`。
8. 执行 `057-01-teacher-created-customer-access.sql`，确认字段、外键和索引 3 行全部为 `READY`。
9. 按 `058-README.md` 执行三段 SQL，确认只读验收两行全部为 `READY`。
10. 按 `059-README.md` 先执行只读预检，再执行写入文件和只读验收，确认业务老师矩阵全部为 `READY`。
11. 按 060 README 建立独立产品主档，再按 061、062 README 建立并验收充值赠品明细与独立产品购买。
12. 确认 063 的 8 行安全验收全部为 `READY`；短暂停止核销写入，执行 064。随后按 065 README 短暂停止充值、退费、核销和产品购买新建并执行 065；继续整文件执行 066。066 不登记设备，只建立短时资格和授权审计。最后在低峰期按 067 README 建立充值／退费查询索引并完成只读验收。
13. 执行并验收 068—083，配置至少 32 字节的 `CUSTOMER_RATING_SIGNING_KEY` 及实际 `rating.html` 地址 `CUSTOMER_RATING_BASE_URL`，准备 `customerRating-v10.zip`。如果旧版 066 曾建立第三张设备注册表，先执行 `066-02-retire-legacy-device-registry.sql`；设备固件切换到凯撒签名且迁移 072 预留验收通过后，再部署 `faceRecognition v145` 及同轮配套函数，分别调用 `health` 核对实际版本，最后发布当前客户端。

历史 v138／v98 首次启用组长的前置顺序：先完整备份并执行、验收 `database/cloudbase-console/091-README.md` 中的组长迁移，再原地部署 `deployments/staffAccount-v107.zip` 和 `deployments/faceRecognition-v145.zip`，分别确认 health 为 v107／v145，并回下载全部根文件逐一比对，最后发布配套客户端。091 不自动任命任何老师或改变既有人员／业务数据；不重复执行历史迁移，联动部署新增组长只读评价的 customerRating v10；不重新部署未变化的 verificationPhoto 或 teacherCreate，不重建函数，不改运行时或全局活体开关。首次从照片考勤之前版本升级的历史前置顺序仍见 `database/cloudbase-console/090-README.md`。

部署后测试：

```json
{ "action": "health" }
```

应返回：

```json
{
  "ok": true,
  "version": "v145",
  "photoBucketId": "customer-photos",
  "verificationPhotoBucketId": "verification-photos",
  "verificationPhotoFallbackBucketId": "customer-photos",
  "verificationPhotoUrlTtlSeconds": 900,
  "verificationPhotoUploadTtlSeconds": 600,
  "verificationPhotoCleanupConfigured": true,
  "verificationPhotoCleanupTimerTriggerName": "cleanup-verification-photo-drafts-hourly",
  "verificationPhotoServiceRoleKeyConfigured": true,
  "verificationPhotoBucketMetadataReady": true,
  "verificationPhotoServiceRoleStorageReady": true,
  "livenessEnabled": true
}
```

上例假设另建了 `verification-photos`。如果当前环境把 `VERIFICATION_PHOTO_BUCKET_ID` 与 `CUSTOMER_PHOTO_BUCKET_ID` 都配置为 `customer-photos`，健康检查中的 `photoBucketId`、`verificationPhotoBucketId` 和 `verificationPhotoFallbackBucketId` 都返回 `customer-photos` 才是正确结果。`health` 展示的是环境变量配置；部署前还必须在同一个 CloudBase 环境的 PostgreSQL SQL 编辑器执行以下只读检查，确认真实桶和迁移 039 都存在：

```sql
SELECT
  CURRENT_DATABASE() AS database_name,
  TO_REGCLASS('public.verification_photo_upload_requests') AS upload_request_table,
  EXISTS (
    SELECT 1
      FROM storage.buckets
     WHERE id = 'customer-photos'
  ) AS configured_bucket_exists;

SELECT id, name, public, file_size_limit, allowed_mime_types
  FROM storage.buckets
 WHERE id IN ('customer-photos')
 ORDER BY id;
```

对上述 `customer-photos` 配置，第一条应返回非空 `upload_request_table` 和 `configured_bucket_exists=true`，第二条应恰好返回一行 `customer-photos`，同时 `public=false`、`file_size_limit` 不少于 5242880（5 MB）、`allowed_mime_types` 为空或包含 `image/jpeg`。如果使用专用桶，把查询中的候选集合改为 `('verification-photos', 'customer-photos')`，并确认至少一个 ID 与两个云函数的环境变量逐字一致。SQL 不能核对云函数 API Key；还要确认 `CLOUDBASE_ENV_ID`、优先变量 `CLOUDBASE_APIKEY`（或兼容变量 `CLOUDBASE_SERVICE_ROLE_KEY`）和执行 SQL 的 PostgreSQL 实例都属于同一个 CloudBase 环境。两个 health 的 `verificationPhotoServiceRoleStorageReady=true` 会额外使用各自的服务端 Key 对真实桶执行只读 `listObjects`，可直接识别错环境、失效 Key 或权限异常；若为 `false`，查看同响应的错误码和请求 ID。

## 支持的动作

- `validateCapture`：拍照后立即检查单人、人脸尺寸、质量、口罩、闭眼和姿态。
- `registerCustomer`：服务端质量检查、可选活体检测，然后以新的唯一客户编号和 `PersonId` 入人员库、上传私有照片并写客户表。同一张脸、相同姓名或相同生日都允许建立新的独立客户档案。
- `getTeacherBusinessContext`：仅允许活跃老师账号调用，返回当前老师本人身份和可选择的活跃门店。老师必须先选择本次办理门店，后续每个业务动作都会由服务端重新校验老师身份与门店状态。
- `listActiveStoreCustomers`：门店账号按 UID 锁定自身门店；老师账号必须提交一个真实活跃门店 ID。只返回目标门店 `customer_status='ACTIVE'` 客户的编号、姓名和生日，不预取备注、状态或业务汇总。每批最多 100 位并按“姓名、生日、客户编号”稳定升序；响应在还有下一批时返回 `nextCursor={customerName,birthDate,customerCode}`，下一次请求把该对象原样放入 `cursor` 即可继续加载完整名单。旧请求不传 `cursor` 时仍从首批开始；`customerName` 与 `birthDate` 可单独传入精确匹配，也可同时传入取交集，游标必须与当前已传筛选字段一致且字段完整。
- `queryStoreCustomers`：总部与门店共用的真实客户查询。服务端先根据 CloudBase UID 验证活跃身份；总部可查看全部门店或选择一个真实门店，门店账号始终锁定到自身绑定门店，老师无权调用。结果使用 `(created_at,id)` 游标分页且每页最多 100 条，业务阶段、活跃／封存及总数均由数据库对完整筛选范围汇总。结果中的“核销次数”直接从已通过且 `verification_type='NORMAL'` 的正常核销重新汇总，不读取会同时包含体验的客户主档历史累计字段。
- `queryInactiveVerificationCustomers`：总部与门店共用的“活跃预警”查询，只读取 `customer_status='ACTIVE'` 的正常在档客户。总部可查全部或一个真实门店，门店始终锁定本店，老师无权调用。`minimumDays` 必须是 `1—3650` 的整数上海自然日；每位客户只要存在任意已完成正常核销就取最新 `NORMAL`，完全没有正常核销时才取最新 `EXPERIENCE`，两类都没有时取建档时间。充值、退费和产品购买不参与起点。`balanceCategory` 可为 `ZERO`、`NONZERO` 或兼容旧客户端的 `ALL`：只要权威余额表存在任意 `remaining_count <> 0` 的项目，该客户属于 `NONZERO`，否则属于 `ZERO`；没有余额行也属于 `ZERO`。分类各自按起点最早优先，以 `(baseline_at,customer_id)` 稳定分页，汇总同时返回两类客户数。
- `queryLowBalanceCustomers`：总部与门店共用的“余次预警”查询，只读取正常在档客户与当前活跃项目。`remainingBelow` 必须是 `1—999999` 的整数，可提交一个真实项目 ID 或留空表示全部项目。接口直接读取 `customer_product_balances`，要求 `total_recharge_count > 0` 且 `remaining_count < remainingBelow`；余额为 0 的已开卡项目会命中，从未开卡的项目不会被合成 0 次。结果对象固定为客户×项目卡项；`balanceCategory=ZERO` 只返回余次等于 0 的卡项，`NONZERO` 只返回余次不等于 0 且低于阈值的卡项，`ALL` 保持旧客户端兼容。两类各自按 `(remaining_count,customer_id,product_id)` 稳定分页，汇总同时返回两类卡项数。
- `queryStoreBusinessRecords`：总部与门店共用的充值／核销查询。总部可查看全部门店或选择一个真实门店；门店范围只来自服务端 UID 绑定，浏览器不能扩大权限，老师无权调用。支持按项目、原单状态、核销类型、提交日期或客户姓名＋生日查询；充值记录另返回作废申请状态，核销记录只显示原单审核状态。列表按 `(submitted_at,id)` 游标分页且每页最多 100 条，顶部统计由数据库对完整筛选范围汇总。部署前应依次完成迁移 `026`--`036`，并执行 `033_hq_query_indexes.sql` 支撑总部跨门店查询。
- `getStoreDashboard`：总部与门店共用的真实门店主页。门店账号始终按当前 CloudBase UID 锁定自身绑定门店；总部必须提交一个真实数字门店 ID，服务端验证门店存在后返回该门店基础资料、项目累计和分页客户数据。老师无权调用，浏览器传入的门店编号不能扩大门店账号权限。项目累计将体验明确独立（不扣客户余额），分页客户列表的“核销次数”同样只累计已通过的 `NORMAL` 正常核销；并返回退费生效前是否已有付费核销、退费实际扣掉的客户余额、余额不足而未扣余的退款、历史冲销、原始应计余额和按客户×项目归零后的调整，避免把不同客户的余额跨人抵扣。该动作依赖迁移 `021_customer_product_effective_balances.sql` 的客户余额汇总；生产环境建议同时执行迁移 `031_store_dashboard_indexes.sql`。
- `listActiveTeachers`：门店账号读取全部活跃老师；老师账号只能得到当前登录老师本人。老师办理页的老师下拉框由此锁定，浏览器不能把工单绑定给其他老师。
- `listActiveProducts`：允许活跃门店或已选择活跃门店的老师调用，只返回数据库中 `product_status='ACTIVE'` 产品的内部 ID、编号和名称；不会预取介绍、类别或任何价格字段。
- `listActiveRetailProducts`：允许活跃门店或已选择活跃门店的老师调用，只返回迁移 060 中状态为 `ACTIVE` 的独立产品 ID、自动编号和名称，供充值第三步赠品选择；不返回封存产品。
- `createRechargeApplication`：只创建一张 `NEW`、`PENDING` 的真实充值或退费单，并使用 `idempotency_key` 防止双击或网络重试重复建单。门店办理时业务老师可选；老师办理时服务端强制绑定当前登录老师并拒绝其他老师 ID。正常充值可附带最多 20 行不重复的激活产品赠品，主记录和赠品由单条数据修改 CTE 原子写入；同一防重编号重试还会逐行核对赠品，不允许借重试改清单。退费拒绝赠品。提交待审核单不会增加客户充值次数；只有审核把同一张单改为 `APPROVED` 后，数据库汇总触发器才会计入次数，赠品本身不进入业务次数。部署前依次确认已执行迁移 `021_customer_product_effective_balances.sql`、`023_recharge_pending_submission.sql`、`024_optional_recharge_teacher.sql`、060 和 061。
- `createVerificationApplication`：门店与老师均支持正常核销；门店的业务老师可留空，选择时必须是一位真实活跃老师，老师账号则由服务端自动绑定本人。体验核销只允许老师账号，并同样绑定当前老师。调用者必须先确认目标门店活跃客户、有效业务条件并完成该客户的 1:1 人脸验证；服务端同时校验未过期、未消费、属于同一提交账号／门店／客户／人脸请求的照片令牌，并通过数据库函数原子创建工单、固化客户留存照引用、绑定本次人脸照片和设备信号。体验核销扣减当前老师的可用体验额度，不扣客户购买余额。
- `createSupplementVerificationApplication`：门店与老师通过迁移 079 的专用数据库函数提交 `SUPPLEMENT/PENDING` 补录申请；复用正常核销的客户、项目、次数、老师与留言字段，但不读取人脸、不创建现场照片、不建立 BLE 资格或设备信号，提交时也不扣次。总部在 `staffAccount.reviewOrder` 审核通过时由数据库锁定客户并重新核对余额后原子扣次；通过后普通查询和统计按正常核销显示。
- `getTeacherWorkspace`：仅允许活跃老师读取本人基础资料；本人业务列表和统计查询经过来源校验且 `teacher_id` 等于当前老师的已通过充值、退费、正常核销和体验核销，包含门店选择该老师办理的有效工单。有效业务同时建立老师客户关系；读取精确详情时，服务端先确认工单归属本人或该工单客户属于当前老师的有效客户关系，再允许查看同一客户由其他账号提交的历史。详情只显示来源可信的工单业务老师。被选择为业务老师不等于原提交人，任何改单、补照片或提交恢复仍只认 `submitted_by_account_id`。
- `getActiveStoreCustomerDetail`：客户在下拉框中被选中后才调用；重新确认客户仍为当前门店或老师所选门店的活跃客户，再返回办理流程需要的客户资料和私有照片短时签名地址。短时地址会在安全有效期内由页面与云函数温实例复用，避免重复签名和重复查询；每次返回前仍先执行当前登录身份和门店范围校验。
- `getCustomerProfile`：总部可读取任意客户、门店只可读取本门店客户；老师可读取当前老师账号亲自创建的客户，或本人已有已通过正常核销、体验核销、充值、退费任一关系的客户。余额直接读取汇总表，充值与核销历史各自先返回最近 50 条，后续使用 `(submitted_at,id)` 游标每批最多 100 条，避免一次返回整段历史。
- `getReviewCustomerProfile`：已随运营角色下线；总部审核页直接使用 `getCustomerProfile` 与审核详情入口，不再提供运营审核上下文接口。
- `getCustomerPhotoUrl`：总部可读取任意客户、门店只可读取本门店客户；老师可读取本人账号亲自创建或本人已有任一有效业务关系客户的照片。验证权限后为私有建档照片生成短时有效的签名地址。客户主页使用此动作，浏览器不能直接使用数据库中的 `pg://` 引用。
  - 兼容旧版本曾保存的重复桶名前缀（例如 `pg://bucket/bucket/path`）：读取时自动尝试两个合法对象名，成功后把数据库引用规范化。
  - 兼容 CloudBase `signObject` 的直接／包装返回结构；单对象接口未返回 URL 时自动使用 `signObjects` 复核，并继续尝试旧照片路径。
  - 若两个路径都不存在，返回 `CUSTOMER_PHOTO_OBJECT_MISSING`，该客户需要重新采集照片；不会把底层存储错误直接暴露给页面。
- `getCustomerProductBalances`：验证当前门店账号或老师所选门店和客户归属后，读取该客户按产品汇总的购买次数、有效核销次数和剩余次数；体验核销不消耗余额。核销不提供作废入口，如需纠正误核销必须提交充值工单补回次数。
- `getCustomerStatus`：总部可读取任意客户、门店只可读取本门店客户的资料与当前活跃／封存状态；返回客户姓名、生日、备注、建立时间，以及关联门店的真实名称和门店编号。
- `updateCustomerStatus`：总部或客户所属门店把同一客户档案在 `ACTIVE` 与 `ARCHIVED` 之间切换；只更新状态和更新时间，不删除照片、面容档案或历史工单。
- `getVerificationPhotos`：总部可查看全部核销照片，门店只能查看本店；老师对客户拥有有效关系后，可以只读查看该客户由其他老师提交的核销照片。一次仅返回最多 5 张短时缩略图（客户留存照、本次核销人脸照、3 张补充照）和服务端计算的上传权限；高清原图不在列表阶段签发，数据库也不保存任何签名地址。上传、替换和取消仍要求当前账号就是原提交账号并处于 24 小时窗口内。
- `getVerificationPhotoOriginalUrl`：用户实际点击后再次校验相同工单权限，复用或刷新该照片位的短时原图地址，并写入 `VIEW_ORIGINAL` 查看审计。
- `getVerificationPhotoExportData`：仅供当前工单导出使用；执行与原图查看相同的实时账号、工单权限和 `VIEW_ORIGINAL` 审计，然后由云函数使用服务端鉴权通道直接读取单张私有 JPEG，以最多 4 MB 的 Base64 返回，不依赖临时下载地址。网页优先复用本页已经加载或刚提交的原图 Blob，只有浏览器无法读取字节时才逐张调用该安全兜底；不要求公开存储桶，也不向未授权账号签发或代理照片。
- `beginVerificationPhotoUpload`：入参仅为 `recordId`、客户端幂等 `requestId`、照片位 `slot=2..4` 和压缩后 JPEG 的实际 `originalBytes`。服务端先验证当前登录账号确为工单提交人且仍在 24 小时内；新请求先按真实 `storage.buckets.id` 选择桶，再调用数据库原子函数建立／复用任务并取得单任务锁。每单数据库层最多一条 `UPLOADING`，跨标签页也不能同时传第二张；同一 `requestId` 重试返回同一任务，不重复计数。每单／提交人一小时最多建立 30 个新任务。当前客户端在 `verificationPhoto v14` 调用该动作，固定收到 `uploadMode=DIRECT` 和任务绑定的一次性 PUT 地址。
- `commitVerificationPhotoUpload`：`verificationPhoto v14` 只要求客户端发送 `recordId` 和 `requestId`，拒绝 Base64 图片、客户端桶、路径、尺寸、散列或 MIME 元数据。服务端从数据库请求保存的对象引用读取真实内容，核对预期字节、JPEG 文件头、尺寸和 SHA-256，再由数据库函数锁定订单和请求，在同一事务中写照片、写审计并把任务改为 `COMMITTED`。主函数的旧兼容入口仍有受证明约束的函数回退，但当前客户端不使用。
- `cancelVerificationPhotoUpload`：入参为 `recordId`、`requestId`；仅提交人可取消自己的未提交任务。取消立刻释放“每单一个任务”锁，但对象等签名保守失效 3 小时后才由定时清理删除，防止迟到 PUT 复活孤儿文件。已经提交的任务不能撤回照片。
- `getVerificationPhotoUploadStatus`：入参为 `recordId`、`requestId`；仅提交人可读取，返回 `UPLOADING`／`COMMITTED`／`CANCELLED`／`EXPIRED` 及对象是否已经到达存储。用于断网或页面恢复，不签发查看权限，也不扩大工单范围。
- `verificationPhoto v14` 的 `originalUpload` 只包含 HTTPS URL、PUT 方法、JPEG MIME、随机对象标识和预期字节数；函数响应绝不包含 `CLOUDBASE_APIKEY` 或兼容变量 `CLOUDBASE_SERVICE_ROLE_KEY`。`thumbnailUpload` 固定为 `null`，因为缩略图由服务端图片处理生成。
- `uploadVerificationExtraPhoto`：仅用于“迁移 039 尚未执行”的旧版短时兼容。迁移 039 一旦存在，该旧入口立即返回 `PHOTO_UPLOAD_DIRECT_REQUIRED`，防止旧页面绕过单任务锁；它与受上传请求约束的新 `FUNCTION` 路径不是同一条路径，不可混用。
- v99 延续照片专用启动模式和动作白名单，不暴露任何老师人脸创建、补录、替换、回读、回滚、最终清理或体验核销比对动作。普通核销与老师赠送体验都只对所选客户执行 `VerifyFace` 1:1 比对；系统没有 `SearchPersons`／`searchCustomer` 1:N 入口。照片桶仍保持私有，所有列表、原图与导出读取仍先经过账号和工单权限校验。
- `cleanupVerificationPhotoDrafts`：平台 Timer 自动入口不接收业务参数或凭证，只在可信 SCF Timer 上清理过期未消费草稿；控制台手工入口仍使用恒定时间比较的专用随机凭证。两种入口都不删除已经绑定核销单的照片。

正式上线前还要提供客户授权记录、照片与人脸数据删除流程、访问审计，并确认腾讯云高精度静态活体服务已开通和计费。

当前从已验收 faceRecognition v141／staffAccount v100 升级：须先按完整备份门禁执行并独立验收093，再部署 staffAccount v107、faceRecognition v145，核对运行版本及回下载全部根文件，最后更新客户端。不重复执行091、092。
